<?php
function sendTelegramMessage($message, $topicId, $botToken, $chatId) {
    if (!$botToken || !$chatId) {
        return; // Não faz nada se a configuração estiver incompleta
    }

    $url = "https://api.telegram.org/bot{$botToken}/sendMessage";
    
    $data = [
        'chat_id' => $chatId,
        'text' => $message,
        'parse_mode' => 'HTML',
        'disable_web_page_preview' => true,
    ];

    // Adiciona o ID do tópico se for fornecido
    if ($topicId) {
        $data['message_thread_id'] = $topicId;
    }

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    
    // Para ambientes de desenvolvimento (como XAMPP), pode ser necessário desativar a verificação SSL.
    // Em produção, o ideal é ter os certificados CA corretos no servidor.
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    
    // Opcional: Logar erros do cURL para depuração
    if (curl_errno($ch)) {
        error_log('Telegram cURL Error: ' . curl_error($ch));
    }
    
    curl_close($ch);

    return $response;
}