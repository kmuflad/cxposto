<?php
function auth_check(string $tipo = ''): void
{
    // Sessão com duração de 24 horas
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 86400,
            'path' => '/',
            'secure' => false,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }

    // Verifica se está logado na sessão
    if (empty($_SESSION['usuario_id'])) {
        header('Location: /login.php');
        exit;
    }

    // Verifica expiração de 24h
    if (!empty($_SESSION['login_time']) && (time() - $_SESSION['login_time']) > 86400) {
        session_destroy();
        header('Location: /login.php?exp=1');
        exit;
    }

    // Verifica tipo de acesso (Admin pode acessar tudo)
    if ($tipo !== '' && $_SESSION['tipo'] !== $tipo && $_SESSION['tipo'] !== 'admin') {
        header('Location: /login.php?acesso=negado');
        exit;
    }

    // Validação no Banco de Dados: Verifica se o usuário ainda existe e está ativo
    try {
        // Usa o DB global se já estiver incluído, ou cria nova conexão PDO se necessário.
        // Como o config/db.php geralmente é incluído logo após o auth_check.php,
        // garantimos a inclusão aqui se a função getDB não existir.
        if (!function_exists('getDB')) {
            require_once __DIR__ . '/db.php';
        }
        
        $db = getDB();
        $stmt = $db->prepare("SELECT ativo, tipo, data_base_escala FROM usuarios WHERE id = ?");
        $stmt->execute([$_SESSION['usuario_id']]);
        $user = $stmt->fetch();

        // Se o usuário foi excluído ou inativado, destrói a sessão
        if (!$user || $user['ativo'] == 0) {
            session_destroy();
            header('Location: /login.php?erro=desativado');
            exit;
        }

        // Verifica escala se for operador
        if ($user['tipo'] === 'operador' && $user['data_base_escala']) {
            $hoje = new DateTime(date('Y-m-d'));
            $base = new DateTime($user['data_base_escala']);
            $diff = $hoje->diff($base)->days;
            if ($diff % 2 != 0) {
                session_destroy();
                header('Location: /login.php?erro=folga');
                exit;
            }
        }

        // Logica de abertura automática removida conforme solicitado.


    } catch (PDOException $e) {
        // Ignora erro de banco na checagem para não quebrar a tela inteira em instabilidades,
        // mas o ideal é registrar em log.
    }
}
