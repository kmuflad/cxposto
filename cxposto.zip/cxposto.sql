-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 23/06/2026 às 22:45
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `cxposto`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `caixas`
--

CREATE TABLE `caixas` (
  `id` int(11) NOT NULL,
  `operador_id` int(11) NOT NULL,
  `operador2_id` int(11) DEFAULT NULL,
  `abertura` datetime NOT NULL DEFAULT current_timestamp(),
  `fechamento` datetime DEFAULT NULL,
  `valor_abertura` decimal(10,2) NOT NULL DEFAULT 0.00,
  `valor_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `status` enum('aberto','fechado') NOT NULL DEFAULT 'aberto',
  `valor_dinheiro_final` decimal(10,2) DEFAULT 0.00,
  `valor_vales_final` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `caixas`
--

INSERT INTO `caixas` (`id`, `operador_id`, `operador2_id`, `abertura`, `fechamento`, `valor_abertura`, `valor_total`, `status`, `valor_dinheiro_final`, `valor_vales_final`) VALUES
(2, 7, 8, '2026-06-23 15:35:10', NULL, 0.00, 46.00, 'aberto', 0.00, 0.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `caixa_combustiveis`
--

CREATE TABLE `caixa_combustiveis` (
  `id` int(11) NOT NULL,
  `caixa_id` int(11) NOT NULL,
  `combustivel_id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `litragem_inicial` decimal(12,3) NOT NULL DEFAULT 0.000,
  `altura_inicial` decimal(10,2) DEFAULT 0.00,
  `litragem_final` decimal(12,3) DEFAULT NULL,
  `altura_final` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `caixa_combustiveis`
--

INSERT INTO `caixa_combustiveis` (`id`, `caixa_id`, `combustivel_id`, `nome`, `preco`, `litragem_inicial`, `altura_inicial`, `litragem_final`, `altura_final`) VALUES
(1, 2, 2, 'Diesel S-10', 7.79, 0.000, 0.00, NULL, NULL),
(2, 2, 1, 'Gasolina Comum', 7.29, 0.000, 0.00, NULL, NULL);

-- --------------------------------------------------------

--
-- Estrutura para tabela `clientes_abastecimento`
--

CREATE TABLE `clientes_abastecimento` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `empresa` varchar(150) DEFAULT NULL,
  `carro` varchar(100) DEFAULT NULL,
  `placa` varchar(20) DEFAULT NULL,
  `ativo` tinyint(1) DEFAULT 1,
  `criado_em` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `clientes_abastecimento`
--

INSERT INTO `clientes_abastecimento` (`id`, `nome`, `empresa`, `carro`, `placa`, `ativo`, `criado_em`) VALUES
(1, 'RENATO', 'Select Locações', 'Onibus', 'AVS6259', 1, '2026-06-23 13:39:26'),
(2, 'MAIK', 'Prefeitura', 'Mobi', 'ABC1235', 1, '2026-06-23 13:54:52'),
(3, 'TOINHO', 'Prefeitura', 'Mobi', 'ABV5483', 1, '2026-06-23 13:55:43'),
(4, 'JUNIOR', 'Select Locações', 'Onibus', '123456', 1, '2026-06-23 14:21:14'),
(5, 'CARLINHOS', 'Select Locações', 'Onibus', '123456', 1, '2026-06-23 14:21:28'),
(6, 'MIGUEL', 'Select Locações', 'Onibus', '123456', 1, '2026-06-23 14:21:50');

-- --------------------------------------------------------

--
-- Estrutura para tabela `combustiveis`
--

CREATE TABLE `combustiveis` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `preco` decimal(10,2) NOT NULL DEFAULT 0.00,
  `litragem_atual` decimal(12,3) NOT NULL DEFAULT 0.000,
  `altura_atual` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `combustiveis`
--

INSERT INTO `combustiveis` (`id`, `nome`, `preco`, `litragem_atual`, `altura_atual`) VALUES
(1, 'Gasolina Comum', 7.29, 0.000, 0.00),
(2, 'Diesel S-10', 7.79, 0.000, 0.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_mesa`
--

CREATE TABLE `itens_mesa` (
  `id` int(11) NOT NULL,
  `mesa_id` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `valor_unitario` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_venda`
--

CREATE TABLE `itens_venda` (
  `id` int(11) NOT NULL,
  `venda_id` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `nome_produto` varchar(150) NOT NULL,
  `valor_unitario` decimal(10,2) NOT NULL,
  `quantidade` int(11) NOT NULL DEFAULT 1,
  `valor_total` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `itens_venda`
--

INSERT INTO `itens_venda` (`id`, `venda_id`, `produto_id`, `nome_produto`, `valor_unitario`, `quantidade`, `valor_total`) VALUES
(2, 2, 76, 'Cerveja Budwaiser', 7.00, 1, 7.00),
(3, 2, 1, 'Água Mineral Pequena', 2.00, 2, 4.00),
(4, 2, 27, 'Cerveja Heineken', 7.00, 5, 35.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `lancamentos_avulsos`
--

CREATE TABLE `lancamentos_avulsos` (
  `id` int(11) NOT NULL,
  `caixa_id` int(11) NOT NULL,
  `operador_id` int(11) DEFAULT NULL,
  `tipo` enum('pix','cielo','vale','dinheiro') NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `descricao` varchar(255) DEFAULT NULL,
  `venda_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `mesas`
--

CREATE TABLE `mesas` (
  `id` int(11) NOT NULL,
  `caixa_id` int(11) NOT NULL,
  `nome` varchar(50) NOT NULL,
  `criado_em` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `nome` varchar(150) NOT NULL,
  `codigo_barras` varchar(80) DEFAULT NULL,
  `valor` decimal(10,2) NOT NULL DEFAULT 0.00,
  `estoque` int(11) NOT NULL DEFAULT 0,
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `codigo_barras`, `valor`, `estoque`, `ativo`, `criado_em`) VALUES
(1, 'Água Mineral Pequena', '7891107101621', 2.00, 13, 1, '2026-05-13 22:41:16'),
(2, 'Água Mineral Grande', '7898013050029', 4.00, 44, 1, '2026-05-13 23:00:41'),
(3, 'Cheetos Requeijão', '7892840822309', 4.00, 9, 1, '2026-05-13 23:01:27'),
(6, 'Picolé de Açaí', '6806399612645', 4.50, 19, 1, '2026-05-14 18:24:51'),
(7, 'Ruffles', '7892840824693', 6.00, 15, 1, '2026-05-14 18:25:40'),
(8, 'Doritos', '7892840822385', 6.00, 14, 1, '2026-05-14 18:26:14'),
(9, 'Fandangos Assado', '7892840824778', 4.00, 10, 1, '2026-05-14 18:26:52'),
(10, 'Sensação', '7892840825218', 7.00, 10, 1, '2026-05-14 18:27:13'),
(11, 'Cebolitos', '7892840825126', 4.00, 9, 1, '2026-05-14 18:27:38'),
(12, 'Torcida Churrasco', '7892840822477', 2.00, 45, 1, '2026-05-14 18:28:10'),
(13, 'Amedoin', '7892840815745', 4.00, 12, 1, '2026-05-14 18:28:27'),
(14, 'Lays', '7892840825195', 6.00, 10, 1, '2026-05-14 18:28:49'),
(15, 'Refrigerante Cajuina', '8089779257433', 5.00, 10, 1, '2026-05-14 18:29:29'),
(16, 'Refrigerante Coca-Cola', '8727512160730', 5.00, 16, 1, '2026-05-14 18:30:48'),
(17, 'Água de Coco', '7897770000025', 4.00, 19, 1, '2026-05-14 18:32:08'),
(18, 'Água com Gás', '6230564526008', 3.00, 7, 1, '2026-05-14 18:32:28'),
(19, 'Suco Goiaba', '1420137366704', 2.00, 14, 1, '2026-05-14 18:32:44'),
(20, 'Toddynho', '2036151802427', 4.00, 9, 1, '2026-05-14 18:32:57'),
(21, 'Mini Monster', '1155754476537', 10.00, 12, 1, '2026-05-14 18:35:28'),
(22, 'Monster Grande', '9966950939369', 12.00, 12, 1, '2026-05-14 18:35:43'),
(23, 'Red Bull', '7077853898008', 12.00, 12, 1, '2026-05-14 18:37:54'),
(24, 'Cerveja Skol Lata', '4663004976460', 5.00, 9, 1, '2026-05-14 18:38:19'),
(25, 'Cerveja Skol Vidro', '4353638251501', 5.00, 20, 1, '2026-05-14 18:38:40'),
(26, 'Cerveja Itaipava', '9758846500762', 5.00, 11, 1, '2026-05-14 18:38:58'),
(27, 'Cerveja Heineken', '5271950080168', 7.00, 34, 1, '2026-05-14 20:34:55'),
(28, 'Cerveja Bohemia', '5478523038245', 4.00, 15, 1, '2026-05-14 20:35:23'),
(29, 'Cerveja Devassa', '8463021416149', 5.00, 15, 1, '2026-05-14 20:35:41'),
(30, 'Cerveja Stella', '9882338644198', 7.00, 13, 1, '2026-05-14 20:36:01'),
(32, 'Cerveja Ultra', '7582398934790', 7.00, 14, 1, '2026-05-14 20:37:05'),
(33, 'Potinho Morango', '742832193788', 3.50, 19, 1, '2026-05-15 06:22:47'),
(34, 'Potinho Flocs', '742832193771', 3.50, 16, 1, '2026-05-15 06:23:20'),
(36, 'Sorvete QMax Maracujá', '742832143264', 9.50, 15, 1, '2026-05-15 06:25:12'),
(37, 'Sorvete QMax Cookies', '6701959874391', 9.50, 16, 1, '2026-05-15 06:25:54'),
(38, 'Sorvete QMax Brigadeiro', '742832228084', 9.50, 18, 1, '2026-05-15 06:26:16'),
(39, 'Sorvete QMax Sonho', '0161361172807', 9.50, 20, 1, '2026-05-15 06:27:14'),
(40, 'Sorvete QMax Petit', '6128280117355', 9.50, 20, 1, '2026-05-15 06:27:43'),
(41, 'Sorvete Cone Brigadeiro', '1468895436728', 9.50, 20, 1, '2026-05-15 06:28:51'),
(42, 'Sorvete Cone Crocante', '0918659986552', 9.50, 20, 1, '2026-05-15 06:29:31'),
(43, 'P. Bombom Ferreiro', '6756020207464', 7.00, 20, 1, '2026-05-15 06:30:32'),
(44, 'P. Prestígio', '8935553859439', 7.00, 20, 1, '2026-05-15 06:31:19'),
(45, 'P. QMaltine', '2178129106726', 7.00, 19, 1, '2026-05-15 06:31:49'),
(46, 'P. Doce de Leite', '3819327132662', 7.00, 20, 1, '2026-05-15 06:32:13'),
(47, 'Picolé Bombom Branco', '4245658160309', 7.00, 20, 1, '2026-05-15 06:35:16'),
(48, 'P. Fruta Uva', '1767222685410', 2.50, 20, 1, '2026-05-15 06:35:52'),
(49, 'Picolé Fruta Morango', '742832214148', 2.50, 18, 1, '2026-05-15 06:37:15'),
(50, 'P. Fruta Limão', '1234452253657', 2.50, 16, 1, '2026-05-15 06:37:57'),
(51, 'P. Oblets', '8149861163845', 9.50, 20, 1, '2026-05-15 06:38:37'),
(52, 'P. Skimo', '8751591267034', 6.00, 20, 1, '2026-05-15 06:39:08'),
(53, 'P. Recheado Grego', '0186657565071', 5.00, 20, 1, '2026-05-15 06:39:48'),
(54, 'P. Recheado Leitinho', '2216583296328', 5.00, 20, 1, '2026-05-15 06:40:12'),
(55, 'P. Recheado Trufado', '7627655459011', 5.00, 20, 1, '2026-05-15 06:40:36'),
(56, 'P. Pinta Lingua Kids', '742832208345', 1.50, 12, 1, '2026-05-15 06:41:11'),
(57, 'Sorvete Qsundae', '742832742382', 7.00, 15, 1, '2026-05-15 12:02:13'),
(58, 'Refrigerante Sprite', '5622712598389', 5.00, 19, 1, '2026-05-15 16:11:50'),
(59, 'Qcopão napolitano', '742832742436', 9.50, 19, 1, '2026-05-15 18:47:52'),
(60, 'Estopa', '2637278612243', 4.00, 9, 1, '2026-05-19 08:27:58'),
(61, 'Cheetos Parmesão', '7892840822286', 4.00, 15, 1, '2026-05-19 09:01:37'),
(62, 'Torcida Pimenta Mexicana', '7892840822507', 2.00, 19, 1, '2026-05-19 09:11:34'),
(63, 'Fandangos Assado', '7892840822835', 4.00, 20, 1, '2026-05-19 09:14:54'),
(64, 'Picolé Cremoso Leite Condensado', '742832143226', 3.50, 17, 1, '2026-05-19 09:39:59'),
(65, 'Suco de Acerola', '7885429947740', 2.00, 20, 1, '2026-05-19 09:46:02'),
(66, 'Mobil Super 10W 40', '7896636551381', 40.00, 12, 1, '2026-05-19 10:01:08'),
(67, 'Mobil Super 20W 50 MINERAL', '7896636550599', 30.00, 11, 1, '2026-05-19 10:02:19'),
(68, 'Mobil Super 5W 30 Sintético', '7896636552265', 50.00, 12, 1, '2026-05-19 10:03:14'),
(69, 'Lubrificante Mineral Lubrax GL-5 90', '7891344006437', 45.00, 11, 1, '2026-05-19 10:04:20'),
(70, 'Lubrificante Hipoid 90 GL4', '7892908600115', 36.00, 7, 1, '2026-05-19 10:10:56'),
(71, 'Lubrificante Street 20W50 SL Mineral', '602883313446', 25.00, 8, 1, '2026-05-19 10:12:36'),
(72, 'Aditivo Estabilizador Diesel', '4068362065903', 35.00, 9, 1, '2026-05-19 10:14:01'),
(73, 'Sorvete Grego 1,5L', '5018758162931', 30.00, 0, 1, '2026-05-19 12:42:33'),
(74, 'Lubrificante 4T Street 20W50 Mineral', '6824333973162', 25.00, 11, 1, '2026-05-19 13:45:51'),
(75, 'refrigerante fanta', '2860860757298', 5.00, 17, 1, '2026-05-19 14:20:38'),
(76, 'Cerveja Budwaiser', '8398739445876', 7.00, 12, 1, '2026-05-21 06:32:36'),
(81, 'Sorvete Chocolate 2L', '1459887555461', 28.00, 9, 1, '2026-05-21 12:53:49'),
(82, 'Picolé Cremoso Morango', '5294364502146', 3.50, 15, 1, '2026-05-21 16:27:30'),
(83, 'Picolé Cremoso Coco', '5837566999882', 3.50, 14, 1, '2026-05-21 16:28:07'),
(84, 'Picolé Cremoso Tapioca', '6832853002860', 3.50, 0, 1, '2026-05-21 16:28:42'),
(85, 'Picolé Cremoso Napolitano', '8457895956939', 3.50, 15, 1, '2026-05-21 16:29:13'),
(86, 'Protein', '9040051273324', 7.00, 15, 1, '2026-05-23 08:26:04'),
(87, 'Fluido De Freio DOT 3 BOSH', '0051691562935', 30.00, 19, 1, '2026-05-23 16:39:17');

-- --------------------------------------------------------

--
-- Estrutura para tabela `retiradas_vale`
--

CREATE TABLE `retiradas_vale` (
  `id` int(11) NOT NULL,
  `vale_id` int(11) NOT NULL,
  `quantidade_retirada` decimal(12,3) NOT NULL,
  `valor_retirado` decimal(10,2) NOT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `retirado_em` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `login` varchar(50) NOT NULL,
  `senha` varchar(255) NOT NULL,
  `tipo` enum('admin','operador') NOT NULL DEFAULT 'operador',
  `ativo` tinyint(1) NOT NULL DEFAULT 1,
  `data_base_escala` date DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `login`, `senha`, `tipo`, `ativo`, `data_base_escala`, `criado_em`) VALUES
(1, 'Administrador', 'admin', '$2y$10$gxTrdJz/DtpbxrzlqQbh5.KFCHYOO46cX3NdL4ZAeiHVjyTKGB.aC', 'admin', 1, NULL, '2026-05-13 22:29:37'),
(7, 'RENAN', '008', '$2y$10$2m32LG9X5mrQw6YO66XS8ODjGtLNv/ylqjLd916c5gKCYY1oksZLG', 'operador', 1, '2026-06-23', '2026-06-23 15:21:23'),
(8, 'OSMAR', '003', '$2y$10$sY6owtCC92kkGZRYrHUDz.2Ibdp3pea.i0H111D3/5vi8JoSnpJSi', 'operador', 1, '2026-06-23', '2026-06-23 15:21:40');

-- --------------------------------------------------------

--
-- Estrutura para tabela `vales`
--

CREATE TABLE `vales` (
  `id` int(11) NOT NULL,
  `caixa_id` int(11) NOT NULL,
  `operador_id` int(11) NOT NULL,
  `operador2_id` int(11) DEFAULT NULL,
  `cliente_id` int(11) DEFAULT NULL,
  `nome_cliente` varchar(150) NOT NULL,
  `empresa` varchar(150) DEFAULT NULL,
  `carro` varchar(100) DEFAULT NULL,
  `placa` varchar(20) DEFAULT NULL,
  `km` decimal(10,2) DEFAULT NULL,
  `combustivel_id` int(11) NOT NULL,
  `nome_combustivel` varchar(100) NOT NULL,
  `preco_combustivel` decimal(10,2) NOT NULL,
  `tipo_quantidade` enum('litros','dinheiro') NOT NULL DEFAULT 'litros',
  `quantidade` decimal(12,3) NOT NULL DEFAULT 0.000,
  `valor_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `descricao` text DEFAULT NULL,
  `status` enum('ativo','revogado') NOT NULL DEFAULT 'ativo',
  `criado_em` datetime DEFAULT current_timestamp(),
  `revogado_em` datetime DEFAULT NULL,
  `revogado_por` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `vales`
--

INSERT INTO `vales` (`id`, `caixa_id`, `operador_id`, `operador2_id`, `cliente_id`, `nome_cliente`, `empresa`, `carro`, `placa`, `km`, `combustivel_id`, `nome_combustivel`, `preco_combustivel`, `tipo_quantidade`, `quantidade`, `valor_total`, `descricao`, `status`, `criado_em`, `revogado_em`, `revogado_por`) VALUES
(5, 2, 8, NULL, 6, 'MIGUEL', 'Select Locações', 'Onibus', '123456', NULL, 2, 'Diesel S-10', 7.79, 'litros', 110.000, 856.90, NULL, 'ativo', '2026-06-23 15:39:04', NULL, NULL),
(6, 2, 7, NULL, 4, 'JUNIOR', 'Select Locações', 'Onibus', '123456', NULL, 2, 'Diesel S-10', 7.79, 'litros', 100.000, 779.00, NULL, 'revogado', '2026-06-23 15:52:18', '2026-06-23 15:54:52', 1);

-- --------------------------------------------------------

--
-- Estrutura para tabela `vendas`
--

CREATE TABLE `vendas` (
  `id` int(11) NOT NULL,
  `caixa_id` int(11) NOT NULL,
  `operador_id` int(11) NOT NULL,
  `valor_total` decimal(10,2) NOT NULL DEFAULT 0.00,
  `valor_dinheiro` decimal(10,2) DEFAULT 0.00,
  `valor_pix` decimal(10,2) DEFAULT 0.00,
  `valor_cielo` decimal(10,2) DEFAULT 0.00,
  `valor_vale` decimal(10,2) DEFAULT 0.00,
  `forma_pagamento` enum('dinheiro','pix','cielo','vale') NOT NULL DEFAULT 'dinheiro',
  `status` enum('finalizada','cancelada') NOT NULL DEFAULT 'finalizada',
  `criado_em` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `vendas`
--

INSERT INTO `vendas` (`id`, `caixa_id`, `operador_id`, `valor_total`, `valor_dinheiro`, `valor_pix`, `valor_cielo`, `valor_vale`, `forma_pagamento`, `status`, `criado_em`) VALUES
(2, 2, 7, 46.00, 46.00, 0.00, 0.00, 0.00, 'dinheiro', 'finalizada', '2026-06-23 15:59:49');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `caixas`
--
ALTER TABLE `caixas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `operador_id` (`operador_id`),
  ADD KEY `fk_caixas_operador2_id` (`operador2_id`);

--
-- Índices de tabela `caixa_combustiveis`
--
ALTER TABLE `caixa_combustiveis`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_caixa_comb` (`caixa_id`,`combustivel_id`);

--
-- Índices de tabela `clientes_abastecimento`
--
ALTER TABLE `clientes_abastecimento`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `combustiveis`
--
ALTER TABLE `combustiveis`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `itens_mesa`
--
ALTER TABLE `itens_mesa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `mesa_id` (`mesa_id`),
  ADD KEY `produto_id` (`produto_id`);

--
-- Índices de tabela `itens_venda`
--
ALTER TABLE `itens_venda`
  ADD PRIMARY KEY (`id`),
  ADD KEY `venda_id` (`venda_id`),
  ADD KEY `produto_id` (`produto_id`);

--
-- Índices de tabela `lancamentos_avulsos`
--
ALTER TABLE `lancamentos_avulsos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `caixa_id` (`caixa_id`),
  ADD KEY `fk_lancamentos_operador` (`operador_id`);

--
-- Índices de tabela `mesas`
--
ALTER TABLE `mesas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `caixa_id` (`caixa_id`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `codigo_barras` (`codigo_barras`);

--
-- Índices de tabela `retiradas_vale`
--
ALTER TABLE `retiradas_vale`
  ADD PRIMARY KEY (`id`),
  ADD KEY `vale_id` (`vale_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Índices de tabela `vales`
--
ALTER TABLE `vales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `caixa_id` (`caixa_id`),
  ADD KEY `operador_id` (`operador_id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `fk_operador2` (`operador2_id`);

--
-- Índices de tabela `vendas`
--
ALTER TABLE `vendas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `caixa_id` (`caixa_id`),
  ADD KEY `operador_id` (`operador_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `caixas`
--
ALTER TABLE `caixas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `caixa_combustiveis`
--
ALTER TABLE `caixa_combustiveis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `clientes_abastecimento`
--
ALTER TABLE `clientes_abastecimento`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `combustiveis`
--
ALTER TABLE `combustiveis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `itens_mesa`
--
ALTER TABLE `itens_mesa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `itens_venda`
--
ALTER TABLE `itens_venda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de tabela `lancamentos_avulsos`
--
ALTER TABLE `lancamentos_avulsos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `mesas`
--
ALTER TABLE `mesas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;

--
-- AUTO_INCREMENT de tabela `retiradas_vale`
--
ALTER TABLE `retiradas_vale`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `vales`
--
ALTER TABLE `vales`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `vendas`
--
ALTER TABLE `vendas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `caixas`
--
ALTER TABLE `caixas`
  ADD CONSTRAINT `caixas_ibfk_1` FOREIGN KEY (`operador_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `fk_caixas_operador2_id` FOREIGN KEY (`operador2_id`) REFERENCES `usuarios` (`id`);

--
-- Restrições para tabelas `caixa_combustiveis`
--
ALTER TABLE `caixa_combustiveis`
  ADD CONSTRAINT `caixa_combustiveis_ibfk_1` FOREIGN KEY (`caixa_id`) REFERENCES `caixas` (`id`);

--
-- Restrições para tabelas `itens_mesa`
--
ALTER TABLE `itens_mesa`
  ADD CONSTRAINT `itens_mesa_ibfk_1` FOREIGN KEY (`mesa_id`) REFERENCES `mesas` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `itens_mesa_ibfk_2` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `lancamentos_avulsos`
--
ALTER TABLE `lancamentos_avulsos`
  ADD CONSTRAINT `fk_lancamentos_operador` FOREIGN KEY (`operador_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `lancamentos_avulsos_ibfk_1` FOREIGN KEY (`caixa_id`) REFERENCES `caixas` (`id`);

--
-- Restrições para tabelas `mesas`
--
ALTER TABLE `mesas`
  ADD CONSTRAINT `mesas_ibfk_1` FOREIGN KEY (`caixa_id`) REFERENCES `caixas` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `retiradas_vale`
--
ALTER TABLE `retiradas_vale`
  ADD CONSTRAINT `retiradas_vale_ibfk_1` FOREIGN KEY (`vale_id`) REFERENCES `vales` (`id`) ON DELETE CASCADE;

--
-- Restrições para tabelas `vales`
--
ALTER TABLE `vales`
  ADD CONSTRAINT `fk_operador2` FOREIGN KEY (`operador2_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `vales_ibfk_1` FOREIGN KEY (`caixa_id`) REFERENCES `caixas` (`id`),
  ADD CONSTRAINT `vales_ibfk_2` FOREIGN KEY (`operador_id`) REFERENCES `usuarios` (`id`),
  ADD CONSTRAINT `vales_ibfk_3` FOREIGN KEY (`cliente_id`) REFERENCES `clientes_abastecimento` (`id`);

--
-- Restrições para tabelas `vendas`
--
ALTER TABLE `vendas`
  ADD CONSTRAINT `vendas_ibfk_1` FOREIGN KEY (`caixa_id`) REFERENCES `caixas` (`id`),
  ADD CONSTRAINT `vendas_ibfk_2` FOREIGN KEY (`operador_id`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
