<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('operador');

$caixa = null;
$produtos = [];
try {
  $db = getDB();
  
  // Verifica se a coluna operador2_id existe para evitar erros fatais
  $colunaOperador2Existe = $db->query("SHOW COLUMNS FROM `caixas` LIKE 'operador2_id'")->fetch();

  if ($colunaOperador2Existe) {
      $stmt = $db->query("
        SELECT c.*, u1.nome as operador, u2.nome as operador2
        FROM caixas c 
        JOIN usuarios u1 ON u1.id=c.operador_id 
        LEFT JOIN usuarios u2 ON u2.id=c.operador2_id
        WHERE c.status='aberto' ORDER BY c.abertura DESC LIMIT 1");
  } else {
      $stmt = $db->query("
        SELECT c.*, u1.nome as operador, NULL as operador2
        FROM caixas c 
        JOIN usuarios u1 ON u1.id=c.operador_id 
        WHERE c.status='aberto' ORDER BY c.abertura DESC LIMIT 1");
  }
    $caixa = $stmt->fetch();
  if ($caixa) {
    $produtos = $db->query("SELECT id,nome,codigo_barras,valor,estoque FROM produtos WHERE ativo=1 ORDER BY nome ASC")->fetchAll();
    $stmtComb = $db->prepare("SELECT * FROM caixa_combustiveis WHERE caixa_id = ? ORDER BY nome ASC");
    $stmtComb->execute([$caixa['id']]);
    $combustiveisNoCaixa = $stmtComb->fetchAll();

    // Carrega configurações
    $configPath = __DIR__ . '/../config/settings.json';
    $configCaixa = file_exists($configPath) ? json_decode(file_get_contents($configPath), true) : [];

    $id = (int) $caixa['id'];
    $resumoTotais = [
      'pix' => $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$id AND tipo='pix') + (SELECT COALESCE(SUM(valor_pix),0) FROM vendas WHERE caixa_id=$id AND status='finalizada')")->fetchColumn(),
      'cielo' => $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$id AND tipo='cielo') + (SELECT COALESCE(SUM(valor_cielo),0) FROM vendas WHERE caixa_id=$id AND status='finalizada')")->fetchColumn(),
      'vale' => $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$id AND tipo='vale') + (SELECT COALESCE(SUM(valor_vale),0) FROM vendas WHERE caixa_id=$id AND status='finalizada') + (SELECT COALESCE(SUM(valor_total),0) FROM vales WHERE caixa_id=$id AND status='ativo')")->fetchColumn()
    ];
    $vendasDinheiro = $db->query("SELECT COALESCE(SUM(valor_dinheiro),0) FROM vendas WHERE caixa_id=$id AND status='finalizada'")->fetchColumn();
    
    // Soma total de combustível (avulso) lançado no turno
    $totalCombustivelTurno = $db->query("SELECT COALESCE(SUM(valor), 0) FROM lancamentos_avulsos WHERE caixa_id=$id AND descricao LIKE '%combustível%'")->fetchColumn();

    // Logs do Turno para transparência entre operadores
    $logCaixa = [];
    $caixaId = $caixa['id'];

    // 1. Vendas de produtos
    $stmtVendasLog = $db->prepare("
        SELECT v.criado_em, v.valor_total, u.nome as operador, 'Venda de Produtos' as tipo
        FROM vendas v
        JOIN usuarios u ON u.id = v.operador_id
        WHERE v.caixa_id = ? AND v.status = 'finalizada'
    ");
    $stmtVendasLog->execute([$caixaId]);
    $logCaixa = array_merge($logCaixa, $stmtVendasLog->fetchAll());

    // 2. Lançamentos avulsos (PIX, Cielo, etc) - com verificação de segurança
    $colunaOpLancamentoExiste = $db->query("SHOW COLUMNS FROM `lancamentos_avulsos` LIKE 'operador_id'")->fetch();
    if ($colunaOpLancamentoExiste) {
        $stmtLancamentosLog = $db->prepare("
            SELECT l.criado_em, l.valor as valor_total, u.nome as operador, CONCAT('Avulso: ', l.tipo) as tipo
            FROM lancamentos_avulsos l
            JOIN usuarios u ON u.id = l.operador_id
            WHERE l.caixa_id = ?
        ");
        $stmtLancamentosLog->execute([$caixaId]);
        $logCaixa = array_merge($logCaixa, $stmtLancamentosLog->fetchAll());
    }

    // 3. Vales de convênio
    $stmtValesLog = $db->prepare("
        SELECT v.criado_em, v.valor_total, u.nome as operador, 'Vale Convênio' as tipo
        FROM vales v
        JOIN usuarios u ON u.id = v.operador_id
        WHERE v.caixa_id = ? AND v.status = 'ativo'
    ");
    $stmtValesLog->execute([$caixaId]);
    $logCaixa = array_merge($logCaixa, $stmtValesLog->fetchAll());

    // Ordena o log por data, do mais recente para o mais antigo
    usort($logCaixa, fn($a, $b) => strtotime($b['criado_em']) <=> strtotime($a['criado_em']));
  }
} catch (PDOException $e) {
}

$page_id = 'venda';
$page_title = 'Venda — Convênio Posto';
include __DIR__ . '/../includes/navbar_usuario.php';
?>

<style>
  /* ── Grade de Produtos ──────────────────── */
  .prod-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
    gap: .65rem;
    padding: .75rem;
    overflow-y: auto;
    flex: 1;
  }

  .prod-card {
    background: var(--bg-card2);
    border: 1.5px solid var(--border);
    border-radius: 10px;
    padding: .85rem .75rem;
    cursor: pointer;
    transition: border-color .18s, transform .15s, background .18s;
    display: flex;
    flex-direction: column;
    gap: .3rem;
    position: relative;
    user-select: none;
  }

  .prod-card:hover {
    border-color: var(--accent);
    background: rgba(251, 146, 60, .07);
    transform: translateY(-2px);
  }

  .prod-card:active {
    transform: translateY(0) scale(.97);
  }

  .prod-card.sem-estoque {
    opacity: .4;
    pointer-events: none;
  }

  .prod-card.flash {
    animation: cardFlash .35s ease;
  }

  @keyframes cardFlash {

    0%,
    100% {
      background: rgba(251, 146, 60, .07)
    }

    50% {
      background: rgba(251, 146, 60, .3)
    }
  }

  .prod-card .pc-nome {
    font-size: .82rem;
    font-weight: 700;
    line-height: 1.3;
    color: var(--text-primary);
  }

  .prod-card .pc-valor {
    font-size: 1rem;
    font-weight: 800;
    color: var(--accent);
  }

  .prod-card .pc-estoque {
    font-size: .68rem;
    color: var(--text-muted);
  }

  .prod-card .pc-cod {
    font-size: .65rem;
    color: var(--text-muted);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }

  .prod-card .pc-add {
    position: absolute;
    top: .5rem;
    right: .5rem;
    width: 22px;
    height: 22px;
    background: var(--accent);
    color: #fff;
    border-radius: 50%;
    font-size: .85rem;
    font-weight: 700;
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity .18s;
  }

  .prod-card:hover .pc-add {
    opacity: 1;
  }

  .prod-card .pc-qty-badge {
    position: absolute;
    top: -.4rem;
    right: -.4rem;
    background: var(--accent);
    color: #fff;
    border-radius: 999px;
    font-size: .65rem;
    font-weight: 800;
    padding: .1rem .35rem;
    min-width: 18px;
    text-align: center;
    display: none;
  }

  .prod-card.in-cart .pc-qty-badge {
    display: block;
  }

  .prod-card.in-cart {
    border-color: var(--accent);
  }

  /* ── Barra de busca ─────────────────────── */
  .search-topbar {
    display: flex;
    flex-direction: column;
    gap: .5rem;
    padding: .75rem;
    border-bottom: 1px solid var(--border);
    background: var(--bg-card);
  }

  .search-topbar .search-row {
    display: flex;
    gap: .5rem;
    align-items: center;
  }

  .search-topbar input {
    flex: 1;
    background: var(--bg-input);
    border: 1.5px solid var(--border);
    border-radius: 8px;
    padding: .6rem .9rem;
    color: var(--text-primary);
    font-size: .9rem;
    font-family: 'Inter', sans-serif;
    transition: border-color .2s;
  }

  .search-topbar input:focus {
    outline: none;
    border-color: var(--accent);
  }

  /* Botão câmera — sempre visível */
  .btn-scan {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: .5rem;
    width: 100%;
    padding: .65rem;
    background: linear-gradient(135deg, rgba(251, 146, 60, .18), rgba(234, 88, 12, .12));
    border: 1.5px solid var(--accent);
    border-radius: 9px;
    color: var(--accent);
    font-size: .9rem;
    font-weight: 700;
    font-family: 'Inter', sans-serif;
    cursor: pointer;
    transition: background .2s, transform .15s;
    letter-spacing: .02em;
  }

  .btn-scan:hover {
    background: rgba(251, 146, 60, .28);
    transform: translateY(-1px);
  }

  .btn-scan:active {
    transform: translateY(0);
  }

  .btn-scan .scan-icon {
    font-size: 1.25rem;
  }

  .empty-grid {
    grid-column: 1/-1;
    text-align: center;
    padding: 2.5rem 1rem;
    color: var(--text-muted);
  }

  .empty-grid span {
    font-size: 2.5rem;
    display: block;
    margin-bottom: .75rem;
  }

  /* ── Layout mobile ──────────────────────── */
  @media (max-width: 900px) {
    .venda-grid {
      grid-template-columns: 1fr !important;
      height: auto !important;
    }

    .produtos-panel {
      height: 60vh;
      min-height: 340px;
    }

    .carrinho-panel {
      min-height: 300px;
      height: auto;
    }

    .prod-grid {
      grid-template-columns: repeat(auto-fill, minmax(130px, 1fr));
    }
  }

  @keyframes scanLine {
    0% {
      top: 20%
    }

    50% {
      top: 80%
    }

    100% {
      top: 20%
    }
  }
</style>

<div class="page-body" style="padding:1rem;">

  <?php if (!$caixa): ?>
    <div
      style="text-align:center;padding:3rem;background:var(--bg-card);border-radius:var(--radius);border:1px solid var(--border);">
      <span style="font-size:3rem;">🔒</span>
      <h2 style="margin:.75rem 0 .5rem;">Caixa Fechado</h2>
      <p style="color:var(--text-muted); margin-bottom:1.5rem;">Aguarde o administrador realizar a abertura do caixa
        global para iniciar as vendas.</p>
      <div class="badge badge-neutral">Acesso Restrito ao Administrador</div>
    </div>
  <?php else: ?>

    <div class="venda-grid">

      <!-- PAINEL ESQUERDO: GRADE DE PRODUTOS -->
      <div class="produtos-panel" style="display:flex;flex-direction:column;overflow:hidden;">

        <!-- Barra de busca + câmera -->
        <div class="search-topbar">
          <div class="search-row">
            <input type="text" id="searchInput" placeholder="🔍  Filtrar por nome, código ou valor..." autocomplete="off"
              autofocus oninput="filtrarProdutos(this.value)">
          </div>
          <button class="btn-scan" onclick="openBarcodeCamera(onBarcodeDetected)" id="btnCameraMain">
            <span class="scan-icon">📷</span>
            Escanear Código de Barras
          </button>
        </div>

        <!-- Grade de produtos -->
        <div class="prod-grid" id="prod-grid">
          <?php if (empty($produtos)): ?>
            <div class="empty-grid"><span>📦</span>
              <p>Nenhum produto cadastrado ainda.</p>
            </div>
          <?php else: ?>
            <?php foreach ($produtos as $p): ?>
              <div class="prod-card <?= $p['estoque'] <= 0 ? 'sem-estoque' : '' ?>" id="pcard-<?= $p['id'] ?>"
                data-id="<?= $p['id'] ?>" data-nome="<?= htmlspecialchars($p['nome'], ENT_QUOTES) ?>"
                data-valor="<?= $p['valor'] ?>" data-estoque="<?= $p['estoque'] ?>"
                data-search="<?= strtolower($p['nome'] . ' ' . ($p['codigo_barras'] ?? '') . ' ' . $p['valor']) ?>"
                onclick="addFromCard(this)">
                <span class="pc-qty-badge" id="badge-<?= $p['id'] ?>">0</span>
                <div class="pc-add">+</div>
                <div class="pc-nome"><?= htmlspecialchars($p['nome']) ?></div>
                <div class="pc-valor">R$ <?= number_format($p['valor'], 2, ',', '.') ?></div>
                <div class="pc-estoque" style="font-weight: 700;">
                  <?php if ($p['estoque'] > 5): ?>
                    <span style="color: var(--success);">Estoque: <?= $p['estoque'] ?></span>
                  <?php elseif ($p['estoque'] > 0): ?>
                    <span style="color: var(--warning);">Estoque: <?= $p['estoque'] ?> (Baixo)</span>
                  <?php else: ?>
                    <span style="color: var(--danger);">⚠️ Sem estoque</span>
                  <?php endif; ?>
                </div>
                <?php if ($p['codigo_barras']): ?>
                  <div class="pc-cod">🔖 <?= htmlspecialchars($p['codigo_barras']) ?></div>
                <?php endif; ?>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>

      <!-- PAINEL DIREITO: CARRINHO + MESAS -->
      <div class="carrinho-panel">
        
        <!-- Cabeçalho com Abas Premium -->
        <div class="panel-header" style="flex-direction: column; gap: 0.65rem; align-items: stretch; padding: 0.75rem;">
          <div class="tab-switcher">
            <button id="tab-venda-direta" class="tab-btn active" onclick="switchVendaMode('direct')">🛒 Venda Direta</button>
            <button id="tab-mesas" class="tab-btn" onclick="switchVendaMode('table')">🪑 Mesas</button>
          </div>
          <div style="display: flex; justify-content: space-between; align-items: center;">
            <span class="panel-title" id="panel-title-text">🛒 Carrinho</span>
            <span id="cart-count" class="badge badge-neutral">0 itens</span>
          </div>
        </div>

        <!-- Banner de volta para comanda de mesa -->
        <div id="table-back-banner" class="table-back-banner" style="display: none;">
          <button class="btn btn-ghost btn-xs" onclick="voltarParaListaMesas()" style="padding: 3px 8px; font-size: 0.7rem; font-weight: 700; display: flex; align-items: center; gap: 0.3rem;">
            <span>←</span> Voltar para Mesas
          </button>
          <span class="autosave-badge">⚡ Auto-salvando</span>
        </div>

        <!-- Carrinho de Compras padrão -->
        <div id="cart-items" class="cart-items">
          <div class="empty-state" id="cart-empty">
            <span class="empty-icon">🛒</span>
            <p>Clique em um produto para adicionar.</p>
          </div>
        </div>

        <!-- Container da Lista de Mesas -->
        <div id="mesas-list-container" class="cart-items" style="display: none; padding: 0.75rem; overflow-y: auto;">
          <button class="btn btn-primary btn-sm" onclick="openAddMesaModal()" style="width: 100%; margin-bottom: 1rem; font-weight: 800; font-size: 0.8rem; display: flex; align-items: center; justify-content: center; gap: 0.4rem; height: 36px; border-radius: 8px;">
            <span>➕</span> Adicionar Nova Mesa
          </button>
          <div id="mesas-grid" style="display: flex; flex-direction: column; gap: 0.65rem;">
            <!-- Mesas serão injetadas dinamicamente aqui -->
          </div>
        </div>

        <!-- Rodapé do Carrinho -->
        <div class="cart-footer">
          <div class="cart-total">
            <span class="label">Total</span>
            <span class="value" id="cart-total">R$ 0,00</span>
          </div>
          <div class="cart-actions">
            <button class="btn btn-danger" onclick="cancelarVenda()">✕ Cancelar</button>
            <button class="btn btn-success" onclick="finalizarVenda()">✅ Finalizar</button>
          </div>
        </div>
      </div>
    </div>

  <?php endif; ?>
</div>
</div>
</div>

<!-- MODAL CÂMERA -->
<div class="modal-overlay" id="modal-camera">
  <div class="modal" style="max-width:460px;">
    <div class="modal-header">
      <span class="modal-title">📷 Leitor de Código de Barras</span>
      <button class="modal-close" onclick="closeBarcodeCamera()">×</button>
    </div>
    <div class="modal-body" style="padding:1rem;">
      <div style="position:relative;background:#000;border-radius:10px;overflow:hidden;aspect-ratio:4/3;">
        <video id="barcode-video" playsinline muted
          style="width:100%;height:100%;object-fit:cover;display:block;"></video>
        <div
          style="position:absolute;left:10%;right:10%;top:50%;height:2px;background:rgba(251,146,60,.8);box-shadow:0 0 8px var(--accent);animation:scanLine 2s linear infinite;">
        </div>
      </div>
      <p id="barcode-status" style="text-align:center;margin-top:.75rem;font-size:.85rem;color:#93c5fd;">Iniciando
        câmera...</p>
      <div style="margin-top:1rem;">
        <label class="form-label">Ou digite o código manualmente:</label>
        <div style="display:flex;gap:.5rem;">
          <input type="text" id="manual-code" class="form-control" placeholder="Ex: 7891000315507"
            onkeydown="if(event.key==='Enter') manualBarcode()">
          <button class="btn btn-primary" onclick="manualBarcode()">OK</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL ADICIONAR MESA -->
<div class="modal-overlay" id="modal-adicionar-mesa">
  <div class="modal" style="max-width:380px;">
    <div class="modal-header">
      <span class="modal-title">🪑 Adicionar Nova Mesa</span>
      <button class="modal-close" onclick="closeModal('modal-adicionar-mesa')">×</button>
    </div>
    <div class="modal-body" style="padding: 1.25rem;">
      <form id="form-adicionar-mesa" onsubmit="criarNovaMesa(event)">
        <div class="form-group" style="margin-bottom:0;">
          <label class="form-label" style="font-weight: 700; margin-bottom: 0.5rem;">Identificação da Mesa / Comanda</label>
          <input type="text" id="nova-mesa-nome" class="form-control" placeholder="Ex: Mesa 1, Balcão A, Comanda 12" required autocomplete="off">
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-adicionar-mesa')">Cancelar</button>
      <button class="btn btn-primary" onclick="document.getElementById('form-adicionar-mesa').requestSubmit()">Abrir Mesa</button>
    </div>
  </div>
</div>

<!-- MODAL CONFIRMAR VENDA -->
<div class="modal-overlay" id="modal-confirmar">
  <div class="modal" style="max-width:400px;">
    <div class="modal-header">
      <span class="modal-title">✅ Confirmar Venda</span>
      <button class="modal-close" onclick="closeModal('modal-confirmar')">×</button>
    </div>
    <div class="modal-body" style="text-align:center;">
      <span style="font-size:3rem;display:block;margin-bottom:1rem;">💰</span>
      <p style="color:var(--text-secondary);">Total da venda:</p>
      <p style="font-size:2.5rem;font-weight:800;color:var(--accent);" id="confirm-total">R$ 0,00</p>
      <p style="font-size:.85rem;color:var(--text-muted);margin-top:.5rem;" id="confirm-itens"></p>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-confirmar')">Voltar</button>
      <button class="btn btn-success btn-lg" id="btnConfirmarFinal" onclick="confirmarFinalizacao()">✅
        Confirmar</button>
    </div>
  </div>
</div>

<!-- MODAL FECHAR CAIXA -->
<div class="modal-overlay" id="modal-fechar">
  <div class="modal" style="max-width:420px;">
    <div class="modal-header">
      <span class="modal-title">🔒 Fechar Caixa</span>
      <button class="modal-close" onclick="closeModal('modal-fechar')">×</button>
    </div>
    <div class="modal-body" style="text-align:center;">
      <span style="font-size:2.5rem;display:block;margin-bottom:.5rem;">⚠️</span>
      <p style="color:var(--text-secondary);margin-bottom:.75rem;">Tem certeza que deseja fechar o caixa do dia?</p>

      <form id="form-fechar-caixa"
        style="margin-top:1.5rem; text-align:left; border-top:1px solid var(--border); padding-top:1rem;">
        <div class="form-label" style="margin-bottom:1rem; color:var(--accent);">⛽ Conferência de Caixa</div>

        <div class="form-group"
          style="background:rgba(255,255,255,0.03); padding:.75rem; border-radius:8px; border:1px solid var(--border); margin-bottom:1.5rem;">
          <label class="form-label" style="color:var(--success);">💵 Total em Dinheiro (Físico no Caixa)</label>
          <input name="dinheiro_final" type="text" class="form-control mask-money" placeholder="0,00" required>
          <small class="text-muted">Conte todo o dinheiro em espécie que está na gaveta.</small>
        </div>

        <?php if (!empty($combustiveisNoCaixa)): ?>
          <?php foreach ($combustiveisNoCaixa as $cb): ?>
            <div class="form-group">
              <label class="form-label" style="font-size:.8rem;"><?= htmlspecialchars($cb['nome']) ?></label>
              <div style="display:grid; grid-template-columns:1fr; gap:.5rem;">
                <div>
                  <label style="font-size:.65rem; color:var(--accent); font-weight: bold;">Litros Vendidos (L)</label>
                  <input name="litros_vendidos_<?= $cb['id'] ?>" type="number" step="0.01" min="0" class="form-control"
                    placeholder="Ex: 1470.2" required>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        <?php endif; ?>
      </form>

      <p style="font-size:.85rem;color:var(--text-muted); margin-top:1rem;">O comprovante será gerado automaticamente.
      </p>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-fechar')">Cancelar</button>
      <button class="btn btn-danger" onclick="fecharCaixa()">🔒 Confirmar Fechamento</button>
    </div>
  </div>
</div>

<!-- MODAL LANÇAMENTO AVULSO -->
<div class="modal-overlay" id="modal-lancamento">
  <div class="modal" style="max-width:420px;">
    <div class="modal-header">
      <span class="modal-title">💳 Lançar Pix / Cielo</span>
      <button class="modal-close" onclick="closeModal('modal-lancamento')">×</button>
    </div>
    <div class="modal-body">
      <form id="form-lancamento" onsubmit="salvarLancamento(event)">
        <div class="form-group">
          <label class="form-label">Tipo de Recebimento</label>
          <select name="tipo" class="form-control" required
            style="background:var(--bg-input); color:var(--text-primary);">
            <option value="">-- Selecione --</option>
            <option value="pix">PIX</option>
            <option value="cielo">CIELO (Cartão)</option>
            <option value="vale">VALE (Voucher)</option>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Valor (R$)</label>
          <input name="valor" type="text" class="form-control mask-money" placeholder="0,00" required>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-lancamento')">Cancelar</button>
      <button class="btn btn-primary" onclick="document.getElementById('form-lancamento').requestSubmit()">Adicionar
        Lançamento</button>
    </div>
  </div>
</div>

<!-- MODAL ESTOQUE COMBUSTÍVEL -->
<div class="modal-overlay" id="modal-estoque-combustivel">
  <div class="modal" style="max-width:420px;">
    <div class="modal-header">
      <span class="modal-title">⛽ Estoque de Combustível</span>
      <button class="modal-close" onclick="closeModal('modal-estoque-combustivel')">×</button>
    </div>
    <div class="modal-body">
      <?php if (!empty($combustiveisNoCaixa)): ?>
        <div style="display: flex; flex-direction: column; gap: 1rem;">
          <?php foreach ($combustiveisNoCaixa as $cb): ?>
            <div style="background: var(--bg-card); border: 1px solid var(--border); border-radius: 12px; padding: 1.25rem; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
              <div style="font-size: 1rem; font-weight: 800; color: var(--text-primary); margin-bottom: 0.75rem; border-bottom: 1px solid var(--border); padding-bottom: 0.5rem; display: flex; align-items: center; gap: 0.5rem;">
                <span>⛽</span> <?= htmlspecialchars($cb['nome']) ?>
              </div>
              <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 1rem;">
                <div>
                  <div style="font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.25rem;">Volume</div>
                  <div style="font-size: 1.2rem; font-weight: 800; color: var(--accent);"><?= number_format($cb['litragem_inicial'], 2, ',', '.') ?> L</div>
                </div>
                <div>
                  <div style="font-size: 0.7rem; color: var(--text-muted); text-transform: uppercase; margin-bottom: 0.25rem;">Altura</div>
                  <div style="font-size: 1.2rem; font-weight: 800; color: var(--text-primary);"><?= number_format($cb['altura_inicial'], 2, ',', '.') ?> cm</div>
                </div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>
      <?php else: ?>
        <div class="empty-state">
          <span class="empty-icon">⛽</span>
          <p>Nenhum dado de combustível para este turno.</p>
        </div>
      <?php endif; ?>
    </div>
    <div class="modal-footer">
      <button class="btn btn-primary" style="width: 100%;" onclick="closeModal('modal-estoque-combustivel')">Fechar</button>
    </div>
  </div>
</div>

<!-- MODAL FORMA DE PAGAMENTO (VENDA PRODUTOS) -->
<div class="modal-overlay" id="modal-pagamento-venda">
  <div class="modal" style="max-width:400px;">
    <div class="modal-header">
      <span class="modal-title">💰 Pagamento Misto / Detalhado</span>
      <button class="modal-close" onclick="closeModal('modal-pagamento-venda')">×</button>
    </div>
    <div class="modal-body">
      <div
        style="background:rgba(255,255,255,0.05); padding:1rem; border-radius:8px; margin-bottom:1.5rem; text-align:center; border:1px solid var(--border);">
        <div style="font-size:.8rem; color:var(--text-muted);">TOTAL DA VENDA</div>
        <div style="font-size:1.8rem; font-weight:800; color:var(--accent);" id="pago-total-venda">R$ 0,00</div>
        <div style="font-size:.85rem; margin-top:.5rem; font-weight:600;" id="pago-restante-container">
          <span id="pago-restante-status">Faltam:</span>
          <span id="pago-restante" style="color:var(--danger);">R$ 0,00</span>
        </div>
      </div>

      <form id="form-pagamento-misto">
        <div class="form-group"
          style="background:rgba(251,146,60,0.08); padding:.75rem; border-radius:8px; border:1px solid var(--accent); margin-bottom:1.5rem;">
          <label class="form-label" style="color:var(--accent); display:flex; align-items:center; gap:.4rem;">
            ⛽ Combustível (R$)
          </label>
          <input type="text" name="v_extra_combustivel" id="v_extra_combustivel" class="form-control mask-money"
            placeholder="0,00" style="border-color:var(--accent);" oninput="calcularRestantePagamento()">
          <small style="color:var(--text-muted); font-size:.7rem;">O valor digitado aqui será lançado como combustível
            avulso.</small>
        </div>

        <div class="form-group">
          <label class="form-label">💵 Dinheiro</label>
          <input type="text" name="v_dinheiro" class="form-control input-pago mask-money" placeholder="0,00"
            oninput="calcularRestantePagamento()">
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">📱 Pix</label>
            <input type="text" name="v_pix" class="form-control input-pago mask-money" placeholder="0,00"
              oninput="calcularRestantePagamento()">
          </div>
          <div class="form-group">
            <label class="form-label">💳 Cielo (Cartão)</label>
            <input type="text" name="v_cielo" class="form-control input-pago mask-money" placeholder="0,00"
              oninput="calcularRestantePagamento()">
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">🎟️ Vale (Voucher)</label>
          <input type="text" name="v_vale" class="form-control input-pago mask-money" placeholder="0,00"
            oninput="calcularRestantePagamento()">
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-pagamento-venda')">Cancelar</button>
      <button class="btn btn-primary" id="btnConfirmarMisto" onclick="finalizarVendaMista()" disabled>Finalizar
        Venda</button>
    </div>
  </div>
</div>

<script>
  const configVendaDetalhada = <?= json_encode($configCaixa['vendas_pagamento_detalhado'] ?? false) ?>;
</script>
<script src="/assets/js/main.js?v=<?= time() ?>"></script>
<script src="/assets/js/barcode.js?v=<?= time() ?>"></script>
<script>
  let cart = [];
  let caixaId = <?= $caixa ? (int) $caixa['id'] : 0 ?>;

  // Estado do Sistema de Mesas
  let activeMode = 'direct'; // 'direct' ou 'table'
  let activeTableId = null;
  let activeTableName = '';
  let directCart = []; // Rascunho do carrinho do balcão (venda direta)

  // ── FILTRO ──────────────────────────────────────
  function filtrarProdutos(q) {
    q = q.toLowerCase().trim();
    document.querySelectorAll('.prod-card').forEach(card => {
      const match = !q || card.dataset.search.includes(q);
      card.style.display = match ? '' : 'none';
    });
  }

  // ── CÂMERA CALLBACK ─────────────────────────────
  function onBarcodeDetected(code) {
    const input = document.getElementById('searchInput');
    input.value = code;
    filtrarProdutos(code);
    // tenta adicionar automaticamente se só houver 1 resultado
    const visibles = [...document.querySelectorAll('.prod-card')].filter(c => c.style.display !== 'none');
    if (visibles.length === 1) {
      visibles[0].click();
      showToast('Produto adicionado via câmera!', 'success');
    }
  }

  function manualBarcode() {
    const code = document.getElementById('manual-code').value.trim();
    if (!code) return;
    closeBarcodeCamera();
    onBarcodeDetected(code);
  }

  // ── ADICIONAR DO CARD ───────────────────────────
  function addFromCard(card) {
    const id = parseInt(card.dataset.id);
    const nome = card.dataset.nome;
    const valor = parseFloat(card.dataset.valor);
    const estoque = parseInt(card.dataset.estoque);
    adicionarProduto(id, nome, valor, estoque);

    // feedback visual no card
    card.classList.add('flash');
    setTimeout(() => card.classList.remove('flash'), 350);
  }

  // ── CARRINHO ────────────────────────────────────
  function adicionarProduto(id, nome, valor, estoque) {
    if (estoque <= 0) { showToast('Produto sem estoque!', 'error'); return; }
    const idx = cart.findIndex(i => i.id === id);
    if (idx >= 0) {
      if (cart[idx].quantidade >= estoque) { showToast('Estoque insuficiente!', 'error'); return; }
      cart[idx].quantidade++;
    } else {
      cart.push({ id, nome, valor, quantidade: 1, estoque });
    }
    renderCart();
    updateCardBadges();
    if (activeMode === 'table' && activeTableId !== null) {
      salvarItensMesaNoBanco();
    }
  }

  function alterarQtd(id, delta) {
    const idx = cart.findIndex(i => i.id === id);
    if (idx < 0) return;
    cart[idx].quantidade += delta;
    if (cart[idx].quantidade <= 0) cart.splice(idx, 1);
    else if (cart[idx].quantidade > cart[idx].estoque) {
      cart[idx].quantidade = cart[idx].estoque;
      showToast('Estoque máximo atingido!', 'warning');
    }
    renderCart();
    updateCardBadges();
    if (activeMode === 'table' && activeTableId !== null) {
      salvarItensMesaNoBanco();
    }
  }

  function removerItem(id) {
    cart = cart.filter(i => i.id !== id);
    renderCart();
    updateCardBadges();
    if (activeMode === 'table' && activeTableId !== null) {
      salvarItensMesaNoBanco();
    }
  }

  function updateCardBadges() {
    // Limpa todos primeiro
    document.querySelectorAll('.prod-card').forEach(c => {
      c.classList.remove('in-cart');
      const badge = c.querySelector('.pc-qty-badge');
      if (badge) badge.textContent = '0';
    });
    // Marca os que estão no carrinho
    cart.forEach(item => {
      const card = document.getElementById('pcard-' + item.id);
      const badge = document.getElementById('badge-' + item.id);
      if (card) card.classList.add('in-cart');
      if (badge) badge.textContent = item.quantidade;
    });
  }

  function renderCart() {
    const container = document.getElementById('cart-items');
    const countBadge = document.getElementById('cart-count');
    const totalEl = document.getElementById('cart-total');

    const total = cart.reduce((s, i) => s + i.valor * i.quantidade, 0);
    const count = cart.reduce((s, i) => s + i.quantidade, 0);

    countBadge.textContent = `${count} ${count === 1 ? 'item' : 'itens'}`;
    totalEl.textContent = formatBRL(total);

    if (!cart.length) {
      container.innerHTML = `<div class="empty-state" id="cart-empty">
      <span class="empty-icon">🛒</span><p>Clique em um produto para adicionar.</p></div>`;
      return;
    }

    container.innerHTML = cart.map(item => `
    <div class="cart-item">
      <div class="item-info">
        <div class="item-nome">${item.nome}</div>
        <div class="item-preco">${formatBRL(item.valor)} / unid.</div>
      </div>
      <div class="qty-control">
        <button class="qty-btn" onclick="alterarQtd(${item.id},-1)">−</button>
        <span class="qty-num">${item.quantidade}</span>
        <button class="qty-btn" onclick="alterarQtd(${item.id},+1)">+</button>
      </div>
      <span class="item-subtotal">${formatBRL(item.valor * item.quantidade)}</span>
      <button class="item-remove" onclick="removerItem(${item.id})" title="Remover">✕</button>
    </div>
  `).join('');
  }

  // ── FINALIZAR ───────────────────────────────────
  function finalizarVenda() {
    if (cart.length === 0) return;
    const total = cart.reduce((s, i) => s + i.valor * i.quantidade, 0);
    const count = cart.reduce((s, i) => s + i.quantidade, 0);

    if (configVendaDetalhada) {
      document.getElementById('pago-total-venda').textContent = formatBRL(total);
      document.getElementById('v_extra_combustivel').value = '';
      document.getElementById('form-pagamento-misto').reset();
      calcularRestantePagamento();
      openModal('modal-pagamento-venda');
    } else {
      document.getElementById('confirm-total').textContent = formatBRL(total);
      document.getElementById('confirm-itens').textContent = `${cart.length} produto(s) — ${count} unidade(s)`;
      openModal('modal-confirmar');
    }
  }

  async function confirmarFinalizacao() {
    const total = cart.reduce((s, i) => s + i.valor * i.quantidade, 0);
    executarFinalizacao({ dinheiro: total });
  }

  function calcularRestantePagamento() {
    // Pequeno delay para garantir que a máscara de dinheiro já processou o input
    setTimeout(() => {
      const totalProdutos = cart.reduce((s, i) => s + i.valor * i.quantidade, 0);
      const extraCombustivel = parseBRL(document.getElementById('v_extra_combustivel').value || '0');
      const totalGeral = totalProdutos + extraCombustivel;

      const inputs = document.querySelectorAll('.input-pago');
      let pago = 0;
      inputs.forEach(i => {
        pago += parseBRL(i.value);
      });

      const restante = totalGeral - pago;
      const elRestante = document.getElementById('pago-restante');
      const elStatus = document.getElementById('pago-restante-status');
      const btn = document.getElementById('btnConfirmarMisto');

      if (!elRestante) return;

      if (Math.abs(restante) < 0.01) {
        elRestante.textContent = 'R$ 0,00';
        elStatus.innerHTML = '✅ Valor Total Atingido!';
        elStatus.style.color = 'var(--success)';
        btn.disabled = false;
      } else if (restante > 0) {
        elRestante.textContent = formatBRL(restante);
        elStatus.innerHTML = 'Faltam:';
        elStatus.style.color = 'var(--danger)';
        btn.disabled = true;
      } else {
        elRestante.textContent = formatBRL(Math.abs(restante));
        elStatus.innerHTML = 'Passando (Troco):';
        elStatus.style.color = 'var(--warning)';
        btn.disabled = false;
      }
    }, 10);
  }

  async function finalizarVendaMista() {
    const form = document.getElementById('form-pagamento-misto');
    const fd = new FormData(form);
    let vExtra = parseBRL(fd.get('v_extra_combustivel'));

    let vDin = parseBRL(fd.get('v_dinheiro'));
    let vPix = parseBRL(fd.get('v_pix'));
    let vCie = parseBRL(fd.get('v_cielo'));
    let vVal = parseBRL(fd.get('v_vale'));

    // Determina o tipo de pagamento que foi usado para o combustível extra ANTES de subtrair
    let extraTipo = 'dinheiro';
    let extraRestante = vExtra;

    if (extraRestante > 0 && vPix > 0) {
      extraTipo = 'pix';
      if (vPix >= extraRestante) { vPix -= extraRestante; extraRestante = 0; }
      else { extraRestante -= vPix; vPix = 0; }
    }

    if (extraRestante > 0 && vCie > 0) {
      extraTipo = 'cielo';
      if (vCie >= extraRestante) { vCie -= extraRestante; extraRestante = 0; }
      else { extraRestante -= vCie; vCie = 0; }
    }

    if (extraRestante > 0 && vVal > 0) {
      extraTipo = 'vale';
      if (vVal >= extraRestante) { vVal -= extraRestante; extraRestante = 0; }
      else { extraRestante -= vVal; vVal = 0; }
    }

    if (extraRestante > 0 && vDin > 0) {
      extraTipo = 'dinheiro';
      if (vDin >= extraRestante) { vDin -= extraRestante; extraRestante = 0; }
      else { extraRestante -= vDin; vDin = 0; }
    }

    const pagamentos = {
      dinheiro: vDin,
      pix: vPix,
      cielo: vCie,
      vale: vVal,
      v_extra_combustivel: vExtra,
      v_extra_combustivel_tipo: extraTipo
    };

    closeModal('modal-pagamento-venda');
    executarFinalizacao(pagamentos);
  }

  async function executarFinalizacao(pagamentos) {
    const btn = document.getElementById('btnConfirmarFinal');
    if (btn) { btn.disabled = true; btn.textContent = 'Finalizando...'; }

    try {
      const resp = await fetch('/usuario/ajax/finalizar_venda.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          caixa_id: caixaId,
          itens: cart,
          pagamentos: pagamentos,
          mesa_id: (activeMode === 'table' ? activeTableId : 0)
        }),
      });
      const data = await resp.json();
      if (data.ok) {
        closeModal('modal-confirmar');
        cart = [];
        renderCart();
        updateCardBadges();
        document.getElementById('searchInput').value = '';
        filtrarProdutos('');
        showToast(`Venda #${data.venda_id} finalizada!`, 'success', 4000);
        refreshContent(['#total-vendas-hoje', '#resumo-financeiro', '#prod-grid']);
        
        if (activeMode === 'table') {
            activeTableId = null;
            activeTableName = '';
            switchVendaMode('table');
        }
      } else {
        showToast(data.msg || 'Erro ao finalizar.', 'error');
      }
    } catch (e) { showToast('Erro de comunicação.', 'error'); }
    btn.disabled = false; btn.textContent = '✅ Confirmar';
  }

  // ── SISTEMA DE MESAS (LÓGICA) ──────────────────
  async function switchVendaMode(mode) {
    if (mode === 'direct') {
      if (activeMode === 'table' && activeTableId !== null) {
          await salvarItensMesaNoBanco();
      }
      activeMode = 'direct';
      activeTableId = null;
      activeTableName = '';
      
      cart = directCart;
      
      document.getElementById('tab-venda-direta').classList.add('active');
      document.getElementById('tab-mesas').classList.remove('active');
      
      document.getElementById('table-back-banner').style.display = 'none';
      document.getElementById('mesas-list-container').style.display = 'none';
      document.getElementById('cart-items').style.display = 'block';
      document.querySelector('.cart-footer').style.display = 'block';
      document.getElementById('panel-title-text').textContent = '🛒 Carrinho';
      
      renderCart();
      updateCardBadges();
    } else if (mode === 'table') {
      if (activeMode === 'direct') {
          directCart = cart;
      }
      
      activeMode = 'table';
      
      document.getElementById('tab-venda-direta').classList.remove('active');
      document.getElementById('tab-mesas').classList.add('active');
      
      if (activeTableId === null) {
          document.getElementById('table-back-banner').style.display = 'none';
          document.getElementById('cart-items').style.display = 'none';
          document.querySelector('.cart-footer').style.display = 'none';
          document.getElementById('mesas-list-container').style.display = 'block';
          document.getElementById('panel-title-text').textContent = '🪑 Mesas Ativas';
          
          await carregarMesasAtivas();
          cart = [];
          updateCardBadges();
      } else {
          document.getElementById('mesas-list-container').style.display = 'none';
          document.getElementById('table-back-banner').style.display = 'flex';
          document.getElementById('cart-items').style.display = 'block';
          document.querySelector('.cart-footer').style.display = 'block';
          document.getElementById('panel-title-text').textContent = `🪑 ${activeTableName}`;
          
          renderCart();
          updateCardBadges();
      }
    }
  }

  function openAddMesaModal() {
      document.getElementById('nova-mesa-nome').value = '';
      openModal('modal-adicionar-mesa');
      setTimeout(() => document.getElementById('nova-mesa-nome').focus(), 300);
  }

  async function criarNovaMesa(e) {
      e.preventDefault();
      const nome = document.getElementById('nova-mesa-nome').value.trim();
      if (!nome) return;
      
      showSpinner('Criando mesa...');
      try {
          const resp = await postJSON('/usuario/ajax/mesas.php', {
              action: 'criar',
              caixa_id: caixaId,
              nome: nome
          });
          hideSpinner();
          if (resp.ok) {
              closeModal('modal-adicionar-mesa');
              showToast(`Mesa ${nome} aberta com sucesso!`, 'success');
              atenderMesa(resp.mesa_id, nome);
          } else {
              showToast(resp.msg || 'Erro ao criar mesa.', 'error');
          }
      } catch (err) {
          hideSpinner();
          showToast('Erro de comunicação.', 'error');
      }
  }

  async function carregarMesasAtivas() {
      const container = document.getElementById('mesas-grid');
      try {
          const resp = await fetch(`/usuario/ajax/mesas.php?action=listar&caixa_id=${caixaId}`);
          const data = await resp.json();
          if (data.ok) {
              if (data.mesas.length === 0) {
                  container.innerHTML = `
                      <div class="empty-state">
                          <span class="empty-icon">🪑</span>
                          <p>Nenhuma mesa ativa no momento.</p>
                      </div>
                  `;
                  return;
              }
              
              container.innerHTML = data.mesas.map(m => `
                  <div class="mesa-card">
                      <div style="display: flex; justify-content: space-between; align-items: center;">
                          <span class="mesa-nome">🪑 ${m.nome}</span>
                          <span class="badge ${m.total_itens > 0 ? 'badge-primary' : 'badge-neutral'}" style="font-size: 0.65rem;">
                              ${m.total_itens} ${m.total_itens === 1 ? 'item' : 'itens'}
                          </span>
                      </div>
                      <div class="mesa-footer">
                          <span class="mesa-total">${formatBRL(m.total_valor)}</span>
                          <div style="display: flex; gap: 0.4rem;">
                              <button class="btn btn-ghost btn-xs" onclick="cancelarMesa(${m.id}, '${m.nome}')" title="Cancelar mesa" style="color: var(--danger); padding: 2px 6px;">🗑️</button>
                              <button class="btn btn-primary btn-xs" onclick="atenderMesa(${m.id}, '${m.nome}')" style="padding: 2px 8px; font-size: 0.7rem; font-weight: 800;">Atender</button>
                          </div>
                      </div>
                  </div>
              `).join('');
          } else {
              showToast(data.msg || 'Erro ao carregar mesas.', 'error');
          }
      } catch (err) {
          container.innerHTML = `<p style="text-align:center; color: var(--danger); font-size:0.8rem;">Erro ao carregar mesas.</p>`;
      }
  }

  async function atenderMesa(id, nome) {
      showSpinner(`Carregando ${nome}...`);
      try {
          const resp = await fetch(`/usuario/ajax/mesas.php?action=obter&caixa_id=${caixaId}&mesa_id=${id}`);
          const data = await resp.json();
          hideSpinner();
          if (data.ok) {
              activeTableId = id;
              activeTableName = nome;
              cart = data.itens;
              
              switchVendaMode('table');
          } else {
              showToast(data.msg || 'Erro ao carregar comanda.', 'error');
          }
      } catch (err) {
          hideSpinner();
          showToast('Erro de comunicação.', 'error');
      }
  }

  async function voltarParaListaMesas() {
      if (activeTableId !== null) {
          await salvarItensMesaNoBanco();
      }
      activeTableId = null;
      activeTableName = '';
      switchVendaMode('table');
  }

  async function salvarItensMesaNoBanco() {
      if (activeTableId === null) return;
      try {
          await postJSON('/usuario/ajax/mesas.php', {
              action: 'salvar_itens',
              caixa_id: caixaId,
              mesa_id: activeTableId,
              itens: cart
          });
      } catch (err) {
          console.error("Erro ao salvar comanda no banco:", err);
      }
  }

  function cancelarMesa(id, nome) {
      confirmDelete(`Deseja realmente cancelar a comanda da ${nome}? Isso apagará todos os produtos dela permanentemente.`, async () => {
          showSpinner('Cancelando comanda...');
          try {
              const resp = await postJSON('/usuario/ajax/mesas.php', {
                  action: 'excluir',
                  caixa_id: caixaId,
                  mesa_id: id
              });
              hideSpinner();
              if (resp.ok) {
                  showToast(`${nome} cancelada com sucesso!`, 'success');
                  carregarMesasAtivas();
              } else {
                  showToast(resp.msg || 'Erro ao excluir mesa.', 'error');
              }
          } catch (err) {
              hideSpinner();
              showToast('Erro de comunicação.', 'error');
          }
      });
  }

  // ── CANCELAR ────────────────────────────────────
  function cancelarVenda() {
    if (!cart.length) return;
    const msg = activeMode === 'table'
      ? 'Deseja realmente limpar todos os itens da comanda desta mesa?'
      : 'Cancelar a venda e limpar o carrinho?';

    confirmDelete(msg, () => {
      cart = [];
      renderCart();
      updateCardBadges();
      document.getElementById('searchInput').value = '';
      filtrarProdutos('');
      showToast(activeMode === 'table' ? 'Itens da mesa removidos.' : 'Venda cancelada.', 'info');

      if (activeMode === 'table' && activeTableId !== null) {
        salvarItensMesaNoBanco();
      }
    });
  }

  // ── CAIXA ───────────────────────────────────────
  async function fecharCaixa() {
    if (!caixaId) return;
    const form = document.getElementById('form-fechar-caixa');
    if (!form.reportValidity()) {
      showToast('Por favor, preencha todos os campos obrigatórios.', 'warning');
      return;
    }

    showSpinner('Fechando caixa...');
    const formData = serializeForm(form);
    const resp = await postJSON('/administrator/ajax/fechar_caixa.php', {
      acao: 'fechar',
      id: caixaId,
      litragem: formData,
      dinheiro_final: parseBRL(formData.dinheiro_final)
    });
    hideSpinner();
    if (resp.ok) {
      limparProgressoFechamento();
      closeModal('modal-fechar');
      showToast('Caixa fechado com sucesso!', 'success');

      // Diálogo customizado para escolha de comprovante
      setTimeout(() => {
        confirmDelete('Deseja imprimir o comprovante COMPLETO (com itens) ou RESUMIDO?', () => {
          window.open(`/administrator/comprovante.php?id=${caixaId}&mode=completo`, '_blank');
          location.reload();
        });
        // Ajusta texto dos botões do confirmDelete para esta situação específica
        const btnOk = document.getElementById('global-confirm-ok');
        const btnCancel = document.getElementById('global-confirm-cancel');
        if (btnOk) btnOk.textContent = 'Completo';
        if (btnCancel) {
          btnCancel.textContent = 'Resumido';
          btnCancel.classList.remove('btn-ghost');
          btnCancel.classList.add('btn-primary');
          // Como o confirmDelete padrão fecha no cancel, precisamos re-adicionar a lógica
          const newCancel = btnCancel.cloneNode(true);
          btnCancel.replaceWith(newCancel);
          newCancel.addEventListener('click', () => {
            document.getElementById('global-confirm').classList.remove('open');
            window.open(`/administrator/comprovante.php?id=${caixaId}&mode=resumido`, '_blank');
            location.reload();
          });
        }
      }, 500);
    } else showToast(resp.msg || 'Erro ao fechar caixa.', 'error');
  }

  async function salvarLancamento(e) {
    e.preventDefault();
    if (!caixaId) { showToast('Nenhum caixa aberto.', 'error'); return; }
    const data = serializeForm(e.target);
    data.valor = parseBRL(data.valor);
    const resp = await postJSON('/usuario/ajax/salvar_lancamento.php', data);
    if (resp.ok) {
      showToast('Lançamento adicionado com sucesso!', 'success');
      closeModal('modal-lancamento');
      e.target.reset();
      refreshContent(['#resumo-financeiro']);
    } else {
      showToast(resp.msg || 'Erro ao lançar.', 'error');
    }
  }

  // ── PERSISTÊNCIA DO FECHAMENTO (LOCALSTORAGE) ──
  function salvarProgressoFechamento() {
    const form = document.getElementById('form-fechar-caixa');
    if (!form) return;
    const data = serializeForm(form);
    localStorage.setItem('progresso_fechamento', JSON.stringify(data));
  }

  function carregarProgressoFechamento() {
    const salvo = localStorage.getItem('progresso_fechamento');
    const ativo = localStorage.getItem('modal_fechamento_ativo');
    if (!salvo || !ativo) return;

    const data = JSON.parse(salvo);
    const form = document.getElementById('form-fechar-caixa');
    if (!form) return;

    Object.keys(data).forEach(key => {
      const input = form.querySelector(`[name="${key}"]`);
      if (input) input.value = data[key];
    });

    openModal('modal-fechar');
  }

  function limparProgressoFechamento() {
    localStorage.removeItem('progresso_fechamento');
    localStorage.removeItem('modal_fechamento_ativo');
  }

  // Intercepta abertura/fechamento do modal para salvar estado
  const originalOpenModal = window.openModal;
  window.openModal = function (id) {
    if (id === 'modal-fechar') localStorage.setItem('modal_fechamento_ativo', '1');
    originalOpenModal(id);
  };

  const originalCloseModal = window.closeModal;
  window.closeModal = function (id) {
    if (id === 'modal-fechar') localStorage.removeItem('modal_fechamento_ativo');
    originalCloseModal(id);
  };

  // Escuta mudanças nos inputs do fechamento
  document.addEventListener('input', (e) => {
    if (e.target.closest('#form-fechar-caixa')) {
      salvarProgressoFechamento();
    }
  });

  // Carrega ao iniciar
  document.addEventListener('DOMContentLoaded', () => {
    if (caixaId) carregarProgressoFechamento();
  });

  // ── MONITORAMENTO AUTOMÁTICO ────────────────────
  setInterval(async () => {
    try {
      const resp = await fetch('/administrator/ajax/check_status.php');
      const status = await resp.json();

      // 1. Forçar fechamento por horário
      if (status.deve_fechar && caixaId) {
        if (!document.getElementById('modal-fechar').classList.contains('open')) {
          openModal('modal-fechar');
          showToast('🕒 Horário de fechamento atingido!', 'warning', 5000);
          const m = document.getElementById('modal-fechar');
          if (m.querySelector('.modal-close')) m.querySelector('.modal-close').style.display = 'none';
          if (m.querySelector('.btn-ghost')) m.querySelector('.btn-ghost').style.display = 'none';
        }
      }

      // 2. Detectar abertura/fechamento remoto
      if ((status.status === 'aberto' && !caixaId) || (status.status === 'fechado' && caixaId)) {
        // Se abriu ou fechou por fora, recarrega suavemente
        refreshContent(['body']); // Tenta atualizar o body inteiro via AJAX primeiro
        setTimeout(() => location.reload(), 1000); // Recarga real após 1s para garantir integridade
      }
    } catch (e) { }
  }, 15000); // Checa a cada 15 segundos
</script>
<script>
  // Inicializa máscaras
  document.querySelectorAll('.mask-money').forEach(maskMoney);
</script>
</body>

</html>