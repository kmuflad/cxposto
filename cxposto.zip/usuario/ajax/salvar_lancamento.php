<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check(); // Operador ou admin

header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);

$tipo = $input['tipo'] ?? '';
$valor = (float)($input['valor'] ?? 0);

if (!in_array($tipo, ['pix', 'cielo', 'vale'])) {
    echo json_encode(['ok' => false, 'msg' => 'Tipo de lançamento inválido.']);
    exit;
}

if ($valor <= 0) {
    echo json_encode(['ok' => false, 'msg' => 'Valor deve ser maior que zero.']);
    exit;
}

try {
    $db = getDB();
    
    // Pegar caixa aberto
    $caixaAberto = $db->query("SELECT id FROM caixas WHERE status='aberto' LIMIT 1")->fetchColumn();
    if (!$caixaAberto) {
        echo json_encode(['ok' => false, 'msg' => 'Nenhum caixa aberto.']);
        exit;
    }
    
    $operadorId = $_SESSION['usuario_id'];
    // Inserir lançamento
    $stmt = $db->prepare("INSERT INTO lancamentos_avulsos (caixa_id, operador_id, tipo, valor) VALUES (?, ?, ?, ?)");
    $stmt->execute([$caixaAberto, $operadorId, $tipo, $valor]);
    
    echo json_encode(['ok' => true]);

} catch (Exception $e) {
    echo json_encode(['ok' => false, 'msg' => 'Erro interno do servidor.']);
}
