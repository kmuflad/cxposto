<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('operador');

header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$action = $input['action'] ?? $_GET['action'] ?? '';
$caixaId = (int)($input['caixa_id'] ?? $_GET['caixa_id'] ?? 0);

if (!$caixaId) {
    echo json_encode(['ok' => false, 'msg' => 'Caixa não informado.']);
    exit;
}

try {
    $db = getDB();

    switch ($action) {
        case 'listar':
            // Retorna as mesas e calcula o total acumulado e a contagem de itens
            $stmt = $db->prepare("
                SELECT m.id, m.nome, m.criado_em,
                COALESCE(SUM(i.quantidade), 0) as total_itens,
                COALESCE(SUM(i.quantidade * i.valor_unitario), 0) as total_valor
                FROM mesas m
                LEFT JOIN itens_mesa i ON i.mesa_id = m.id
                WHERE m.caixa_id = ?
                GROUP BY m.id
                ORDER BY m.nome ASC
            ");
            $stmt->execute([$caixaId]);
            $mesas = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Converte campos numéricos
            foreach ($mesas as &$m) {
                $m['id'] = (int)$m['id'];
                $m['total_itens'] = (int)$m['total_itens'];
                $m['total_valor'] = (float)$m['total_valor'];
            }

            echo json_encode(['ok' => true, 'mesas' => $mesas]);
            break;

        case 'criar':
            $nome = trim($input['nome'] ?? '');
            if (!$nome) {
                echo json_encode(['ok' => false, 'msg' => 'Nome da mesa é obrigatório.']);
                exit;
            }

            // Verifica se já existe uma mesa com o mesmo nome para este caixa
            $stmt = $db->prepare("SELECT id FROM mesas WHERE caixa_id = ? AND nome = ?");
            $stmt->execute([$caixaId, $nome]);
            if ($stmt->fetch()) {
                echo json_encode(['ok' => false, 'msg' => 'Já existe uma mesa aberta com este nome no seu turno.']);
                exit;
            }

            // Insere a nova mesa
            $stmt = $db->prepare("INSERT INTO mesas (caixa_id, nome) VALUES (?, ?)");
            $stmt->execute([$caixaId, $nome]);
            $mesaId = (int)$db->lastInsertId();

            echo json_encode(['ok' => true, 'mesa_id' => $mesaId, 'nome' => $nome]);
            break;

        case 'obter':
            $mesaId = (int)($input['mesa_id'] ?? $_GET['mesa_id'] ?? 0);
            if (!$mesaId) {
                echo json_encode(['ok' => false, 'msg' => 'ID da mesa não informado.']);
                exit;
            }

            // Busca os itens salvos para a mesa
            $stmt = $db->prepare("
                SELECT i.produto_id as id, p.nome, i.valor_unitario as valor, i.quantidade, p.estoque
                FROM itens_mesa i
                JOIN produtos p ON p.id = i.produto_id
                WHERE i.mesa_id = ?
            ");
            $stmt->execute([$mesaId]);
            $itens = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Normaliza os tipos numéricos
            foreach ($itens as &$it) {
                $it['id'] = (int)$it['id'];
                $it['valor'] = (float)$it['valor'];
                $it['quantidade'] = (int)$it['quantidade'];
                $it['estoque'] = (int)$it['estoque'];
            }

            echo json_encode(['ok' => true, 'itens' => $itens]);
            break;

        case 'salvar_itens':
            $mesaId = (int)($input['mesa_id'] ?? 0);
            $itens = $input['itens'] ?? [];

            if (!$mesaId) {
                echo json_encode(['ok' => false, 'msg' => 'ID da mesa não informado.']);
                exit;
            }

            $db->beginTransaction();

            // Limpa os itens anteriores da mesa
            $stmt = $db->prepare("DELETE FROM itens_mesa WHERE mesa_id = ?");
            $stmt->execute([$mesaId]);

            // Insere a nova lista de itens da comanda
            if (!empty($itens)) {
                $stmtInsert = $db->prepare("
                    INSERT INTO itens_mesa (mesa_id, produto_id, quantidade, valor_unitario)
                    VALUES (?, ?, ?, ?)
                ");
                foreach ($itens as $it) {
                    $prodId = (int)$it['id'];
                    $qtd = (int)$it['quantidade'];
                    $valorUnit = (float)$it['valor'];

                    if ($qtd > 0) {
                        $stmtInsert->execute([$mesaId, $prodId, $qtd, $valorUnit]);
                    }
                }
            }

            $db->commit();
            echo json_encode(['ok' => true, 'msg' => 'Comanda da mesa salva com sucesso.']);
            break;

        case 'excluir':
            $mesaId = (int)($input['mesa_id'] ?? 0);
            if (!$mesaId) {
                echo json_encode(['ok' => false, 'msg' => 'ID da mesa não informado.']);
                exit;
            }

            // Exclui a mesa (os itens são apagados em cascata)
            $stmt = $db->prepare("DELETE FROM mesas WHERE id = ?");
            $stmt->execute([$mesaId]);

            echo json_encode(['ok' => true, 'msg' => 'Mesa cancelada e liberada com sucesso.']);
            break;

        default:
            echo json_encode(['ok' => false, 'msg' => 'Ação inválida.']);
            break;
    }
} catch (Exception $e) {
    if (isset($db) && $db->inTransaction()) {
        $db->rollBack();
    }
    echo json_encode(['ok' => false, 'msg' => 'Erro no servidor: ' . $e->getMessage()]);
}
