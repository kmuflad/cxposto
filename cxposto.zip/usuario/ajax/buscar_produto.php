<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('operador');
header('Content-Type: application/json');

$q = trim($_GET['q'] ?? '');
if (!$q) { echo json_encode([]); exit; }

try {
    $db = getDB();

    // Busca por: código de barras exato | nome parcial | valor aproximado
    $isNumeric = is_numeric(str_replace([',', '.', 'R$', ' '], '', $q));

    if ($isNumeric) {
        // Tenta código de barras primeiro
        $valor = (float) str_replace([',', 'R$', ' '], '', str_replace('.', '', $q));
        $stmt = $db->prepare("
            SELECT id, nome, codigo_barras, valor, estoque
            FROM produtos
            WHERE ativo = 1 AND (
                codigo_barras = :q1
                OR ABS(valor - :val) < 0.01
            )
            ORDER BY (codigo_barras = :q2) DESC, nome ASC
            LIMIT 20
        ");
        $stmt->execute([':q1' => $q, ':val' => $valor, ':q2' => $q]);
    } else {
        $stmt = $db->prepare("
            SELECT id, nome, codigo_barras, valor, estoque
            FROM produtos
            WHERE ativo = 1 AND nome LIKE :q
            ORDER BY nome ASC
            LIMIT 20
        ");
        $stmt->execute([':q' => '%' . $q . '%']);
    }

    $produtos = $stmt->fetchAll();
    echo json_encode($produtos);

} catch (PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
