<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('operador');

header('Content-Type: application/json');

try {
    $db = getDB();
    $stmt = $db->query("SELECT c.* FROM caixas c WHERE c.status='aberto' ORDER BY c.abertura DESC LIMIT 1");
    $caixa = $stmt->fetch();

    if (!$caixa) {
        echo json_encode(['ok' => false, 'msg' => 'Caixa fechado']);
        exit;
    }

    $id = (int) $caixa['id'];
    $resumoTotais = [
        'pix' => $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$id AND tipo='pix') + (SELECT COALESCE(SUM(valor_pix),0) FROM vendas WHERE caixa_id=$id AND status='finalizada')")->fetchColumn(),
        'cielo' => $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$id AND tipo='cielo') + (SELECT COALESCE(SUM(valor_cielo),0) FROM vendas WHERE caixa_id=$id AND status='finalizada')")->fetchColumn(),
        'vale' => $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$id AND tipo='vale') + (SELECT COALESCE(SUM(valor_vale),0) FROM vendas WHERE caixa_id=$id AND status='finalizada') + (SELECT COALESCE(SUM(valor_total),0) FROM vales WHERE caixa_id=$id AND status='ativo')")->fetchColumn()
    ];
    $vendasDinheiro = $db->query("SELECT COALESCE(SUM(valor_dinheiro),0) FROM vendas WHERE caixa_id=$id AND status='finalizada'")->fetchColumn();

    echo json_encode([
        'ok' => true,
        'pix' => (float)$resumoTotais['pix'],
        'cielo' => (float)$resumoTotais['cielo'],
        'vale' => (float)$resumoTotais['vale'],
        'dinheiro' => (float)$vendasDinheiro
    ]);
} catch (Exception $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}
