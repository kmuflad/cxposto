<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('operador');
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$caixaId    = (int)($input['caixa_id'] ?? 0);
$itens      = $input['itens'] ?? [];
$operadorId = (int)$_SESSION['usuario_id'];

if (!$caixaId || !$itens) {
    echo json_encode(['ok' => false, 'msg' => 'Dados inválidos.']);
    exit;
}

try {
    $db = getDB();
    $db->beginTransaction();

    // Valida caixa aberto
    $stmt = $db->prepare("SELECT id FROM caixas WHERE id = ? AND status = 'aberto' LIMIT 1");
    $stmt->execute([$caixaId]);
    if (!$stmt->fetch()) {
        $db->rollBack();
        echo json_encode(['ok' => false, 'msg' => 'Caixa não está aberto.']);
        exit;
    }

    // Calcula total e valida estoque
    $total = 0;
    $itensValidados = [];
    foreach ($itens as $item) {
        $id  = (int)$item['id'];
        $qty = (int)$item['quantidade'];
        if ($id <= 0 || $qty <= 0) continue;

        $stmt = $db->prepare("SELECT id, nome, valor, estoque FROM produtos WHERE id = ? AND ativo = 1 FOR UPDATE");
        $stmt->execute([$id]);
        $produto = $stmt->fetch();

        if (!$produto) { $db->rollBack(); echo json_encode(['ok'=>false,'msg'=>"Produto ID $id não encontrado."]); exit; }
        if ($produto['estoque'] < $qty) {
            $db->rollBack();
            echo json_encode(['ok'=>false,'msg'=>"Estoque insuficiente para: {$produto['nome']}. Disponível: {$produto['estoque']}."]);
            exit;
        }

        $subtotal = $produto['valor'] * $qty;
        $total += $subtotal;
        $itensValidados[] = [
            'id'         => $id,
            'nome'       => $produto['nome'],
            'valor'      => $produto['valor'],
            'quantidade' => $qty,
            'subtotal'   => $subtotal,
        ];
    }

    // Insere venda
    $p = $input['pagamentos'] ?? ['dinheiro' => $total];
    $v_din = (float)($p['dinheiro'] ?? 0);
    $v_pix = (float)($p['pix'] ?? 0);
    $v_cie = (float)($p['cielo'] ?? 0);
    $v_val = (float)($p['vale'] ?? 0);

    $stmt = $db->prepare("INSERT INTO vendas (caixa_id, operador_id, valor_total, valor_dinheiro, valor_pix, valor_cielo, valor_vale, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'finalizada')");
    $stmt->execute([$caixaId, $operadorId, $total, $v_din, $v_pix, $v_cie, $v_val]);
    $vendaId = $db->lastInsertId();

    // Insere itens e baixa estoque
    $stmtItem  = $db->prepare("INSERT INTO itens_venda (venda_id, produto_id, nome_produto, valor_unitario, quantidade, valor_total) VALUES (?,?,?,?,?,?)");
    $stmtStock = $db->prepare("UPDATE produtos SET estoque = estoque - ? WHERE id = ?");
    foreach ($itensValidados as $iv) {
        $stmtItem->execute([$vendaId, $iv['id'], $iv['nome'], $iv['valor'], $iv['quantidade'], $iv['subtotal']]);
        $stmtStock->execute([$iv['quantidade'], $iv['id']]);
    }

    // Soma ao caixa
    $db->prepare("UPDATE caixas SET valor_total = valor_total + ? WHERE id = ?")->execute([$total, $caixaId]);

    // Lançamento Automático de Combustível (se houver v_extra_combustivel)
    $v_ext = (float)($p['v_extra_combustivel'] ?? 0);
    if ($v_ext > 0) {
        // Define o tipo do lançamento com base no tipo explícito enviado pelo frontend
        $tipoExt = $p['v_extra_combustivel_tipo'] ?? 'dinheiro';

        $db->prepare("INSERT INTO lancamentos_avulsos (caixa_id, tipo, valor, descricao, venda_id) VALUES (?, ?, ?, ?, ?)")
           ->execute([$caixaId, $tipoExt, $v_ext, 'Venda de Combustível', $vendaId]);
    }

    // Se a venda veio de uma mesa, removemos a mesa (itens_mesa é deletado via CASCADE)
    $mesaId = (int)($input['mesa_id'] ?? 0);
    if ($mesaId > 0) {
        $db->prepare("DELETE FROM mesas WHERE id = ?")->execute([$mesaId]);
    }

    $db->commit();

    // Enviar notificação para o Telegram
    require_once __DIR__ . '/../../config/telegram_helper.php';
    $configPath = __DIR__ . '/../../config/settings.json';
    $config = file_exists($configPath) ? json_decode(file_get_contents($configPath), true) : [];
    
    $topicId = $config['telegram_topic_vendas'] ?? null;
    $botToken = $config['telegram_bot_token'] ?? null;
    $chatId = $config['telegram_chat_id'] ?? null;

    if ($topicId && $botToken && $chatId) {
        $operadorNome = $_SESSION['usuario_nome'];
        $message = "<b>🛒 Nova Venda de Produtos</b>\n\n";
        $message .= "<pre>------------------------------</pre>\n";
        
        $message .= "<b>Itens:</b>\n";
        foreach ($itensValidados as $iv) {
            $message .= "- " . $iv['quantidade'] . "x " . htmlspecialchars($iv['nome']) . "\n";
        }
        
        $message .= "\n<b>Pagamento:</b>\n";
        if ($v_din > 0) $message .= "- Dinheiro: R$ " . number_format($v_din, 2, ',', '.') . "\n";
        if ($v_pix > 0) $message .= "- Pix: R$ " . number_format($v_pix, 2, ',', '.') . "\n";
        if ($v_cie > 0) $message .= "- Cielo: R$ " . number_format($v_cie, 2, ',', '.') . "\n";
        if ($v_val > 0) $message .= "- Vale: R$ " . number_format($v_val, 2, ',', '.') . "\n";

        $message .= "\n<b>Operador:</b> " . htmlspecialchars($operadorNome) . "\n";
        $message .= "<b>Data:</b> " . date('d/m/Y H:i:s') . "\n";
        $message .= "<b>ID da Venda:</b> <code>#" . $vendaId . "</code>";
        sendTelegramMessage($message, $topicId, $botToken, $chatId);
    }

    echo json_encode(['ok' => true, 'venda_id' => $vendaId, 'total' => $total]);

} catch (PDOException $e) {
    if ($db->inTransaction()) $db->rollBack();
    echo json_encode(['ok' => false, 'msg' => 'Erro interno: ' . $e->getMessage()]);
}
