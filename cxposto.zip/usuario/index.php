<?php
require_once __DIR__ . '/../config/auth_check.php';
auth_check('operador');
header('Location: /usuario/venda.php');
exit;
