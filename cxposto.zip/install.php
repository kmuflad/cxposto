<?php
require_once __DIR__ . '/config/db.php';

$dsn_no_db = "mysql:host=" . DB_HOST . ";charset=" . DB_CHARSET;
$pdo = new PDO($dsn_no_db, DB_USER, DB_PASS, [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
]);

// Cria banco se não existir
$pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
$pdo->exec("USE `" . DB_NAME . "`");

$pdo->exec("
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('admin','operador') NOT NULL DEFAULT 'operador',
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    data_base_escala DATE DEFAULT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// Migrações de colunas faltantes
try {
    $pdo->exec("ALTER TABLE usuarios ADD COLUMN data_base_escala DATE DEFAULT NULL AFTER ativo");
} catch (Exception $e) { /* Coluna já existe */ }

$pdo->exec("
CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    codigo_barras VARCHAR(80) DEFAULT NULL UNIQUE,
    valor DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    estoque INT NOT NULL DEFAULT 0,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$pdo->exec("
CREATE TABLE IF NOT EXISTS caixas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    operador_id INT NOT NULL,
    operador2_id INT DEFAULT NULL,
    abertura DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    fechamento DATETIME DEFAULT NULL,
    valor_abertura DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    valor_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    valor_dinheiro_final DECIMAL(10,2) DEFAULT 0.00,
    status ENUM('aberto','fechado') NOT NULL DEFAULT 'aberto',
    FOREIGN KEY (operador_id) REFERENCES usuarios(id),
    FOREIGN KEY (operador2_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

try {
    // Migração segura para a coluna 'valor_dinheiro_final'
    $check_vdf = $pdo->query("SHOW COLUMNS FROM `caixas` LIKE 'valor_dinheiro_final'");
    if ($check_vdf->rowCount() == 0) {
        $pdo->exec("ALTER TABLE caixas ADD COLUMN valor_dinheiro_final DECIMAL(10,2) DEFAULT 0.00 AFTER valor_total");
    }

    // Migração segura para a coluna 'operador2_id'
    $check_op2 = $pdo->query("SHOW COLUMNS FROM `caixas` LIKE 'operador2_id'");
    if ($check_op2->rowCount() == 0) {
        // Adiciona a coluna e a constraint com um nome único para evitar conflitos.
        $pdo->exec("ALTER TABLE caixas ADD COLUMN operador2_id INT DEFAULT NULL AFTER operador_id, ADD CONSTRAINT `fk_caixas_operador2_id` FOREIGN KEY (`operador2_id`) REFERENCES `usuarios`(`id`)");
    }
} catch (PDOException $e) { /* Ignora erros de migração */ }

$pdo->exec("
CREATE TABLE IF NOT EXISTS vendas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixa_id INT NOT NULL,
    operador_id INT NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    status ENUM('finalizada','cancelada') NOT NULL DEFAULT 'finalizada',
    forma_pagamento ENUM('dinheiro','pix','cielo','vale') NOT NULL DEFAULT 'dinheiro',
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (caixa_id) REFERENCES caixas(id),
    FOREIGN KEY (operador_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

try {
    $pdo->exec("ALTER TABLE vendas ADD COLUMN forma_pagamento ENUM('dinheiro','pix','cielo','vale') NOT NULL DEFAULT 'dinheiro' AFTER valor_total");
} catch (Exception $e) { /* Coluna já existe */ }

// Colunas de pagamento dividido (split payment)
try { $pdo->exec("ALTER TABLE vendas ADD COLUMN valor_dinheiro DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER forma_pagamento"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE vendas ADD COLUMN valor_pix DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER valor_dinheiro"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE vendas ADD COLUMN valor_cielo DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER valor_pix"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE vendas ADD COLUMN valor_vale DECIMAL(10,2) NOT NULL DEFAULT 0.00 AFTER valor_cielo"); } catch (Exception $e) {}

$pdo->exec("
CREATE TABLE IF NOT EXISTS itens_venda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    venda_id INT NOT NULL,
    produto_id INT NOT NULL,
    nome_produto VARCHAR(150) NOT NULL,
    valor_unitario DECIMAL(10,2) NOT NULL,
    quantidade INT NOT NULL DEFAULT 1,
    valor_total DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (venda_id) REFERENCES vendas(id),
    FOREIGN KEY (produto_id) REFERENCES produtos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$pdo->exec("
CREATE TABLE IF NOT EXISTS lancamentos_avulsos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixa_id INT NOT NULL,
    operador_id INT DEFAULT NULL,
    venda_id INT DEFAULT NULL,
    tipo ENUM('pix','cielo','vale','dinheiro') NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    descricao VARCHAR(255) DEFAULT NULL,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (caixa_id) REFERENCES caixas(id),
    FOREIGN KEY (venda_id) REFERENCES vendas(id),
    FOREIGN KEY (operador_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

try { $pdo->exec("ALTER TABLE lancamentos_avulsos ADD COLUMN venda_id INT DEFAULT NULL AFTER caixa_id"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE lancamentos_avulsos ADD COLUMN operador_id INT DEFAULT NULL AFTER caixa_id, ADD CONSTRAINT fk_lancamentos_operador FOREIGN KEY (operador_id) REFERENCES usuarios(id)"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE lancamentos_avulsos ADD COLUMN descricao VARCHAR(255) DEFAULT NULL AFTER valor"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE lancamentos_avulsos MODIFY COLUMN tipo ENUM('pix','cielo','vale','dinheiro') NOT NULL"); } catch (Exception $e) {}


$pdo->exec("
CREATE TABLE IF NOT EXISTS combustiveis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    preco DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    litragem_atual DECIMAL(12,3) NOT NULL DEFAULT 0.000,
    altura_atual DECIMAL(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

try { $pdo->exec("ALTER TABLE combustiveis ADD COLUMN litragem_atual DECIMAL(12,3) NOT NULL DEFAULT 0.000 AFTER preco"); } catch (Exception $e) {}
try { $pdo->exec("ALTER TABLE combustiveis ADD COLUMN altura_atual DECIMAL(10,2) DEFAULT 0.00 AFTER litragem_atual"); } catch (Exception $e) {}

$pdo->exec("
CREATE TABLE IF NOT EXISTS caixa_combustiveis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixa_id INT NOT NULL,
    combustivel_id INT NOT NULL,
    nome VARCHAR(100) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    litragem_inicial DECIMAL(12,3) NOT NULL DEFAULT 0.000,
    altura_inicial DECIMAL(10,2) DEFAULT 0.00,
    litragem_final DECIMAL(12,3) DEFAULT NULL,
    altura_final DECIMAL(10,2) DEFAULT NULL,
    FOREIGN KEY (caixa_id) REFERENCES caixas(id),
    UNIQUE INDEX unique_caixa_comb (caixa_id, combustivel_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// Tabelas do Sistema de Mesas
$pdo->exec("
CREATE TABLE IF NOT EXISTS mesas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixa_id INT NOT NULL,
    nome VARCHAR(50) NOT NULL,
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (caixa_id) REFERENCES caixas(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$pdo->exec("
CREATE TABLE IF NOT EXISTS itens_mesa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mesa_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    valor_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (mesa_id) REFERENCES mesas(id) ON DELETE CASCADE,
    FOREIGN KEY (produto_id) REFERENCES produtos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// Tabelas do Sistema de Vales (Convênio)
$pdo->exec("
CREATE TABLE IF NOT EXISTS clientes_abastecimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    empresa VARCHAR(100) DEFAULT NULL,
    carro VARCHAR(100) DEFAULT NULL,
    placa VARCHAR(20) DEFAULT NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

$pdo->exec("
CREATE TABLE IF NOT EXISTS vales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    caixa_id INT NOT NULL,
    operador_id INT NOT NULL,
    cliente_id INT DEFAULT NULL,
    nome_cliente VARCHAR(100) NOT NULL,
    empresa VARCHAR(100) DEFAULT NULL,
    carro VARCHAR(100) DEFAULT NULL,
    placa VARCHAR(20) DEFAULT NULL,
    km DECIMAL(10,1) DEFAULT NULL,
    combustivel_id INT NOT NULL,
    nome_combustivel VARCHAR(100) NOT NULL,
    preco_combustivel DECIMAL(10,3) NOT NULL,
    tipo_quantidade ENUM('litros','dinheiro') NOT NULL DEFAULT 'litros',
    quantidade DECIMAL(10,2) NOT NULL,
    valor_total DECIMAL(10,2) NOT NULL,
    descricao TEXT DEFAULT NULL,
    status ENUM('ativo','revogado') NOT NULL DEFAULT 'ativo',
    criado_em DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    revogado_em DATETIME DEFAULT NULL,
    revogado_por INT DEFAULT NULL,
    FOREIGN KEY (caixa_id) REFERENCES caixas(id),
    FOREIGN KEY (operador_id) REFERENCES usuarios(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// Tabela de Configurações (para Telegram, etc)
$pdo->exec("
CREATE TABLE IF NOT EXISTS configuracoes (
    `chave` VARCHAR(255) NOT NULL,
    `valor` TEXT,
    PRIMARY KEY (`chave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// Admin padrão
$adminLogin = 'admin';
$adminSenha = password_hash('admin123', PASSWORD_BCRYPT);
$stmt = $pdo->prepare("SELECT id FROM usuarios WHERE login = ?");
$stmt->execute([$adminLogin]);
if (!$stmt->fetch()) {
    $pdo->prepare("INSERT INTO usuarios (nome, login, senha, tipo) VALUES (?, ?, ?, 'admin')")
        ->execute(['Administrador', $adminLogin, $adminSenha]);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Instalação — Convênio Posto</title>
<style>
  body{font-family:monospace;background:#111;color:#0f0;padding:2rem;}
  h1{color:#f90;}
  .ok{color:#0f0;} .err{color:#f44;}
</style>
</head>
<body>
<h1>🔧 Instalação — Convênio Posto</h1>
<p class="ok">✅ Banco de dados criado: <strong><?= DB_NAME ?></strong></p>
<p class="ok">✅ Tabela <strong>usuarios</strong> OK</p>
<p class="ok">✅ Tabela <strong>produtos</strong> OK</p>
<p class="ok">✅ Tabela <strong>caixas</strong> OK</p>
<p class="ok">✅ Tabela <strong>vendas</strong> OK</p>
<p class="ok">✅ Tabela <strong>itens_venda</strong> OK</p>
<p class="ok">✅ Tabela <strong>lancamentos_avulsos</strong> OK</p>
<p class="ok">✅ Tabela <strong>combustiveis</strong> OK</p>
<p class="ok">✅ Tabela <strong>caixa_combustiveis</strong> OK</p>
<p class="ok">✅ Tabela <strong>mesas</strong> OK</p>
<p class="ok">✅ Tabela <strong>itens_mesa</strong> OK</p>
<p class="ok">✅ Tabela <strong>clientes_abastecimento</strong> OK</p>
<p class="ok">✅ Tabela <strong>vales</strong> OK</p>
<p class="ok">✅ Tabela <strong>configuracoes</strong> OK</p>
<p class="ok">✅ Admin padrão: login <strong>admin</strong> / senha <strong>admin123</strong></p>
<hr style="border-color:#333;margin:1.5rem 0">
<p style="color:#fa0;">⚠️ Altere a senha do admin após o primeiro login!</p>
<p><a href="/login.php" style="color:#f90;">→ Ir para o Login</a></p>
<p style="color:#555;font-size:.8rem;">Você pode excluir este arquivo após a instalação.</p>
</body>
</html>
