<?php
/**
 * includes/navbar_admin.php
 * Componente centralizado para a barra lateral e barra superior do Administrador.
 */

if (!isset($page_id))
  $page_id = '';

// Verifica se existe algum caixa aberto no sistema para o indicador de status
$db_nav = getDB();
$caixaGlobalNav = $db_nav->query("SELECT id FROM caixas WHERE status='aberto' LIMIT 1")->fetch();

if (!function_exists('sidebarAdmin')) {
  function sidebarAdmin(string $ativo = ''): string
  {
    $items = [
      ['href' => '/administrator/', 'icon' => '📊', 'label' => 'Dashboard', 'id' => 'dashboard'],
      ['href' => '/administrator/caixa.php', 'icon' => '🏧', 'label' => 'Caixa', 'id' => 'caixa'],
      ['href' => '/administrator/combustiveis.php', 'icon' => '⛽', 'label' => 'Combustíveis', 'id' => 'combustiveis'],
      ['href' => '/administrator/produtos.php', 'icon' => '📦', 'label' => 'Produtos', 'id' => 'produtos'],
      ['href' => '/administrator/clientes.php', 'icon' => '👥', 'label' => 'Operadores', 'id' => 'clientes'],
      ['href' => '/administrator/clientes_abastecimento.php', 'icon' => '👤', 'label' => 'Clientes Convênio', 'id' => 'clientes_abastecimento'],
      ['href' => '/administrator/vales.php', 'icon' => '🎟️', 'label' => 'Vales', 'id' => 'vales'],
      ['href' => '/administrator/telegram.php', 'icon' => '✈️', 'label' => 'Telegram', 'id' => 'telegram'],
      ['href' => '/administrator/vendas.php', 'icon' => '🧾', 'label' => 'Histórico de Vendas', 'id' => 'vendas'],
    ];
    $html = '';
    foreach ($items as $i) {
      $cls = $i['id'] === $ativo ? ' active' : '';
      $html .= "<a class='nav-item{$cls}' href='{$i['href']}'><span class='nav-icon'>{$i['icon']}</span>{$i['label']}</a>";
    }
    return $html;
  }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $page_title ?? 'Convênio Posto' ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/style.css?v=<?= time() ?>">
</head>

<body>
  <div class="overlay-mob"></div>
  <div class="layout">

    <!-- SIDEBAR -->
    <aside class="sidebar">
      <div class="sidebar-logo">
        <img src="/assets/images/logo.png" alt="Logo" style="width:36px; height:36px; object-fit:contain;">
        <div>
          <div class="logo-text">Convênio Posto</div>
          <div class="logo-sub">Administrador</div>
        </div>
      </div>
      <nav class="sidebar-nav">
        <div class="nav-section">Painel</div>
        <?= sidebarAdmin($page_id) ?>
      </nav>
    </aside>

    <!-- MAIN CONTENT WRAPPER START -->
    <div class="main-content">
      <header class="topbar" style="justify-content: space-between;">
        <div style="display: flex; align-items: center; gap: 1rem;">
          <button class="hamburger"><span></span><span></span><span></span></button>
          <div class="hide-mobile" style="display: flex; align-items: center; gap: 0.75rem;">
            <div
              style="width: 38px; height: 38px; background: var(--warning); color: #000; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.2);">
              <?= strtoupper(substr($_SESSION['usuario_nome'], 0, 1)) ?>
            </div>
            <div style="line-height: 1.2;">
              <div
                style="font-size: 0.95rem; font-weight: 700; color: var(--text-primary); display: flex; align-items: center; gap: 0.5rem;">
                <span class="hide-mobile"><?= htmlspecialchars($_SESSION['usuario_nome']) ?></span>
                <form action="/logout.php" method="POST" style="display: inline;">
                  <button type="submit"
                    style="background: none; border: none; cursor: pointer; display: flex; align-items: center; opacity: 0.7; transition: 0.2s; padding: 0;"
                    onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0.7" title="Sair">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
                      stroke-linecap="round" stroke-linejoin="round" style="color: var(--danger);">
                      <path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path>
                      <line x1="12" y1="2" x2="12" y2="12"></line>
                    </svg>
                  </button>
                </form>
              </div>
              <div class="hide-mobile"
                style="font-size: 0.7rem; color: var(--text-white); text-transform: uppercase; letter-spacing: 0.5px;">
                Administrador</div>
            </div>
          </div>
        </div>

        <div class="topbar-right" style="display: flex; align-items: center; gap: 1.25rem;">
          <div style="display: flex; align-items: center; gap: 1rem;">
            <button onclick="toggleTheme()" class="theme-toggle-icon" style="background:none; border:none; cursor:pointer; font-size:1.2rem; transition:transform 0.2s;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'" title="Alternar Tema">☀️</button>
            <?= $topbar_custom_actions ?? '' ?>
            <?php if ($caixaGlobalNav): ?>
              <span id="nav-caixa-status" class="caixa-status caixa-aberto"
                style="font-size: 0.7rem; padding: 4px 10px;">🟢 Caixa Aberto</span>
            <?php else: ?>
              <span id="nav-caixa-status" class="caixa-status caixa-fechado"
                style="font-size: 0.7rem; padding: 4px 10px;">🔴 Caixa Fechado</span>
            <?php endif; ?>
            <?php if (($page_id ?? '') === 'caixa'): ?>
            <button class="btn btn-ghost" onclick="openModal('modal-config')" title="Automação do Caixa"
              style="padding: 5px 10px; font-size: 1.2rem;">⚙️</button>
            <?php endif; ?>
            <span class="topbar-time" id="live-clock"
              style="font-weight: 600; color: var(--text-white); font-size: 0.85rem;"></span>
          </div>
        </div>
      </header>