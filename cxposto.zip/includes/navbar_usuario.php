<?php
/**
 * includes/navbar_usuario.php
 * Componente centralizado para a barra lateral e barra superior do Operador.
 */

if (!isset($page_id))
  $page_id = '';

// Variáveis esperadas: $caixa (obj), $vendasDinheiro (float), $resumoTotais (array)
// Se não existirem, inicializamos com valores padrão para evitar erros
if (!isset($caixa))
  $caixa = null;
if (!isset($vendasDinheiro))
  $vendasDinheiro = 0;
if (!isset($resumoTotais))
  $resumoTotais = ['pix' => 0, 'cielo' => 0, 'vale' => 0];
if (!isset($totalCombustivelTurno))
  $totalCombustivelTurno = 0;
if (!isset($combustiveisNoCaixa))
  $combustiveisNoCaixa = [];

// DADOS PARA O MODAL DE VALES
$db_nav_vales = getDB();
$clientes_abastecimento_nav = $db_nav_vales->query("SELECT * FROM clientes_abastecimento WHERE ativo = 1 ORDER BY nome ASC")->fetchAll();
$combustiveis_nav = $db_nav_vales->query("SELECT id, nome, preco FROM combustiveis ORDER BY nome ASC")->fetchAll();

?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= $page_title ?? 'Convênio Posto' ?></title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/style.css?v=<?= time() ?>">
</head>

<body>
  <div class="overlay-mob"></div>
  <div class="layout">

    <!-- SIDEBAR -->
    <aside class="sidebar">
      <div class="sidebar-logo">
        <img src="/assets/images/logo.png" alt="Logo" style="width:36px; height:36px; object-fit:contain;">
        <div>
          <div class="logo-text">Convênio Posto</div>
          <div class="logo-sub">Operador</div>
        </div>
      </div>
      <nav class="sidebar-nav">
        <div style="display: flex; flex-direction: column; gap: .5rem; margin: 1rem .75rem;">
          <a class="nav-item" href="#" onclick="openModal('modal-lancamento'); return false;" style="margin:0;"><span
              class="nav-icon">💳</span>Lançar Pix / Cielo</a>
          <a class="nav-item" href="#" onclick="openModal('modal-logs-turno'); return false;" style="margin:0;"><span
              class="nav-icon">📋</span>Logs do Turno</a>
          <a class="nav-item" href="#" onclick="abrirModalValeOp(); return false;" style="margin:0;"><span
              class="nav-icon">🎟️</span>Gerar Vale</a>
          <a class="nav-item" href="#" onclick="openModal('modal-estoque-combustivel'); return false;" style="margin:0; background: rgba(251,146,60,0.05); border: 1px solid rgba(251,146,60,0.1);"><span
              class="nav-icon">⛽</span>Combustível</a>
        </div>

        <?php if ($caixa): ?>
          <div class="nav-section" style="margin-top:1.5rem;">Resumo do Turno</div>
          <div style="padding: 0 0.75rem;">
            <div
              style="background:var(--bg-card); border:1px solid var(--border); border-radius:12px; padding:1rem; box-shadow: 0 4px 12px rgba(0,0,0,0.1);">
              <div style="display:flex; align-items:center; gap:.5rem; margin-bottom:1rem;">
                <span style="font-size:1.2rem;">👤</span>
                <div style="line-height:1.2;">
                  <div style="font-size:.7rem; color:var(--text-white); text-transform:uppercase; letter-spacing:0.5px;">
                    Responsáveis</div>
                  <div style="font-weight:700; font-size:.85rem; color:var(--text-primary);">
                    <?= htmlspecialchars($caixa['operador'] ?? '') ?>
                    <?php if (!empty($caixa['operador2'])): ?>
                      / <?= htmlspecialchars($caixa['operador2']) ?>
                    <?php endif; ?>
                  </div>
                </div>
              </div>

              <div
                style="background:rgba(34, 197, 94, 0.08); border-radius:8px; padding:.75rem; margin-bottom:1rem; border:1px solid rgba(34, 197, 94, 0.2);">
                <div
                  style="font-size:.7rem; color:var(--success); font-weight:700; text-transform:uppercase; margin-bottom:.25rem;">
                  💵 Vendas em Dinheiro</div>
                <div id="total-vendas-hoje"
                  style="font-size:1.4rem; font-weight:800; color:var(--success); letter-spacing:-0.5px;">
                  <span id="nav-resumo-dinheiro">R$ <?= number_format($vendasDinheiro, 2, ',', '.') ?></span>
                </div>
              </div>

              <div id="resumo-financeiro" style="display:flex; flex-direction:column; gap:.6rem; margin-bottom:1.25rem;">
                <div
                  style="display: flex; align-items: center; justify-content: space-between; font-size: 0.8rem; margin-bottom: 0.4rem; padding: 0 0.5rem;">
                  <span style="display: flex; align-items: center; gap: 0.4rem;"><span
                      style="width: 8px; height: 8px; background: #38bdf8; border-radius: 50%;"></span> Pix</span>
                  <span id="nav-resumo-pix">R$ <?= number_format($resumoTotais['pix'] ?? 0, 2, ',', '.') ?></span>
                </div>
                <div
                  style="display: flex; align-items: center; justify-content: space-between; font-size: 0.8rem; margin-bottom: 0.4rem; padding: 0 0.5rem;">
                  <span style="display: flex; align-items: center; gap: 0.4rem;"><span
                      style="width: 8px; height: 8px; background: #fbbf24; border-radius: 50%;"></span> Cielo</span>
                  <span id="nav-resumo-cielo">R$ <?= number_format($resumoTotais['cielo'] ?? 0, 2, ',', '.') ?></span>
                </div>
                <div
                  style="display: flex; align-items: center; justify-content: space-between; font-size: 0.8rem; padding: 0 0.5rem;">
                  <span style="display: flex; align-items: center; gap: 0.4rem;"><span
                      style="width: 8px; height: 8px; background: #fb923c; border-radius: 50%;"></span> Vales</span>
                  <span id="nav-resumo-vale">R$ <?= number_format($resumoTotais['vale'] ?? 0, 2, ',', '.') ?></span>
                </div>

                <div style="margin-top: 0.5rem; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 0.75rem;">
                  <div style="display: flex; align-items: center; justify-content: space-between; font-size: 0.85rem; font-weight: 700; color: var(--accent);">
                    <span>⛽ Combustível</span>
                    <span>R$ <?= number_format($totalCombustivelTurno, 2, ',', '.') ?></span>
                  </div>
                </div>
              </div>


              <div style="display:flex; flex-direction:column; gap:.5rem;">
                <button onclick="openModal('modal-imprimir-previa')"
                  class="btn btn-ghost btn-sm" style="width:100%; border:1px solid var(--border); font-size:.75rem;">🖨️
                  Imprimir Prévia</button>
                <button onclick="openModal('modal-fechar')" class="btn btn-danger btn-sm"
                  style="width:100%; font-size:.75rem; font-weight:700;">🔒 Fechar Caixa</button>
              </div>
            </div>
          </div>
        <?php endif; ?>
      </nav>
    </aside>

    <!-- MAIN CONTENT WRAPPER START -->
    <div class="main-content">
      <header class="topbar" style="justify-content: space-between;">
        <div style="display: flex; align-items: center; gap: 1rem;">
          <button class="hamburger"><span></span><span></span><span></span></button>
          <div style="display: flex; align-items: center; gap: 0.75rem;">
            <div
              style="width: 38px; height: 38px; background: var(--accent); color: white; border-radius: 10px; display: flex; align-items: center; justify-content: center; font-weight: 800; font-size: 1.1rem; box-shadow: 0 2px 8px rgba(0,0,0,0.2);">
              <?= strtoupper(substr($_SESSION['usuario_nome'], 0, 1)) ?>
            </div>
            <div style="line-height: 1.2;">
              <div
                style="font-size: 0.95rem; font-weight: 700; color: var(--text-primary); display: flex; align-items: center; gap: 0.5rem;">
                <?= htmlspecialchars($_SESSION['usuario_nome']) ?>
                <form action="/logout.php" method="POST" style="display: inline;">
                  <button type="submit"
                    style="background: none; border: none; cursor: pointer; display: flex; align-items: center; opacity: 0.5; transition: 0.2s; padding: 0;"
                    onmouseover="this.style.opacity=1" onmouseout="this.style.opacity=0.5" title="Sair">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"
                      stroke-linecap="round" stroke-linejoin="round" style="color: var(--danger);">
                      <path d="M18.36 6.64a9 9 0 1 1-12.73 0"></path>
                      <line x1="12" y1="2" x2="12" y2="12"></line>
                    </svg>
                  </button>
                </form>
              </div>
              <div
                style="font-size: 0.7rem; color: var(--text-white); text-transform: uppercase; letter-spacing: 0.5px;">
                Operador</div>
            </div>
          </div>
        </div>

        <div class="topbar-right" style="display: flex; align-items: center; gap: 1.25rem;">
          <div style="display: flex; align-items: center; gap: 1rem;">
            <button onclick="toggleTheme()" class="theme-toggle-icon" style="background:none; border:none; cursor:pointer; font-size:1.2rem; transition:transform 0.2s;" onmouseover="this.style.transform='scale(1.1)'" onmouseout="this.style.transform='scale(1)'" title="Alternar Tema">☀️</button>
            <?php if ($caixa): ?>
              <span id="nav-caixa-status" class="caixa-status caixa-aberto"
                style="font-size: 0.7rem; padding: 4px 10px;">🟢 Caixa Aberto</span>
            <?php else: ?>
              <span id="nav-caixa-status" class="caixa-status caixa-fechado"
                style="font-size: 0.7rem; padding: 4px 10px;">🔴 Caixa Fechado</span>
            <?php endif; ?>
            <span class="topbar-time" id="live-clock"
              style="font-weight: 600; color: var(--text-white); font-size: 0.85rem;"></span>
          </div>
        </div>
      </header>

<?php /* --- INÍCIO: CÓDIGO DO MODAL DE VALES ---
   Idealmente, este modal e o script abaixo devem ser movidos para o arquivo principal
   que inclui esta navbar (ex: /usuario/venda.php), junto com os outros modais.
*/ ?>
<div class="modal-overlay" id="modal-novo-vale-op">
  <div class="modal" style="max-width:650px;">
    <div class="modal-header">
      <span class="modal-title">🎟️ Novo Vale de Abastecimento</span>
      <button class="modal-close" onclick="closeModal('modal-novo-vale-op')">×</button>
    </div>
    <div class="modal-body">
      <form id="form-vale-op" onsubmit="salvarValeOp(event)">
        <div class="form-group">
            <label class="form-label">Cliente</label>
            <select name="cliente_id" id="vale-cliente-id-op" class="form-control" onchange="selecionarClienteOp(this.value)">
                <option value="0">-- Cliente Avulso (preencher manualmente) --</option>
                <?php foreach ($clientes_abastecimento_nav as $cli): ?>
                <option value="<?= $cli['id'] ?>" data-nome="<?= htmlspecialchars($cli['nome']) ?>" data-empresa="<?= htmlspecialchars($cli['empresa'] ?? '') ?>" data-carro="<?= htmlspecialchars($cli['carro'] ?? '') ?>" data-placa="<?= htmlspecialchars($cli['placa'] ?? '') ?>"><?= htmlspecialchars($cli['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-row">
            <div class="form-group"><label class="form-label">Nome (para o vale)</label><input name="nome_cliente" id="vale-nome-op" class="form-control" required></div>
            <div class="form-group"><label class="form-label">Empresa</label><input name="empresa" id="vale-empresa-op" class="form-control"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label class="form-label">Carro</label><input name="carro" id="vale-carro-op" class="form-control"></div>
            <div class="form-group"><label class="form-label">Placa (Opcional)</label><input name="placa" id="vale-placa-op" class="form-control"></div>
            <div class="form-group"><label class="form-label">KM (Opcional)</label><input type="number" step="0.1" name="km" id="vale-km-op" class="form-control"></div>
        </div>
        <hr style="border-color: var(--border); margin: 1.5rem 0;">
        <div class="form-row">
            <div class="form-group" style="flex: 2;">
                <label class="form-label">Combustível</label>
                <select name="combustivel_id" id="vale-combustivel-op" class="form-control" required onchange="calcularValeOp('litros')">
                    <option value="">Selecione...</option>
                    <?php foreach ($combustiveis_nav as $cb): ?>
                    <option value="<?= $cb['id'] ?>" data-preco="<?= $cb['preco'] ?>"><?= htmlspecialchars($cb['nome']) ?> (R$ <?= number_format($cb['preco'], 3, ',', '.') ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label class="form-label">Quantidade (L)</label><input type="number" step="0.01" min="0" name="quantidade" id="vale-quantidade-op" class="form-control" oninput="calcularValeOp('litros')"></div>
            <div class="form-group"><label class="form-label">Valor Total (R$)</label><input type="number" step="0.01" min="0" name="valor_total" id="vale-valor-op" class="form-control" oninput="calcularValeOp('valor')"></div>
        </div>
        <div class="form-group"><label class="form-label">Descrição / Observações (Opcional)</label><textarea name="descricao" id="vale-descricao-op" class="form-control" rows="2"></textarea></div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-novo-vale-op')">Cancelar</button>
      <button class="btn btn-primary" onclick="document.getElementById('form-vale-op').requestSubmit()">Salvar Vale</button>
    </div>
  </div>
</div>
<script>
const combustiveisOp = <?= json_encode(array_column($combustiveis_nav, null, 'id')) ?>;
const caixaAbertoIdOp = <?= $caixa ? $caixa['id'] : 'null' ?>;

function selecionarClienteOp(clienteId) {
    const form = document.getElementById('form-vale-op');
    if (clienteId && clienteId != "0") {
        const option = document.querySelector(`#vale-cliente-id-op option[value='${clienteId}']`);
        form.querySelector('#vale-nome-op').value = option.dataset.nome;
        form.querySelector('#vale-empresa-op').value = option.dataset.empresa;
        form.querySelector('#vale-carro-op').value = option.dataset.carro;
        form.querySelector('#vale-placa-op').value = option.dataset.placa;
    } else {
        form.querySelector('#vale-nome-op').value = '';
        form.querySelector('#vale-empresa-op').value = '';
        form.querySelector('#vale-carro-op').value = '';
        form.querySelector('#vale-placa-op').value = '';
        form.querySelector('#vale-nome-op').focus();
    }
}
function calcularValeOp(source) {
    const combustivelId = document.getElementById('vale-combustivel-op').value;
    const inputQtd = document.getElementById('vale-quantidade-op');
    const inputVal = document.getElementById('vale-valor-op');

    if (!combustivelId) {
        if ((source === 'litros' && inputQtd.value) || (source === 'valor' && inputVal.value)) {
            showToast('Selecione um combustível primeiro.', 'warning');
            if (source === 'litros') inputQtd.value = '';
            if (source === 'valor') inputVal.value = '';
        }
        return;
    }

    const preco = parseFloat(combustiveisOp[combustivelId].preco);

    if (source === 'litros') {
        const qtd = parseFloat(inputQtd.value) || 0;
        inputVal.value = (qtd > 0) ? (qtd * preco).toFixed(2) : '';
    } else if (source === 'valor') {
        const val = parseFloat(inputVal.value) || 0;
        inputQtd.value = (val > 0) ? (val / preco).toFixed(2) : '';
    }
}
function abrirModalValeOp() {
    if (!caixaAbertoIdOp) { showToast('É necessário ter um caixa aberto para criar vales.', 'warning'); return; }
    document.getElementById('form-vale-op').reset();
    openModal('modal-novo-vale-op');
}
async function salvarValeOp(e) {
    e.preventDefault();
    if (!caixaAbertoIdOp) { showToast('Caixa fechado. Não é possível salvar o vale.', 'error'); return; }
    const data = serializeForm(e.target);
    const resp = await postJSON('/administrator/ajax/gerenciar_vales.php', { acao: 'criar_vale', caixa_id: caixaAbertoIdOp, ...data });
    if (resp.ok) {
        showToast('Vale criado com sucesso!', 'success');
        closeModal('modal-novo-vale-op');
        refreshContent(['#resumo-financeiro']);
    } else {
        showToast(resp.msg || 'Erro ao salvar o vale.', 'error');
    }
}
</script>

<!-- MODAL ESCOLHER IMPRESSÃO -->
<div class="modal-overlay" id="modal-imprimir-previa">
  <div class="modal" style="max-width:380px;">
    <div class="modal-header">
      <span class="modal-title">🖨️ Imprimir Prévia</span>
      <button class="modal-close" onclick="closeModal('modal-imprimir-previa')">×</button>
    </div>
    <div class="modal-body" style="display:flex; flex-direction:column; gap: .75rem; padding: 1.5rem;">
        <a href="/administrator/comprovante.php?id=<?= $caixa['id'] ?? 0 ?>" target="_blank" class="btn btn-primary" style="width:100%; text-align:center;">🧾 Prévia do Caixa</a>
        <a href="/administrator/relatorio_vales_diario.php" target="_blank" class="btn btn-info" style="width:100%; text-align:center; background-color: var(--info);">🎟️ Relatório de Vales do Dia</a>
    </div>
  </div>
</div>

<!-- MODAL LOGS DO TURNO -->
<div class="modal-overlay" id="modal-logs-turno">
  <div class="modal" style="max-width:700px;">
    <div class="modal-header">
      <span class="modal-title">📋 Logs do Turno Atual</span>
      <button class="modal-close" onclick="closeModal('modal-logs-turno')">×</button>
    </div>
    <div class="modal-body" style="padding: 0;">
      <div class="table-wrap" style="max-height: 60vh;">
        <table>
          <thead>
            <tr>
              <th>Horário</th>
              <th>Operador</th>
              <th>Tipo de Lançamento</th>
              <th>Valor</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($logCaixa)): ?>
              <tr><td colspan="4" class="text-center text-muted" style="padding: 2rem;">Nenhum lançamento neste turno.</td></tr>
            <?php else: ?>
              <?php foreach ($logCaixa as $log): ?>
                <tr>
                  <td class="text-sm"><?= date('H:i:s', strtotime($log['criado_em'])) ?></td>
                  <td><?= htmlspecialchars($log['operador']) ?></td>
                  <td><?= htmlspecialchars(ucwords(str_replace('_', ' ', $log['tipo']))) ?></td>
                  <td class="fw-bold">R$ <?= number_format($log['valor_total'], 2, ',', '.') ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<!-- MODAL LOGS DO TURNO -->
<div class="modal-overlay" id="modal-logs-turno">
  <div class="modal" style="max-width:700px;">
    <div class="modal-header">
      <span class="modal-title">📋 Logs do Turno Atual</span>
      <button class="modal-close" onclick="closeModal('modal-logs-turno')">×</button>
    </div>
    <div class="modal-body" style="padding: 0;">
      <div class="table-wrap" style="max-height: 60vh;">
        <table>
          <thead>
            <tr>
              <th>Horário</th>
              <th>Operador</th>
              <th>Tipo de Lançamento</th>
              <th>Valor</th>
            </tr>
          </thead>
          <tbody>
            <?php if (empty($logCaixa)): ?>
              <tr><td colspan="4" class="text-center text-muted" style="padding: 2rem;">Nenhum lançamento neste turno.</td></tr>
            <?php else: ?>
              <?php foreach ($logCaixa as $log): ?>
                <tr>
                  <td class="text-sm"><?= date('H:i:s', strtotime($log['criado_em'])) ?></td>
                  <td><?= htmlspecialchars($log['operador']) ?></td>
                  <td><?= htmlspecialchars(ucwords(str_replace('_', ' ', $log['tipo']))) ?></td>
                  <td class="fw-bold">R$ <?= number_format($log['valor_total'], 2, ',', '.') ?></td>
                </tr>
              <?php endforeach; ?>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>

<?php // --- FIM: CÓDIGO DO MODAL DE VALES --- ?>