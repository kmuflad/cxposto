<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check(); // Permite admin e operador

$db = getDB();

// Pega a data do filtro, se não houver, usa a data atual
$dataFiltro = $_GET['data'] ?? date('Y-m-d');
$mode = $_GET['mode'] ?? 'completo'; // 'completo' ou 'resumido'

$stmt = $db->prepare("
    SELECT * 
    FROM vales 
    WHERE DATE(criado_em) = ? AND status = 'ativo'
    ORDER BY empresa, nome_cliente ASC
");
$stmt->execute([$dataFiltro]);
$vales = $stmt->fetchAll();

// Processa dados para o resumo e agrupa por empresa
$totalGeral = 0;
$resumoCombustiveis = [];
$valesPorEmpresa = [];

foreach ($vales as $vale) {
    $totalGeral += (float)$vale['valor_total'];
    
    // Para o modo resumido
    $combustivelNome = $vale['nome_combustivel'];
    if (!isset($resumoCombustiveis[$combustivelNome])) {
        $resumoCombustiveis[$combustivelNome] = ['litros' => 0, 'valor' => 0];
    }
    $resumoCombustiveis[$combustivelNome]['litros'] += (float)$vale['quantidade'];
    $resumoCombustiveis[$combustivelNome]['valor'] += (float)$vale['valor_total'];

    // Para o modo completo (agrupado por empresa)
    $empresa = !empty($vale['empresa']) ? strtoupper(trim($vale['empresa'])) : 'CLIENTES AVULSOS';
    if (!isset($valesPorEmpresa[$empresa])) {
        $valesPorEmpresa[$empresa] = ['vales' => [], 'total' => 0];
    }
    $valesPorEmpresa[$empresa]['vales'][] = $vale;
    $valesPorEmpresa[$empresa]['total'] += (float)$vale['valor_total'];
}
ksort($resumoCombustiveis);
ksort($valesPorEmpresa);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Relatório Diário de Vales</title>
    <link rel="stylesheet" href="/assets/css/style.css?v=<?= time() ?>">
    <style>
        body { background: var(--bg-deep); margin: 0; padding: 0; -webkit-print-color-adjust: exact; }
        .comp-wrapper { min-height: 100vh; display: flex; flex-direction: column; align-items: center; padding: 2rem 1rem; }
        .no-print { display: flex; flex-wrap: wrap; justify-content: center; gap: .75rem; margin-bottom: 2rem; }
        .recibo { background: #fff; color: #000 !important; max-width: 320px; width: 100%; box-sizing: border-box; padding: 20px; font-family: 'Courier New', Courier, monospace; font-size: 13px; font-weight: 700 !important; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4); }
        .recibo-center { text-align: center; text-transform: uppercase; }
        .recibo h2 { font-size: 18px; margin: 0 0 5px; font-weight: 900 !important; }
        .recibo p { margin: 2px 0; font-size: 11px; }
        .divisor { border-top: 1px dashed #000; margin: 10px 0; }
        .secao-titulo { font-weight: 900 !important; text-transform: uppercase; margin-bottom: 8px; font-size: 14px; border-bottom: 1px solid #000; display: inline-block; }
        .item-row { display: flex; justify-content: space-between; margin-bottom: 4px; line-height: 1.2; }
        .item-nome { flex: 1; padding-right: 10px; }
        .item-valor { text-align: right; white-space: nowrap; }
        .total-destaque { font-size: 16px; font-weight: 900 !important; margin-top: 10px; display: flex; justify-content: space-between; }
        .btn-warning { background: #f59e0b; color: white; }
        .btn-success { background: #10b981; color: white; }
        @page { margin: 0; size: 80mm auto; }
        @media print {
            body { background: #fff !important; }
            .comp-wrapper { padding: 0; }
            .recibo { box-shadow: none; max-width: none; width: 100%; padding: 5mm; }
            .no-print { display: none; }
        }
    </style>
</head>
<body>
    <div class="comp-wrapper">
        <div class="no-print">
            <form method="GET" style="display:flex; gap: .5rem; align-items:flex-end;">
                <div class="form-group">
                    <label class="form-label" style="color:white;">Data</label>
                    <input type="date" name="data" class="form-control" value="<?= htmlspecialchars($dataFiltro) ?>">
                    <input type="hidden" name="mode" value="<?= htmlspecialchars($mode) ?>">
                </div>
                <button type="submit" class="btn btn-primary">Filtrar</button>
            </form>
            <button onclick="window.print()" class="btn btn-primary">🖨️ Imprimir</button>
            <?php if ($mode === 'completo'): ?>
                <a href="?data=<?= $dataFiltro ?>&mode=resumido" class="btn btn-warning">📄 Ver Resumido</a>
            <?php else: ?>
                <a href="?data=<?= $dataFiltro ?>&mode=completo" class="btn btn-success">📄 Ver Completo</a>
            <?php endif; ?>
        </div>

        <div class="recibo">
            <div class="recibo-center">
                <h2>CONVÊNIO POSTO</h2>
                <p>RELATÓRIO DE VALES</p>
                <p><?= date('d/m/Y', strtotime($dataFiltro)) ?></p>
            </div>
            <div class="divisor"></div>

            <?php if (empty($vales)): ?>
                <p class="recibo-center">Nenhum vale emitido nesta data.</p>
            <?php else: ?>
                <?php if ($mode === 'completo'): ?>
                    <div class="secao-titulo">Vales Emitidos (Detalhado)</div>
                    <?php foreach ($valesPorEmpresa as $empresa => $dadosEmpresa): ?>
                        <div style="margin-bottom: 15px;">
                            <div style="font-weight: 900; text-transform: uppercase; border-bottom: 1px solid #000; margin-bottom: 5px;"><?= htmlspecialchars($empresa) ?></div>
                            <?php foreach ($dadosEmpresa['vales'] as $v): ?>
                                <div style="margin-bottom: 8px; border-left: 2px solid #ccc; padding-left: 8px;">
                                    <div class="item-row">
                                        <span class="item-nome"><?= htmlspecialchars($v['nome_cliente']) ?></span>
                                        <span class="item-valor fw-bold">R$ <?= number_format($v['valor_total'], 2, ',', '.') ?></span>
                                    </div>
                                    <div class="item-row" style="font-size:11px;">
                                        <span class="item-nome"><?= htmlspecialchars($v['nome_combustivel']) ?></span>
                                        <span class="item-valor"><?= number_format($v['quantidade'], 2, ',', '.') ?> L</span>
                                    </div>
                                    <?php if($v['placa']): ?>
                                    <div class="item-row" style="font-size:11px;">
                                        <span class="item-nome">PLACA:</span>
                                        <span class="item-valor"><?= htmlspecialchars($v['placa']) ?></span>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                            <div class="item-row" style="font-weight: 900; border-top: 1px solid #ccc; padding-top: 5px; margin-top: 5px;">
                                <span>SUBTOTAL <?= htmlspecialchars($empresa) ?>:</span>
                                <span>R$ <?= number_format($dadosEmpresa['total'], 2, ',', '.') ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: // Resumido ?>
                    <div class="secao-titulo">Resumo por Combustível</div>
                    <?php foreach ($resumoCombustiveis as $nome => $data): ?>
                        <div style="margin-bottom: 8px;">
                            <div style="font-weight: 900;"><?= htmlspecialchars($nome) ?></div>
                            <div class="item-row">
                                <span>TOTAL LITROS:</span>
                                <span><?= number_format($data['litros'], 2, ',', '.') ?> L</span>
                            </div>
                            <div class="item-row">
                                <span>TOTAL VALOR:</span>
                                <span>R$ <?= number_format($data['valor'], 2, ',', '.') ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>

                <div class="divisor"></div>
                <div class="total-destaque">
                    <span>TOTAL GERAL:</span>
                    <span>R$ <?= number_format($totalGeral, 2, ',', '.') ?></span>
                </div>
            <?php endif; ?>

            <div class="recibo-center" style="margin-top: 20px; font-size: 10px;">
                <p>Impresso em <?= date('d/m/Y H:i') ?></p>
            </div>
        </div>
    </div>
</body>
</html>