<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('admin');

$db = getDB();
$combustiveis = $db->query("SELECT * FROM combustiveis ORDER BY nome ASC")->fetchAll();


$page_id = 'combustiveis';
$page_title = 'Combustíveis — Convênio Posto';
$topbar_custom_actions = '<button class="btn btn-primary btn-sm" onclick="openModal(\'modal-novo\')">+ Novo Combustível</button>';

// Busca estoque do caixa aberto, se existir
$caixaAberto = $db->query("SELECT id FROM caixas WHERE status='aberto' LIMIT 1")->fetch();
$estoqueCaixa = [];
if ($caixaAberto) {
  $estoqueCaixa = $db->query("SELECT * FROM caixa_combustiveis WHERE caixa_id=".$caixaAberto['id']." ORDER BY nome ASC")->fetchAll();
}

include __DIR__ . '/../includes/navbar_admin.php'; 
?>

    <div class="page-body">
      <div class="card fade-in">
        <div class="card-header">
          <span class="card-title">⛽ Combustíveis e Preços</span>
          <span class="badge badge-info"><?= count($combustiveis) ?> tipos</span>
        </div>
        <?php if ($combustiveis): ?>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>Combustível</th><th>Preço por Litro</th><th>Ações</th></tr>
            </thead>
            <tbody>
              <?php foreach ($combustiveis as $c): ?>
              <tr id="row-<?= $c['id'] ?>">
                <td><strong><?= htmlspecialchars($c['nome']) ?></strong></td>
                <td class="text-accent fw-bold">R$ <?= number_format($c['preco'],2,',','.') ?></td>
                <td>
                  <div style="display:flex;gap:.4rem;">
                    <button class="btn btn-ghost btn-sm" onclick="abrirEditar(<?= $c['id'] ?>,'<?= addslashes($c['nome']) ?>',<?= $c['preco'] ?>)">✏️ Editar</button>
                    <button class="btn btn-danger btn-sm" onclick="excluirCombustivel(<?= $c['id'] ?>)">🗑️</button>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
          <div class="empty-state"><span class="empty-icon">⛽</span><p>Nenhum combustível cadastrado.</p></div>
        <?php endif; ?>
      </div>

      <?php if ($estoqueCaixa): ?>
      <div class="card fade-in" style="margin-top: 2rem;">
        <div class="card-header">
          <span class="card-title">⚙️ Configurações de Inventário (Turno Atual)</span>
          <span class="badge badge-warning">Ajuste Manual de Altura/Litros</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Combustível</th>
                <th>Litragem Inicial (L)</th>
                <th>Altura Inicial (cm)</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($estoqueCaixa as $ec): ?>
              <tr>
                <td class="fw-bold"><?= htmlspecialchars($ec['nome']) ?></td>
                <td>
                  <input type="number" step="0.001" class="form-control" id="litros_init_<?= $ec['id'] ?>" value="<?= $ec['litragem_inicial'] ?>" style="max-width:140px;">
                </td>
                <td>
                  <input type="number" step="0.01" class="form-control" id="altura_init_<?= $ec['id'] ?>" value="<?= $ec['altura_inicial'] ?>" style="max-width:140px;">
                </td>
                <td>
                  <button class="btn btn-primary btn-sm" onclick="salvarEstoqueInicial(<?= $ec['id'] ?>)">💾 Salvar</button>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
      </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- MODAL NOVO -->
<div class="modal-overlay" id="modal-novo">
  <div class="modal" style="max-width:400px;">
    <div class="modal-header">
      <span class="modal-title">⛽ Novo Combustível</span>
      <button class="modal-close" onclick="closeModal('modal-novo')">×</button>
    </div>
    <div class="modal-body">
      <form id="form-novo" onsubmit="salvarNovo(event)">
        <div class="form-group">
          <label class="form-label">Nome do Combustível</label>
          <input name="nome" class="form-control" placeholder="Ex: Gasolina Comum" required>
        </div>
        <div class="form-group">
          <label class="form-label">Preço por Litro (R$)</label>
          <input name="preco" type="number" step="0.001" min="0" class="form-control" placeholder="0,000" required>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-novo')">Cancelar</button>
      <button class="btn btn-primary" onclick="document.getElementById('form-novo').requestSubmit()">Salvar</button>
    </div>
  </div>
</div>

<!-- MODAL EDITAR -->
<div class="modal-overlay" id="modal-editar">
  <div class="modal" style="max-width:400px;">
    <div class="modal-header">
      <span class="modal-title">✏️ Editar Preço</span>
      <button class="modal-close" onclick="closeModal('modal-editar')">×</button>
    </div>
    <div class="modal-body">
      <form id="form-editar" onsubmit="salvarEditar(event)">
        <input type="hidden" id="edit-id" name="id">
        <div class="form-group">
          <label class="form-label">Nome do Combustível</label>
          <input id="edit-nome" name="nome" class="form-control" required>
        </div>
        <div class="form-group">
          <label class="form-label">Preço por Litro (R$)</label>
          <input id="edit-preco" name="preco" type="number" step="0.001" min="0" class="form-control" required>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-editar')">Cancelar</button>
      <button class="btn btn-primary" onclick="document.getElementById('form-editar').requestSubmit()">Salvar Alterações</button>
    </div>
  </div>
</div>

<script src="/assets/js/main.js?v=<?= time() ?>"></script>
<script>
function abrirEditar(id, nome, preco) {
  document.getElementById('edit-id').value    = id;
  document.getElementById('edit-nome').value  = nome;
  document.getElementById('edit-preco').value = preco;
  openModal('modal-editar');
}

async function salvarNovo(e) {
  e.preventDefault();
  const data = serializeForm(e.target);
  const resp = await postJSON('/administrator/ajax/salvar_combustivel.php', { acao:'criar', ...data });
  if (resp.ok) { showToast('Combustível cadastrado!', 'success'); location.reload(); }
  else showToast(resp.msg || 'Erro ao cadastrar.', 'error');
}

async function salvarEditar(e) {
  e.preventDefault();
  const data = serializeForm(e.target);
  const resp = await postJSON('/administrator/ajax/salvar_combustivel.php', { acao:'editar', ...data });
  if (resp.ok) { showToast('Preço atualizado!', 'success'); location.reload(); }
  else showToast(resp.msg || 'Erro ao atualizar.', 'error');
}

async function excluirCombustivel(id) {
  confirmDelete('Excluir este combustível?', async () => {
    const resp = await postJSON('/administrator/ajax/salvar_combustivel.php', { acao:'excluir', id });
    if (resp.ok) { document.getElementById('row-'+id)?.remove(); showToast('Excluído.', 'success'); }
    else showToast(resp.msg, 'error');
  });
}

async function salvarEstoqueInicial(estoqueCaixaId) {
  const litros = document.getElementById('litros_init_' + estoqueCaixaId).value;
  const altura = document.getElementById('altura_init_' + estoqueCaixaId).value;
  
  const resp = await postJSON('/administrator/ajax/fechar_caixa.php', {
    acao: 'editar_estoque',
    id_registro: estoqueCaixaId,
    litragem_inicial: litros,
    altura_inicial: altura
  });
  
  if (resp.ok) showToast('Inventário atualizado!', 'success');
  else showToast(resp.msg || 'Erro ao salvar.', 'error');
}
</script>
</body>
</html>
