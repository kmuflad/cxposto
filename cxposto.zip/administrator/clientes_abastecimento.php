<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('admin');

$db = getDB();
$clientes = $db->query("SELECT * FROM clientes_abastecimento ORDER BY nome ASC")->fetchAll();

$page_id = 'clientes_abastecimento';
$page_title = 'Clientes de Abastecimento — Convênio Posto';
$topbar_custom_actions = '<button class="btn btn-primary btn-sm" onclick="openModal(\'modal-novo\')">+ Novo Cliente</button>';
include __DIR__ . '/../includes/navbar_admin.php';
?>

<div class="page-body">
  <div class="card fade-in">
    <div class="card-header">
      <span class="card-title">👤 Clientes de Abastecimento</span>
      <span class="badge badge-info"><?= count($clientes) ?> clientes</span>
    </div>
    <?php if ($clientes): ?>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Nome</th>
              <th>Empresa</th>
              <th>Carro / Placa</th>
              <th>Status</th>
              <th>Cadastrado em</th>
              <th>Ações</th>
            </tr>
          </thead>
          <tbody id="tbody-clientes">
            <?php foreach ($clientes as $c): ?>
              <tr id="row-<?= $c['id'] ?>">
                <td><strong><?= htmlspecialchars($c['nome']) ?></strong></td>
                <td><?= htmlspecialchars($c['empresa'] ?? '—') ?></td>
                <td>
                  <?= htmlspecialchars($c['carro'] ?? '—') ?>
                  <div class="text-xs text-muted"><?= htmlspecialchars($c['placa'] ?? '') ?></div>
                </td>
                <td>
                  <?php if ($c['ativo']): ?>
                    <span class="badge badge-success">Ativo</span>
                  <?php else: ?>
                    <span class="badge badge-danger">Inativo</span>
                  <?php endif; ?>
                </td>
                <td class="text-muted text-sm"><?= date('d/m/Y', strtotime($c['criado_em'])) ?></td>
                <td>
                  <div style="display:flex;gap:.4rem;">
                    <button class="btn btn-ghost btn-sm"
                      onclick="abrirEditar(<?= htmlspecialchars(json_encode($c)) ?>)">
                      ✏️ Editar
                    </button>
                    <?php if ($c['ativo']): ?>
                      <button class="btn btn-danger btn-sm" onclick="toggleStatus(<?= $c['id'] ?>, 0)">🚫 Desativar</button>
                    <?php else: ?>
                      <button class="btn btn-success btn-sm" onclick="toggleStatus(<?= $c['id'] ?>, 1)">✅ Ativar</button>
                    <?php endif; ?>
                  </div>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else: ?>
      <div class="empty-state"><span class="empty-icon">👤</span>
        <p>Nenhum cliente de abastecimento cadastrado.</p>
      </div>
    <?php endif; ?>
  </div>
</div>
</div>
</div>

<!-- MODAL NOVO/EDITAR -->
<div class="modal-overlay" id="modal-novo">
  <div class="modal" style="max-width:500px;">
    <div class="modal-header">
      <span class="modal-title" id="modal-title">➕ Novo Cliente</span>
      <button class="modal-close" onclick="closeModal('modal-novo')">×</button>
    </div>
    <div class="modal-body">
      <form id="form-cliente" onsubmit="salvarCliente(event)">
        <input type="hidden" name="id" id="cliente-id">
        <div class="form-group">
          <label class="form-label">Nome do Cliente</label>
          <input name="nome" id="cliente-nome" class="form-control" placeholder="Ex: João da Silva" required>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Empresa (Opcional)</label>
                <input name="empresa" id="cliente-empresa" class="form-control" placeholder="Ex: Minha Empresa LTDA">
            </div>
            <div class="form-group">
                <label class="form-label">Carro (Opcional)</label>
                <input name="carro" id="cliente-carro" class="form-control" placeholder="Ex: Fiat Uno">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label">Placa (Opcional)</label>
            <input name="placa" id="cliente-placa" class="form-control" placeholder="Ex: ABC-1234">
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-novo')">Cancelar</button>
      <button class="btn btn-primary" onclick="document.getElementById('form-cliente').requestSubmit()">Salvar</button>
    </div>
  </div>
</div>

<script src="/assets/js/main.js?v=<?= time() ?>"></script>
<script>
  function abrirEditar(cliente) {
    document.getElementById('modal-title').textContent = '✏️ Editar Cliente';
    document.getElementById('cliente-id').value = cliente.id;
    document.getElementById('cliente-nome').value = cliente.nome;
    document.getElementById('cliente-empresa').value = cliente.empresa || '';
    document.getElementById('cliente-carro').value = cliente.carro || '';
    document.getElementById('cliente-placa').value = cliente.placa || '';
    openModal('modal-novo');
  }

  document.querySelector('button[onclick="openModal(\'modal-novo\')"]').addEventListener('click', function() {
    document.getElementById('modal-title').textContent = '➕ Novo Cliente';
    document.getElementById('form-cliente').reset();
    document.getElementById('cliente-id').value = '';
  });

  async function salvarCliente(e) {
    e.preventDefault();
    const data = serializeForm(e.target);
    const resp = await postJSON('/administrator/ajax/gerenciar_vales.php', { acao: 'salvar_cliente', ...data });
    if (resp.ok) {
      showToast('Cliente salvo com sucesso!', 'success');
      location.reload();
    } else {
      showToast(resp.msg || 'Erro ao salvar cliente.', 'error');
    }
  }

  async function toggleStatus(id, ativo) {
    const msg = ativo ? 'Ativar este cliente?' : 'Desativar este cliente? Clientes inativos não aparecem para seleção nos vales.';
    confirmDelete(msg, async () => {
      const resp = await postJSON('/administrator/ajax/gerenciar_vales.php', { acao: 'toggle_cliente', id, ativo });
      if (resp.ok) {
        showToast('Status alterado!', 'success');
        location.reload();
      } else {
        showToast(resp.msg, 'error');
      }
    });
  }
</script>
</body>
</html>