<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('admin');

$db = getDB();
$operadores = $db->query("SELECT id, nome FROM usuarios WHERE ativo=1 AND tipo='operador' ORDER BY nome")->fetchAll();

// Verifica se a coluna operador2_id existe para evitar erros fatais
$colunaOperador2Existe = $db->query("SHOW COLUMNS FROM `caixas` LIKE 'operador2_id'")->fetch();

if ($colunaOperador2Existe) {
    $caixaAberto = $db->query("
        SELECT c.*, u1.nome as operador, u2.nome as operador2
        FROM caixas c 
        JOIN usuarios u1 ON u1.id=c.operador_id 
        LEFT JOIN usuarios u2 ON u2.id=c.operador2_id
        WHERE c.status='aberto' LIMIT 1")->fetch();
} else {
    $caixaAberto = $db->query("
        SELECT c.*, u1.nome as operador, NULL as operador2
        FROM caixas c 
        JOIN usuarios u1 ON u1.id=c.operador_id 
        WHERE c.status='aberto' LIMIT 1")->fetch();
}

$pixTotal = 0;
$cieloTotal = 0;
if ($caixaAberto) {
  $id = $caixaAberto['id'];
  $vendasDinheiro = $db->query("SELECT COALESCE(SUM(valor_dinheiro),0) FROM vendas WHERE caixa_id=$id AND status='finalizada'")->fetchColumn();
  $vendasBruto    = $db->query("SELECT COALESCE(SUM(valor_total),0) FROM vendas WHERE caixa_id=$id AND status='finalizada'")->fetchColumn();
  
  $pixTotal   = $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$id AND tipo='pix' AND COALESCE(descricao, '') != 'Venda de Combustível') + (SELECT COALESCE(SUM(valor_pix),0) FROM vendas WHERE caixa_id=$id AND status='finalizada')")->fetchColumn();
  $cieloTotal = $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$id AND tipo='cielo' AND COALESCE(descricao, '') != 'Venda de Combustível') + (SELECT COALESCE(SUM(valor_cielo),0) FROM vendas WHERE caixa_id=$id AND status='finalizada')")->fetchColumn();
  $valeTotal  = $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$id AND tipo='vale' AND COALESCE(descricao, '') != 'Venda de Combustível') + (SELECT COALESCE(SUM(valor_vale),0) FROM vendas WHERE caixa_id=$id AND status='finalizada') + (SELECT COALESCE(SUM(valor_total),0) FROM vales WHERE caixa_id=$id AND status='ativo')")->fetchColumn();
  
  $stmtComb = $db->prepare("SELECT * FROM caixa_combustiveis WHERE caixa_id = ? ORDER BY nome ASC");
  $stmtComb->execute([$id]);
  $combustiveisNoCaixaAberto = $stmtComb->fetchAll();

    $vendasNoCaixaAberto = $db->query("
        SELECT v.*, u.nome as operador,
        (SELECT GROUP_CONCAT(CONCAT(quantidade, 'x ', nome_produto) SEPARATOR ', ') FROM itens_venda WHERE venda_id = v.id) as resumo_produtos
        FROM vendas v 
        JOIN usuarios u ON u.id=v.operador_id 
        WHERE v.caixa_id=$id AND v.status='finalizada' 
        ORDER BY v.criado_em DESC
    ")->fetchAll();

    $lancamentosNoCaixaAberto = $db->query("SELECT l.* FROM lancamentos_avulsos l WHERE l.caixa_id=$id ORDER BY l.criado_em DESC")->fetchAll();
    
    $vendasCombustivelNoCaixa = $db->query("
        SELECT l.*, v.valor_total as valor_produtos, v.id as v_id,
        (SELECT GROUP_CONCAT(nome_produto SEPARATOR ', ') FROM itens_venda WHERE venda_id = v.id) as resumo_produtos
        FROM lancamentos_avulsos l
        LEFT JOIN vendas v ON v.id = l.venda_id
        WHERE l.caixa_id=$id AND (l.descricao = 'Venda de Combustível' OR l.venda_id IS NOT NULL)
        ORDER BY l.criado_em DESC
    ")->fetchAll();
} else {
    $pixTotal = 0; $cieloTotal = 0; $valeTotal = 0;
    $combustiveisNoCaixaAberto = [];
    $vendasNoCaixaAberto = [];
    $lancamentosNoCaixaAberto = [];
    $vendasCombustivelNoCaixa = [];
}

// Carrega as configurações
$configPath = __DIR__ . '/../config/settings.json';
$configCaixa = file_exists($configPath) ? json_decode(file_get_contents($configPath), true) : [];
$horaAbertura = $configCaixa['caixa_auto_abertura'] ?? '';
$horaFechamento = $configCaixa['caixa_auto_fechamento'] ?? '';

// Lista de combustíveis para abertura
$combustiveisCadastrados = $db->query("SELECT * FROM combustiveis ORDER BY nome ASC")->fetchAll();

// Histórico de caixas fechados
if ($colunaOperador2Existe) {
    $historico = $db->query("
        SELECT c.*, u1.nome as operador, u2.nome as operador2,
               (SELECT COUNT(*) FROM vendas v WHERE v.caixa_id=c.id AND v.status='finalizada') as total_vendas
        FROM caixas c
        JOIN usuarios u1 ON u1.id=c.operador_id
        LEFT JOIN usuarios u2 ON u2.id=c.operador2_id
        WHERE c.status='fechado'
        ORDER BY c.fechamento DESC
        LIMIT 30
    ")->fetchAll();
} else {
    $historico = $db->query("
        SELECT c.*, u.nome as operador, NULL as operador2,
               (SELECT COUNT(*) FROM vendas v WHERE v.caixa_id=c.id AND v.status='finalizada') as total_vendas
        FROM caixas c
        JOIN usuarios u ON u.id=c.operador_id
        WHERE c.status='fechado'
        ORDER BY c.fechamento DESC
        LIMIT 30
    ")->fetchAll();
}

$page_id = 'caixa';
include __DIR__ . '/../includes/navbar_admin.php'; 
?>

      <div class="page-body" id="caixa-dashboard">

        <!-- STATUS DO CAIXA ATUAL -->
        <div class="card fade-in" style="margin-bottom:1.25rem;">
          <div class="card-header">
            <span class="card-title">🏧 Caixa Atual</span>
            <?php if ($caixaAberto): ?>
              <span class="caixa-status caixa-aberto">🟢 ABERTO</span>
            <?php else: ?>
              <span class="caixa-status caixa-fechado">🔴 FECHADO</span>
            <?php endif; ?>
          </div>

          <?php if ($caixaAberto): ?>
            <!-- CAIXA ABERTO -->
            <div
              style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:1rem;margin-bottom:1.25rem;">
              <div>
                <div class="text-sm text-muted fw-bold">Responsáveis</div>
                <div style="font-size:1.1rem;font-weight:700;">
                  <?= htmlspecialchars($caixaAberto['operador']) ?>
                  <?php if ($caixaAberto['operador2']): ?>
                    / <?= htmlspecialchars($caixaAberto['operador2']) ?>
                  <?php endif; ?>
                </div>
              </div>
              <div>
                <div class="text-sm text-muted fw-bold">Aberto às</div>
                <div style="font-size:1.1rem;font-weight:700;">
                  <?= date('d/m/Y H:i', strtotime($caixaAberto['abertura'])) ?>
                </div>
              </div>
              <div>
                <div class="text-sm text-muted fw-bold">Valor Inicial (Troco)</div>
                <div style="font-size:1.1rem;font-weight:700;color:var(--accent);">R$
                  <?= number_format($caixaAberto['valor_abertura'], 2, ',', '.') ?>
                </div>
              </div>
              <div>
                <div class="text-sm text-muted fw-bold">Vendido (Dinheiro)</div>
                <div style="font-size:1.1rem;font-weight:700;color:var(--success);">R$
                  <?= number_format($vendasDinheiro, 2, ',', '.') ?>
                </div>
              </div>
              <div>
                <div class="text-sm text-muted fw-bold">Total Bruto (Produtos)</div>
                <div style="font-size:1.1rem;font-weight:700;color:var(--text-muted);">R$
                  <?= number_format($vendasBruto, 2, ',', '.') ?>
                </div>
              </div>
              <div>
                <div class="text-sm text-muted fw-bold">PIX</div>
                <div style="font-size:1.1rem;font-weight:700;color:var(--success);">R$
                  <?= number_format($pixTotal, 2, ',', '.') ?>
                </div>
              </div>
              <div>
                <div class="text-sm text-muted fw-bold">CIELO</div>
                <div style="font-size:1.1rem;font-weight:700;color:var(--success);">R$
                  <?= number_format($cieloTotal, 2, ',', '.') ?>
                </div>
              </div>
              <div>
                <div class="text-sm text-muted fw-bold">VALES</div>
                <div style="font-size:1.1rem;font-weight:700;color:var(--success);">R$
                  <?= number_format($valeTotal, 2, ',', '.') ?>
                </div>
              </div>
            </div>
            <div style="display:flex;gap:.75rem;flex-wrap:wrap;">
              <a href="/administrator/comprovante.php?id=<?= $caixaAberto['id'] ?>" target="_blank" class="btn btn-ghost">
                🖨️ Prévia do Comprovante
              </a>
              <button class="btn btn-danger" onclick="openModal('modal-fechar')">
                🔒 Fechar Caixa do Dia
              </button>
            </div>

          <?php else: ?>
            <!-- CAIXA FECHADO -->
            <div class="empty-state" style="padding:2rem 1rem;">
              <span class="empty-icon">🔒</span>
              <p style="margin-bottom:1.5rem;">Nenhum caixa aberto. Abra o caixa para iniciar as vendas.</p>
              <button class="btn btn-primary btn-lg" onclick="openModal('modal-abrir')">
                🟢 Abrir Caixa
              </button>
            </div>
          <?php endif; ?>
        </div>

        <!-- Monitoramento de Vendas e Lançamentos -->
        <?php if ($caixaAberto): ?>
        <style>
          .tabs { display: flex; gap: .25rem; margin-bottom: -1px; position: relative; z-index: 2; overflow-x: auto; padding-bottom: 5px; scrollbar-width: none; }
          .tabs::-webkit-scrollbar { display: none; }
          .tab { padding: .75rem 1rem; background: var(--bg-card); border: 1px solid var(--border); border-radius: 8px 8px 0 0; cursor: pointer; color: var(--text-muted); font-weight: 600; font-size: .8rem; transition: all .2s; white-space: nowrap; flex-shrink: 0; }
          .tab.active { background: var(--bg-card2); border-bottom-color: var(--bg-card2); color: var(--accent); border-top: 2px solid var(--accent); }
          .tab-content { display: none; }
          .tab-content.active { display: block; }
          
          @media (max-width: 600px) {
            .tab { padding: .6rem .75rem; font-size: .75rem; }
          }
        </style>

        <div class="tabs">
          <div class="tab active" onclick="switchTab(this, 'tab-vendas')">🛒 Vendas</div>
          <div class="tab" onclick="switchTab(this, 'tab-pix')">📱 Pix</div>
          <div class="tab" onclick="switchTab(this, 'tab-cielo')">💳 Cielo</div>
          <div class="tab" onclick="switchTab(this, 'tab-vale')">🎟️ Vales</div>
          <div class="tab" onclick="switchTab(this, 'tab-combustivel')">⛽ Combustível</div>
        </div>

        <div class="card fade-in" style="border-top-left-radius: 0; margin-bottom: 1.5rem;">
          <!-- ABA VENDAS -->
          <div id="tab-vendas" class="tab-content active">
            <div class="card-header">
              <span class="card-title">Produtos Vendidos (Turno Atual)</span>
              <span class="badge badge-info"><?= count($vendasNoCaixaAberto) ?> vendas</span>
            </div>
            <div class="table-wrap">
              <table style="font-size: .85rem;">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Horário</th>
                    <th>Produtos</th>
                    <th>Valor Total</th>
                    <th>Distribuição</th>
                    <th>Ações</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($vendasNoCaixaAberto as $v): ?>
                  <tr>
                    <td>#<?= $v['id'] ?></td>
                    <td><?= date('H:i', strtotime($v['criado_em'])) ?></td>
                    <td style="max-width: 250px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;" title="<?= htmlspecialchars($v['resumo_produtos']) ?>">
                      <?= htmlspecialchars($v['resumo_produtos']) ?>
                      <div style="font-size: .65rem; color: var(--text-muted);">Op: <?= htmlspecialchars($v['operador']) ?></div>
                    </td>
                    <td class="fw-bold">R$ <?= number_format($v['valor_total'], 2, ',', '.') ?></td>
                    <td style="font-size:.7rem; color:var(--text-secondary);">
                      <?php 
                        $pMisto = [];
                        if ($v['valor_dinheiro'] > 0) $pMisto[] = "Din: ".number_format($v['valor_dinheiro'], 2, ',', '.');
                        if ($v['valor_pix'] > 0)      $pMisto[] = "Pix: ".number_format($v['valor_pix'], 2, ',', '.');
                        if ($v['valor_cielo'] > 0)    $pMisto[] = "Cie: ".number_format($v['valor_cielo'], 2, ',', '.');
                        if ($v['valor_vale'] > 0)     $pMisto[] = "Val: ".number_format($v['valor_vale'], 2, ',', '.');
                        echo implode(' | ', $pMisto);
                      ?>
                    </td>
                    <td>
                      <button class="btn btn-ghost btn-xs" onclick="excluirVenda(<?= $v['id'] ?>)" title="Excluir Venda">🗑️</button>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                  <?php if (!$vendasNoCaixaAberto): ?>
                  <tr><td colspan="6" class="text-center text-muted">Nenhuma venda de produtos realizada neste turno.</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div> <!-- /table-wrap -->
          </div> <!-- /tab-vendas -->

          <!-- ABA PIX -->
          <div id="tab-pix" class="tab-content">
            <div class="card-header"><span class="card-title">📱 Entradas em PIX</span></div>
            <div class="table-wrap">
              <table>
                <thead><tr><th>Tipo</th><th>Horário</th><th>Valor</th><th style="width:50px">Ações</th></tr></thead>
                <tbody>
                  <?php 
                    foreach ($vendasNoCaixaAberto as $v): if($v['valor_pix'] <= 0) continue; ?>
                    <tr><td>Venda #<?= $v['id'] ?></td><td><?= date('H:i', strtotime($v['criado_em'])) ?></td><td class="fw-bold text-info">R$ <?= number_format($v['valor_pix'], 2, ',', '.') ?></td></tr>
                  <?php endforeach; ?>
                  <?php foreach ($lancamentosNoCaixaAberto as $l): if($l['tipo'] != 'pix') continue; ?>
                    <tr><td>Avulso</td><td><?= date('H:i', strtotime($l['criado_em'])) ?></td><td class="fw-bold text-info">R$ <?= number_format($l['valor'], 2, ',', '.') ?></td><td><button class="btn btn-ghost btn-xs" onclick="excluirLancamento(<?= $l['id'] ?>)">🗑️</button></td></tr>
                  <?php endforeach; ?>
                  <?php if (count($vendasNoCaixaAberto) === 0 && count($lancamentosNoCaixaAberto) === 0): ?>
                    <tr><td colspan="3" class="text-center text-muted">Nenhuma entrada em PIX registrada.</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <!-- ABA CIELO -->
          <div id="tab-cielo" class="tab-content">
            <div class="card-header"><span class="card-title">💳 Entradas em CIELO</span></div>
            <div class="table-wrap">
              <table>
                <thead><tr><th>Tipo</th><th>Horário</th><th>Valor</th><th style="width:50px">Ações</th></tr></thead>
                <tbody>
                  <?php 
                    foreach ($vendasNoCaixaAberto as $v): if($v['valor_cielo'] <= 0) continue; ?>
                    <tr><td>Venda #<?= $v['id'] ?></td><td><?= date('H:i', strtotime($v['criado_em'])) ?></td><td class="fw-bold text-warning">R$ <?= number_format($v['valor_cielo'], 2, ',', '.') ?></td></tr>
                  <?php endforeach; ?>
                  <?php foreach ($lancamentosNoCaixaAberto as $l): if($l['tipo'] != 'cielo') continue; ?>
                    <tr><td>Avulso</td><td><?= date('H:i', strtotime($l['criado_em'])) ?></td><td class="fw-bold text-warning">R$ <?= number_format($l['valor'], 2, ',', '.') ?></td><td><button class="btn btn-ghost btn-xs" onclick="excluirLancamento(<?= $l['id'] ?>)">🗑️</button></td></tr>
                  <?php endforeach; ?>
                  <?php if (count($vendasNoCaixaAberto) === 0 && count($lancamentosNoCaixaAberto) === 0): ?>
                    <tr><td colspan="3" class="text-center text-muted">Nenhuma entrada em CIELO registrada.</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <!-- ABA VALE -->
          <div id="tab-vale" class="tab-content">
            <div class="card-header"><span class="card-title">🎟️ Entradas em VALE</span></div>
            <div class="table-wrap">
              <table>
                <thead><tr><th>Tipo</th><th>Horário</th><th>Valor</th><th style="width:50px">Ações</th></tr></thead>
                <tbody>
                  <?php 
                    foreach ($vendasNoCaixaAberto as $v): if($v['valor_vale'] <= 0) continue; ?>
                    <tr><td>Venda #<?= $v['id'] ?></td><td><?= date('H:i', strtotime($v['criado_em'])) ?></td><td class="fw-bold text-accent">R$ <?= number_format($v['valor_vale'], 2, ',', '.') ?></td></tr>
                  <?php endforeach; ?>
                  <?php foreach ($lancamentosNoCaixaAberto as $l): if($l['tipo'] != 'vale') continue; ?>
                    <tr><td>Avulso</td><td><?= date('H:i', strtotime($l['criado_em'])) ?></td><td class="fw-bold text-accent">R$ <?= number_format($l['valor'], 2, ',', '.') ?></td><td><button class="btn btn-ghost btn-xs" onclick="excluirLancamento(<?= $l['id'] ?>)">🗑️</button></td></tr>
                  <?php endforeach; ?>
                  <?php if (count($vendasNoCaixaAberto) === 0 && count($lancamentosNoCaixaAberto) === 0): ?>
                    <tr><td colspan="3" class="text-center text-muted">Nenhuma entrada em VALE registrada.</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <!-- ABA COMBUSTÍVEL (REFORMULADA) -->
          <div id="tab-combustivel" class="tab-content">
            <div class="card-header">
              <span class="card-title">⛽ Vendas de Combustível (Turno Atual)</span>
            </div>
            <div class="table-wrap">
              <table style="font-size: .85rem;">
                <thead>
                  <tr>
                    <th>Horário</th>
                    <th>Detalhamento (Combustível + Produtos)</th>
                    <th>Pagamento</th>
                    <th style="width:50px">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($vendasCombustivelNoCaixa as $vc): ?>
                  <tr>
                    <td><?= date('H:i', strtotime($vc['criado_em'])) ?></td>
                    <td>
                      <span class="fw-bold text-success">R$ <?= number_format($vc['valor'], 2, ',', '.') ?></span>
                      <span class="text-muted text-xs">combustível</span>
                      <?php if($vc['valor_produtos'] > 0): ?>
                        + <span class="fw-bold text-info">R$ <?= number_format($vc['valor_produtos'], 2, ',', '.') ?></span>
                        <span class="text-muted text-xs">produtos (<?= $vc['resumo_produtos'] ?>)</span>
                      <?php endif; ?>
                    </td>
                    <td>
                      <span class="badge badge-outline" style="text-transform: uppercase;"><?= $vc['tipo'] ?></span>
                    </td>
                    <td>
                      <button class="btn btn-ghost btn-xs" onclick="excluirLancamento(<?= $vc['id'] ?>)">🗑️</button>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                  <?php if (!$vendasCombustivelNoCaixa): ?>
                    <tr><td colspan="4" class="text-center text-muted">Nenhuma venda de combustível registrada neste turno.</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>

          </div>
        </div>
        <?php endif; ?>



        <!-- HISTÓRICO DE CAIXAS -->
        <?php if ($historico): ?>
          <div class="card fade-in" id="historico-lista">
            <div class="card-header">
              <span class="card-title">📋 Histórico de Caixas</span>
            </div>
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Operador</th>
                    <th>Abertura</th>
                    <th>Fechamento</th>
                    <th>Vendas</th>
                    <th>Total</th>
                    <th>Comprovante</th>
                  </tr>
                </thead>
                <tbody>
                  <?php foreach ($historico as $h): ?>
                    <tr>
                      <td>
                        <?= htmlspecialchars($h['operador']) ?>
                        <?php if ($h['operador2']): ?>
                          / <?= htmlspecialchars($h['operador2']) ?>
                        <?php endif; ?>
                      </td>
                      <td class="text-muted text-sm"><?= date('d/m/Y H:i', strtotime($h['abertura'])) ?></td>
                      <td class="text-muted text-sm">
                        <?= $h['fechamento'] ? date('d/m/Y H:i', strtotime($h['fechamento'])) : '—' ?>
                      </td>
                      <td><?= $h['total_vendas'] ?></td>
                      <td class="text-accent fw-bold">R$ <?= number_format($h['valor_total'], 2, ',', '.') ?></td>
                      <td>
                        <div style="display:flex; gap:.3rem;">
                        <a href="comprovante.php?id=<?= $h['id'] ?>&mode=completo" target="_blank" class="btn btn-sm btn-primary" title="Completo">📜</a>
                        <a href="comprovante.php?id=<?= $h['id'] ?>&mode=resumido" target="_blank" class="btn btn-sm btn-warning" title="Resumido">📝</a>
                      </div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        <?php endif; ?>

      </div>
    </div>
  </div>

  <!-- MODAL ABRIR CAIXA -->
  <div class="modal-overlay" id="modal-abrir">
    <div class="modal" style="max-width:420px;">
      <div class="modal-header">
        <span class="modal-title">🟢 Abrir Caixa do Dia</span>
        <button class="modal-close" onclick="closeModal('modal-abrir')">×</button>
      </div>
      <div class="modal-body">
        <div
          style="background:rgba(251,146,60,.08);border:1px solid rgba(251,146,60,.2);border-radius:10px;padding:.9rem 1rem;margin-bottom:1.25rem;display:flex;gap:.6rem;align-items:flex-start;">
          <span style="font-size:1.2rem;">🌐</span>
          <span style="font-size:.85rem;color:var(--text-secondary);">O caixa será aberto de forma <strong
              style="color:var(--accent);">global</strong> — todos os operadores poderão realizar vendas neste
            caixa.</span>
        </div>
        <form id="form-abrir" onsubmit="abrirCaixa(event)">
          <div class="form-group">
            <label class="form-label">Operador 1 (Responsável)</label>
            <select name="operador_id" class="form-control" required>
              <option value="">Selecione um operador...</option>
              <?php foreach ($operadores as $op): ?>
                <option value="<?= $op['id'] ?>"><?= htmlspecialchars($op['nome']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Operador 2 (Opcional)</label>
            <select name="operador2_id" class="form-control">
              <option value="">Nenhum</option>
              <?php foreach ($operadores as $op): ?>
                <option value="<?= $op['id'] ?>"><?= htmlspecialchars($op['nome']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">Valor Inicial (Troco em Caixa)</label>
            <input name="valor_abertura" type="number" step="0.01" min="0" class="form-control" placeholder="0,00"
              value="0">
          </div>

          <?php if ($combustiveisCadastrados): ?>
          <div style="margin-top:1.5rem; border-top:1px solid var(--border); padding-top:1rem;">
            <div class="form-label" style="margin-bottom:1rem; color:var(--accent);">⛽ Litragem Inicial de Combustíveis</div>
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:1rem;">
              <?php foreach ($combustiveisCadastrados as $cb): ?>
              <div style="grid-column: span 2; font-weight:600; font-size:.8rem; margin-top:.5rem; color:var(--text-secondary);"><?= htmlspecialchars($cb['nome']) ?></div>
              <div class="form-group" style="margin:0;">
                <label class="form-label" style="font-size:.7rem;">Litragem (L)</label>
                <input name="litragem_<?= $cb['id'] ?>" type="number" step="0.01" min="0" class="form-control" placeholder="0.00" value="0">
              </div>
              <div class="form-group" style="margin:0;">
                <label class="form-label" style="font-size:.7rem;">Altura (cm)</label>
                <input name="altura_<?= $cb['id'] ?>" type="number" step="0.01" min="0" class="form-control" placeholder="0.00" value="0">
              </div>
              <?php endforeach; ?>
            </div>
          </div>
          <?php endif; ?>
        </form>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('modal-abrir')">Cancelar</button>
        <button class="btn btn-primary" onclick="document.getElementById('form-abrir').requestSubmit()">🟢 Abrir Caixa
          Global</button>
      </div>
    </div>
  </div>


  <!-- MODAL FECHAR CAIXA -->
  <div class="modal-overlay" id="modal-fechar">
    <div class="modal" style="max-width:420px;">
      <div class="modal-header">
        <span class="modal-title">🔒 Fechar Caixa</span>
        <button class="modal-close" onclick="closeModal('modal-fechar')">×</button>
      </div>
      <div class="modal-body" style="text-align:center;">
        <span style="font-size:2.5rem;display:block;margin-bottom:.5rem;">⚠️</span>
        <p style="color:var(--text-secondary);margin-bottom:.75rem;">Tem certeza que deseja fechar o caixa do dia?</p>

        <form id="form-fechar-caixa" onsubmit="fecharCaixa(event)">
          <input type="hidden" name="id" value="<?= $caixaAberto['id'] ?? 0 ?>">
          <div class="form-label" style="margin-bottom:1rem; color:var(--accent);">⛽ Conferência de Caixa</div>

          <div class="form-group" style="background:rgba(255,255,255,0.03); padding:.75rem; border-radius:8px; border:1px solid var(--border); margin-bottom:1.5rem;">
            <label class="form-label" style="color:var(--success);">💵 Total em Dinheiro (Físico no Caixa)</label>
            <input name="dinheiro_final" type="text" class="form-control mask-money" placeholder="0,00" required>
            <small class="text-muted">Conte todo o dinheiro em espécie que está na gaveta.</small>
          </div>
          <?php if (!empty($combustiveisNoCaixaAberto)): ?>
          <?php foreach ($combustiveisNoCaixaAberto as $cb): ?>
          <div class="form-group">
            <label class="form-label" style="font-size:.8rem;"><?= htmlspecialchars($cb['nome']) ?></label>
            <div style="display:grid; grid-template-columns:1fr; gap:.5rem;">
              <div>
                <label style="font-size:.65rem; color:var(--accent); font-weight: bold;">Litros Vendidos (L)</label>
                <input name="litros_vendidos_<?= $cb['id'] ?>" type="number" step="0.01" min="0" class="form-control" placeholder="Ex: 1470.2" required>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
          <?php endif; ?>
        </form>

        <p style="font-size:.85rem;color:var(--text-muted); margin-top:1rem;">O comprovante será gerado automaticamente após o
          fechamento.</p>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('modal-fechar')">Cancelar</button>
        <button class="btn btn-danger" onclick="fecharCaixa()">🔒 Confirmar Fechamento</button>
      </div>
    </div>
  </div>

  <!-- MODAL CONFIGURAÇÕES -->
  <div class="modal-overlay" id="modal-config">
    <div class="modal" style="max-width:500px;">
      <div class="modal-header">
        <span class="modal-title">⚙️ Automação do Caixa</span>
        <button class="modal-close" onclick="closeModal('modal-config')">×</button>
      </div>
      <div class="modal-body">
        <p style="font-size:.85rem;color:var(--text-muted);margin-bottom:1.5rem;line-height:1.4;">
          O sistema abrirá ou fechará o caixa automaticamente se alguém acessar o sistema após o horário estipulado.
        </p>
        <form id="form-config" onsubmit="salvarConfig(event)">
          <div style="display:grid; grid-template-columns:1fr; gap:1rem; margin-bottom:1.5rem;">
            <div class="form-group">
              <label class="form-label">Horário de Fechamento (ex: 23:59)</label>
              <input type="time" name="fechamento" class="form-control" value="<?= htmlspecialchars($horaFechamento) ?>">
            </div>
          </div>

          <div class="form-group" style="background:rgba(255,255,255,0.03); padding:1rem; border-radius:8px; border:1px solid var(--border); margin-bottom:1.5rem;">
            <label class="form-label" style="display:flex; align-items:center; gap:.75rem; cursor:pointer; font-weight:600; margin-bottom:.5rem;">
              <input type="checkbox" name="vendas_pagamento_detalhado" value="1" style="width:18px;height:18px;" <?= ($configCaixa['vendas_pagamento_detalhado'] ?? false) ? 'checked' : '' ?>>
              <span>Registrar Pagamento Detalhado</span>
            </label>
            <small class="text-muted">Ativa a separação de Pix/Cielo/Dinheiro no dashboard do dia.</small>
          </div>

          <button type="submit" class="btn btn-primary" id="btnSalvarConfig" style="width:100%;">💾 Salvar Configurações</button>
        </form>
      </div>
    </div>
  </div>

  <script src="/assets/js/main.js?v=<?= time() ?>"></script>
  <script>
    async function abrirCaixa(e) {
      e.preventDefault();
      showSpinner('Abrindo caixa...');
      const data = serializeForm(e.target);
      const resp = await postJSON('/administrator/ajax/fechar_caixa.php', { acao: 'abrir', ...data });
      hideSpinner();
      if (resp.ok) { 
        showToast('Caixa aberto!', 'success'); 
        closeModal('modal-abrir');
        refreshContent(['#caixa-dashboard', '#historico-lista']); 
      }
      else showToast(resp.msg || 'Erro ao abrir caixa.', 'error');
    }

    async function fecharCaixa() {
      const caixaId = <?= $caixaAberto ? $caixaAberto['id'] : 0 ?>;
      if (!caixaId) return;
      showSpinner('Fechando caixa...');
      const formEl = document.getElementById('form-fechar-caixa');
      const formData = formEl ? serializeForm(formEl) : {};
      const resp = await postJSON('/administrator/ajax/fechar_caixa.php', { 
        acao: 'fechar', 
        id: caixaId, 
        litragem: formData,
        dinheiro_final: parseBRL(formData.dinheiro_final || '0')
      });
      hideSpinner();
      if (resp.ok) {
        closeModal('modal-fechar');
        showToast('Caixa fechado com sucesso!', 'success');

        // Pergunta qual comprovante abrir
        setTimeout(() => {
          confirmDelete('Deseja imprimir o comprovante COMPLETO ou RESUMIDO?', () => {
            window.open(`/administrator/comprovante.php?id=${caixaId}&mode=completo`, '_blank');
            location.reload();
          });
          const btnOk = document.getElementById('global-confirm-ok');
          const btnCancel = document.getElementById('global-confirm-cancel');
          if (btnOk) btnOk.textContent = 'Completo';
          if (btnCancel) {
              btnCancel.textContent = 'Resumido';
              btnCancel.classList.remove('btn-ghost');
              btnCancel.classList.add('btn-primary');
              const newCancel = btnCancel.cloneNode(true);
              btnCancel.replaceWith(newCancel);
              newCancel.addEventListener('click', () => {
                  document.getElementById('global-confirm').classList.remove('open');
                  window.open(`/administrator/comprovante.php?id=${caixaId}&mode=resumido`, '_blank');
                  location.reload();
              });
          }
        }, 500);
      } else showToast(resp.msg || 'Erro ao fechar caixa.', 'error');
    }

    async function salvarConfig(e) {
      e.preventDefault();
      const btn = document.getElementById('btnSalvarConfig');
      btn.disabled = true; btn.textContent = 'Salvando...';
      try {
        const formData = new FormData(e.target);
        const data = {
          abertura: formData.get('abertura'),
          fechamento: formData.get('fechamento'),
          vendas_pagamento_detalhado: formData.get('vendas_pagamento_detalhado') ? 1 : 0
        };
        const resp = await postJSON('/administrator/ajax/salvar_config_caixa.php', data);
        if (resp.ok) {
          showToast('Configurações salvas!', 'success');
        } else {
          showToast(resp.msg || 'Erro ao salvar.', 'error');
        }
      } catch (err) {
        showToast('Erro de comunicação.', 'error');
      }
      btn.disabled = false; btn.textContent = '💾 Salvar Configurações';
    }

    async function excluirVenda(id) {
      if (!confirm('Tem certeza que deseja EXCLUIR esta venda? O estoque será devolvido e os valores estornados do caixa.')) return;
      
      const resp = await postJSON('/administrator/ajax/excluir_venda.php', { id });
      if (resp.ok) {
        showToast('Venda excluída com sucesso!', 'success');
        location.reload(); 
      } else {
        showToast(resp.msg || 'Erro ao excluir venda.', 'error');
      }
    }

    function switchTab(el, tabId) {
      document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
      el.classList.add('active');
      document.getElementById(tabId).classList.add('active');
    }

    async function excluirLancamento(id) {
      if (!confirm('Tem certeza que deseja EXCLUIR este lançamento manual?')) return;
      
      const resp = await postJSON('/administrator/ajax/excluir_lancamento.php', { id });
      if (resp.ok) {
        showToast('Lançamento excluído!', 'success');
        location.reload();
      } else {
        showToast(resp.msg || 'Erro ao excluir.', 'error');
      }
    }

    async function salvarEstoqueInicial(id) {
      const litros = document.getElementById('litros_init_' + id).value;
      const altura = document.getElementById('altura_init_' + id).value;
      
      showSpinner('Salvando...');
      const resp = await postJSON('/administrator/ajax/fechar_caixa.php', {
        acao: 'editar_estoque',
        id_registro: id,
        litragem_inicial: litros,
        altura_inicial: altura
      });
      hideSpinner();
      
      if (resp.ok) {
        showToast('Estoque inicial atualizado!', 'success');
      } else {
        showToast(resp.msg || 'Erro ao salvar.', 'error');
      }
    }
  </script>
  <script>
    // Inicializa máscaras
    document.querySelectorAll('.mask-money').forEach(maskMoney);
  </script>
</body>

</html>