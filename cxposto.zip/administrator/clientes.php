<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('admin');

$db = getDB();
$clientes = $db->query("SELECT * FROM usuarios WHERE tipo='operador' ORDER BY nome ASC")->fetchAll();

function getEscalaStatus($dataBase)
{
  if (!$dataBase)
    return ['text' => 'Não definida', 'class' => 'badge-neutral'];
  $hoje = new DateTime(date('Y-m-d'));
  $base = new DateTime($dataBase);
  $diff = $hoje->diff($base)->days;
  $emTurno = ($diff % 2 == 0);
  return [
    'text' => $emTurno ? 'Turno Hoje' : 'Folga Hoje',
    'class' => $emTurno ? 'badge-success' : 'badge-danger'
  ];
}

$page_id = 'clientes';
$page_title = 'Operadores — Convênio Posto';
$topbar_custom_actions = '<button class="btn btn-primary btn-sm" onclick="openModal(\'modal-novo\')">+ Novo Usuário</button>';
include __DIR__ . '/../includes/navbar_admin.php'; 
?>

      <div class="page-body">
        <div class="card fade-in">
          <div class="card-header">
            <span class="card-title">👥 Usuários Cadastrados</span>
            <span class="badge badge-info"><?= count($clientes) ?> usuários</span>
          </div>
          <?php if ($clientes): ?>
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Nome</th>
                    <th>Login</th>
                    <th>Nível</th>
                    <th>Status Conta</th>
                    <th>Escala (Dia Sim/Não)</th>
                    <th>Cadastrado em</th>
                    <th>Ações</th>
                  </tr>
                </thead>
                <tbody id="tbody-clientes">
                  <?php foreach ($clientes as $c): ?>
                    <tr id="row-<?= $c['id'] ?>">
                      <td><strong><?= htmlspecialchars($c['nome']) ?></strong></td>
                      <td><code
                          style="background:var(--bg-input);padding:.2rem .5rem;border-radius:4px;"><?= htmlspecialchars($c['login']) ?></code>
                      </td>
                      <td>
                        <span class="badge <?= $c['tipo'] === 'admin' ? 'badge-primary' : 'badge-ghost' ?>">
                          <?= ucfirst($c['tipo']) ?>
                        </span>
                      </td>
                      <td>
                        <?php if ($c['ativo']): ?>
                          <span class="badge badge-success">Ativa</span>
                        <?php else: ?>
                          <span class="badge badge-danger">Inativa</span>
                        <?php endif; ?>
                      </td>
                      <td>
                        <?php $esc = getEscalaStatus($c['data_base_escala']); ?>
                        <span class="badge <?= $esc['class'] ?>"><?= $esc['text'] ?></span>
                        <?php if ($c['data_base_escala']): ?>
                          <div class="text-xs text-muted" style="margin-top:2px;">Início:
                            <?= date('d/m/Y', strtotime($c['data_base_escala'])) ?></div>
                        <?php endif; ?>
                      </td>
                      <td class="text-muted text-sm"><?= date('d/m/Y', strtotime($c['criado_em'])) ?></td>
                      <td>
                        <div style="display:flex;gap:.4rem;">
                          <button class="btn btn-ghost btn-sm"
                            onclick="abrirEditar(<?= $c['id'] ?>,'<?= addslashes($c['nome']) ?>','<?= addslashes($c['login']) ?>','<?= $c['data_base_escala'] ?>','<?= $c['tipo'] ?>')">
                            ✏️ Editar
                          </button>
                          <?php if ($c['ativo']): ?>
                            <button class="btn btn-danger btn-sm" onclick="toggleStatus(<?= $c['id'] ?>, 0)">🚫
                              Desativar</button>
                          <?php else: ?>
                            <button class="btn btn-success btn-sm" onclick="toggleStatus(<?= $c['id'] ?>, 1)">✅
                              Ativar</button>
                          <?php endif; ?>
                          <button class="btn btn-danger btn-sm" onclick="excluirCliente(<?= $c['id'] ?>)">🗑️</button>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          <?php else: ?>
            <div class="empty-state"><span class="empty-icon">👥</span>
              <p>Nenhum operador cadastrado.</p>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>

  <!-- MODAL NOVO -->
  <div class="modal-overlay" id="modal-novo">
    <div class="modal">
      <div class="modal-header">
        <span class="modal-title">➕ Novo Operador</span>
        <button class="modal-close" onclick="closeModal('modal-novo')">×</button>
      </div>
      <div class="modal-body">
        <form id="form-novo" onsubmit="salvarNovo(event)">
          <div class="form-group">
            <label class="form-label">Nome Completo</label>
            <input name="nome" class="form-control" placeholder="Ex: João Silva" required>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Login</label>
              <input name="login" class="form-control" placeholder="Ex: joao.silva" required>
            </div>
            <div class="form-group">
              <label class="form-label">Senha</label>
              <input name="senha" type="password" class="form-control" placeholder="Mínimo 6 caracteres" required
                minlength="6">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Tipo de Acesso</label>
              <select name="tipo" class="form-control" required>
                <option value="operador">Operador</option>
                <option value="admin">Administrador</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Data Base da Escala (Primeiro dia)</label>
              <input name="data_base_escala" type="date" class="form-control" required value="<?= date('Y-m-d') ?>">
            </div>
          </div>
          <small class="text-muted">A escala de "dia sim/dia não" só se aplica a Operadores.</small>
        </form>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('modal-novo')">Cancelar</button>
        <button class="btn btn-primary" onclick="document.getElementById('form-novo').requestSubmit()">Salvar</button>
      </div>
    </div>
  </div>

  <!-- MODAL EDITAR -->
  <div class="modal-overlay" id="modal-editar">
    <div class="modal">
      <div class="modal-header">
        <span class="modal-title">✏️ Editar Operador</span>
        <button class="modal-close" onclick="closeModal('modal-editar')">×</button>
      </div>
      <div class="modal-body">
        <form id="form-editar" onsubmit="salvarEditar(event)">
          <input type="hidden" id="edit-id" name="id">
          <div class="form-group">
            <label class="form-label">Nome Completo</label>
            <input id="edit-nome" name="nome" class="form-control" required>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Login</label>
              <input id="edit-login" name="login" class="form-control" required>
            </div>
            <div class="form-group">
              <label class="form-label">Nova Senha <span class="text-muted">(deixe em branco para manter)</span></label>
              <input name="senha" type="password" class="form-control" placeholder="••••••">
            </div>
          </div>
          <div class="form-row">
            <div class="form-group">
              <label class="form-label">Tipo de Acesso</label>
              <select id="edit-tipo" name="tipo" class="form-control" required>
                <option value="operador">Operador</option>
                <option value="admin">Administrador</option>
              </select>
            </div>
            <div class="form-group">
              <label class="form-label">Data Base da Escala</label>
              <input id="edit-escala" name="data_base_escala" type="date" class="form-control" required>
            </div>
          </div>
        </form>
      </div>
      <div class="modal-footer">
        <button class="btn btn-ghost" onclick="closeModal('modal-editar')">Cancelar</button>
        <button class="btn btn-primary" onclick="document.getElementById('form-editar').requestSubmit()">Salvar</button>
      </div>
    </div>
  </div>

  <script src="/assets/js/main.js?v=<?= time() ?>"></script>
  <script>
    function abrirEditar(id, nome, login, escala, tipo) {
      document.getElementById('edit-id').value = id;
      document.getElementById('edit-nome').value = nome;
      document.getElementById('edit-login').value = login;
      document.getElementById('edit-escala').value = escala;
      document.getElementById('edit-tipo').value = tipo;
      openModal('modal-editar');
    }

    async function salvarNovo(e) {
      e.preventDefault();
      const data = serializeForm(e.target);
      const resp = await postJSON('/administrator/ajax/salvar_cliente.php', { acao: 'criar', ...data });
      if (resp.ok) { showToast('Usuário cadastrado!', 'success'); closeModal('modal-novo'); location.reload(); }
      else showToast(resp.msg || 'Erro ao cadastrar.', 'error');
    }

    async function salvarEditar(e) {
      e.preventDefault();
      const data = serializeForm(e.target);
      const resp = await postJSON('/administrator/ajax/salvar_cliente.php', { acao: 'editar', ...data });
      if (resp.ok) { showToast('Usuário atualizado!', 'success'); closeModal('modal-editar'); location.reload(); }
      else showToast(resp.msg || 'Erro ao atualizar.', 'error');
    }

    async function toggleStatus(id, ativo) {
      const msg = ativo ? 'Ativar este operador?' : 'Desativar este operador?';
      confirmDelete(msg, async () => {
        const resp = await postJSON('/administrator/ajax/salvar_cliente.php', { acao: 'toggle', id, ativo });
        if (resp.ok) { showToast('Status alterado!', 'success'); location.reload(); }
        else showToast(resp.msg, 'error');
      });
    }

    async function excluirCliente(id) {
      confirmDelete('Excluir permanentemente este operador? Isso não pode ser desfeito.', async () => {
        const resp = await postJSON('/administrator/ajax/excluir_cliente.php', { id });
        if (resp.ok) { document.getElementById('row-' + id)?.remove(); showToast('Operador excluído.', 'success'); }
        else showToast(resp.msg, 'error');
      });
    }
  </script>
</body>

</html>