<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('admin');

$db = getDB();

// --- Filtering Logic ---
$where = [];
$params = [];

// Filter by status
$status = $_GET['status'] ?? 'todos';
if ($status === 'ativo') {
    $where[] = "v.status = 'ativo'";
} elseif ($status === 'revogado') {
    $where[] = "v.status = 'revogado'";
}

// Filter by date
$data_inicio = $_GET['data_inicio'] ?? '';
$data_fim = $_GET['data_fim'] ?? '';
if ($data_inicio && $data_fim) {
    $where[] = "DATE(v.criado_em) BETWEEN ? AND ?";
    $params[] = $data_inicio;
    $params[] = $data_fim;
}

// Filter by client
$cliente_id = $_GET['cliente_id'] ?? '';
if ($cliente_id) {
    $where[] = "v.cliente_id = ?";
    $params[] = (int)$cliente_id;
}

$sql = "SELECT v.*, c.nome as nome_cliente_cadastrado FROM vales v LEFT JOIN clientes_abastecimento c ON v.cliente_id = c.id";
if (!empty($where)) {
    $sql .= " WHERE " . implode(' AND ', $where);
}
$sql .= " ORDER BY v.criado_em DESC";

$stmt = $db->prepare($sql);
$stmt->execute($params);
$vales = $stmt->fetchAll();

// Data for modals
$clientes_abastecimento = $db->query("SELECT * FROM clientes_abastecimento WHERE ativo = 1 ORDER BY nome ASC")->fetchAll();
$combustiveis = $db->query("SELECT id, nome, preco FROM combustiveis ORDER BY nome ASC")->fetchAll();

// Check for open cash register
$caixaAberto = $db->query("SELECT id FROM caixas WHERE status='aberto' LIMIT 1")->fetch();

$page_id = 'vales'; // This ID should be added to the sidebar function if it's a new main page
$page_title = 'Vales de Abastecimento — Convênio Posto';
$topbar_custom_actions = '<a href="/administrator/relatorio_vales_diario.php" target="_blank" class="btn btn-info btn-sm">Relatório Diário</a> <a href="/administrator/comprovante_vales_empresa.php" target="_blank" class="btn btn-ghost btn-sm">Por Empresa</a> <button class="btn btn-primary btn-sm" onclick="openModal(\'modal-novo-cliente\')">+ Novo Cliente</button> <button class="btn btn-success btn-sm" onclick="abrirModalVale()">+ Novo Vale</button>';

include __DIR__ . '/../includes/navbar_admin.php';
?>

<div class="page-body">
  <div class="card fade-in">
    <div class="card-header">
      <span class="card-title">🎟️ Vales de Abastecimento</span>
      <span class="badge badge-info"><?= count($vales) ?> vales</span>
    </div>

    <!-- Filter Form -->
    <div class="card-filters">
      <form method="GET" class="form-row" style="align-items: flex-end;">
        <div class="form-group">
          <label class="form-label">Data Início</label>
          <input type="date" name="data_inicio" class="form-control" value="<?= htmlspecialchars($data_inicio) ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Data Fim</label>
          <input type="date" name="data_fim" class="form-control" value="<?= htmlspecialchars($data_fim) ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Cliente</label>
          <select name="cliente_id" class="form-control">
            <option value="">Todos</option>
            <?php foreach ($clientes_abastecimento as $cli): ?>
              <option value="<?= $cli['id'] ?>" <?= ($cliente_id == $cli['id']) ? 'selected' : '' ?>><?= htmlspecialchars($cli['nome']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">Status</label>
          <select name="status" class="form-control">
            <option value="todos" <?= ($status == 'todos') ? 'selected' : '' ?>>Todos</option>
            <option value="ativo" <?= ($status == 'ativo') ? 'selected' : '' ?>>Ativo</option>
            <option value="revogado" <?= ($status == 'revogado') ? 'selected' : '' ?>>Revogado</option>
          </select>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary">Filtrar</button>
          <a href="/administrator/vales.php" class="btn btn-ghost">Limpar</a>
        </div>
      </form>
    </div>

    <?php if ($vales): ?>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Cliente</th>
            <th>Combustível</th>
            <th>Litros</th>
            <th>Valor</th>
            <th>Status</th>
            <th>Data</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($vales as $v): ?>
          <tr id="row-vale-<?= $v['id'] ?>">
            <td><small class="text-muted">#<?= $v['id'] ?></small></td>
            <td>
              <strong><?= htmlspecialchars($v['nome_cliente']) ?></strong>
              <div class="text-xs text-muted"><?= htmlspecialchars($v['placa'] ?? '') ?></div>
            </td>
            <td><?= htmlspecialchars($v['nome_combustivel']) ?></td>
            <td class="fw-bold"><?= number_format($v['quantidade'], 2, ',', '.') ?> L</td>
            <td class="text-accent fw-bold">R$ <?= number_format($v['valor_total'], 2, ',', '.') ?></td>
            <td>
              <?php if ($v['status'] === 'ativo'): ?>
                <span class="badge badge-success">Ativo</span>
              <?php else: ?>
                <span class="badge badge-danger">Revogado</span>
              <?php endif; ?>
            </td>
            <td class="text-sm"><?= date('d/m/Y H:i', strtotime($v['criado_em'])) ?></td>
            <td>
              <div style="display:flex;gap:.4rem;">
                <button class="btn btn-ghost btn-sm" onclick="imprimirVale(<?= $v['id'] ?>)" title="Imprimir Comprovante">🖨️</button>
                <?php if ($v['status'] === 'ativo' && $caixaAberto): ?>
                  <button class="btn btn-ghost btn-sm" onclick="abrirModalVale(<?= $v['id'] ?>)" title="Editar Vale">✏️</button>
                  <button class="btn btn-danger btn-sm" onclick="revogarVale(<?= $v['id'] ?>)" title="Revogar Vale">🚫</button>
                <?php endif; ?>
              </div>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php else: ?>
      <div class="empty-state"><span class="empty-icon">🎟️</span><p>Nenhum vale encontrado para os filtros aplicados.</p></div>
    <?php endif; ?>
  </div>
</div>
</div>
</div>

<!-- MODAL NOVO/EDITAR CLIENTE -->
<div class="modal-overlay" id="modal-novo-cliente">
  <div class="modal" style="max-width:500px;">
    <div class="modal-header">
      <span class="modal-title">👤 Cliente de Abastecimento</span>
      <button class="modal-close" onclick="closeModal('modal-novo-cliente')">×</button>
    </div>
    <div class="modal-body">
      <form id="form-cliente" onsubmit="salvarCliente(event)">
        <input type="hidden" name="id" id="cliente-id">
        <div class="form-group">
          <label class="form-label">Nome do Cliente</label>
          <input name="nome" id="cliente-nome" class="form-control" placeholder="Ex: João da Silva" required>
        </div>
        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Empresa (Opcional)</label>
                <input name="empresa" id="cliente-empresa" class="form-control" placeholder="Ex: Minha Empresa LTDA">
            </div>
            <div class="form-group">
                <label class="form-label">Carro (Opcional)</label>
                <input name="carro" id="cliente-carro" class="form-control" placeholder="Ex: Fiat Uno">
            </div>
        </div>
        <div class="form-group">
            <label class="form-label">Placa (Opcional)</label>
            <input name="placa" id="cliente-placa" class="form-control" placeholder="Ex: ABC-1234">
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-novo-cliente')">Cancelar</button>
      <button class="btn btn-primary" onclick="document.getElementById('form-cliente').requestSubmit()">Salvar Cliente</button>
    </div>
  </div>
</div>

<!-- MODAL NOVO/EDITAR VALE -->
<div class="modal-overlay" id="modal-novo-vale">
  <div class="modal" style="max-width:650px;">
    <div class="modal-header">
      <span class="modal-title">🎟️ Novo Vale de Abastecimento</span>
      <button class="modal-close" onclick="closeModal('modal-novo-vale')">×</button>
    </div>
    <div class="modal-body">
      <form id="form-vale" onsubmit="salvarVale(event)">
        <input type="hidden" name="id" id="vale-id">
        
        <div class="form-group">
            <label class="form-label">Cliente</label>
            <select name="cliente_id" id="vale-cliente-id" class="form-control" onchange="selecionarCliente(this.value)">
                <option value="0">-- Cliente Avulso (preencher manualmente) --</option>
                <?php foreach ($clientes_abastecimento as $cli): ?>
                <option value="<?= $cli['id'] ?>" data-nome="<?= htmlspecialchars($cli['nome']) ?>" data-empresa="<?= htmlspecialchars($cli['empresa'] ?? '') ?>" data-carro="<?= htmlspecialchars($cli['carro'] ?? '') ?>" data-placa="<?= htmlspecialchars($cli['placa'] ?? '') ?>"><?= htmlspecialchars($cli['nome']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Nome (para o vale)</label>
                <input name="nome_cliente" id="vale-nome" class="form-control" required>
            </div>
            <div class="form-group">
                <label class="form-label">Empresa</label>
                <input name="empresa" id="vale-empresa" class="form-control">
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label class="form-label">Carro</label>
                <input name="carro" id="vale-carro" class="form-control">
            </div>
            <div class="form-group">
                <label class="form-label">Placa</label>
                <input name="placa" id="vale-placa" class="form-control">
            </div>
            <div class="form-group">
                <label class="form-label">KM</label>
                <input type="number" step="0.1" name="km" id="vale-km" class="form-control">
            </div>
        </div>

        <hr style="border-color: var(--border); margin: 1.5rem 0;">

        <div class="form-row">
            <div class="form-group" style="flex: 2;">
                <label class="form-label">Combustível</label>
                <select name="combustivel_id" id="vale-combustivel" class="form-control" required onchange="calcularVale('litros')">
                    <option value="">Selecione...</option>
                    <?php foreach ($combustiveis as $cb): ?>
                    <option value="<?= $cb['id'] ?>" data-preco="<?= $cb['preco'] ?>"><?= htmlspecialchars($cb['nome']) ?> (R$ <?= number_format($cb['preco'], 3, ',', '.') ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label class="form-label">Quantidade (L)</label>
                <input type="number" step="0.01" min="0" name="quantidade" id="vale-quantidade" class="form-control" oninput="calcularVale('litros')">
            </div>
            <div class="form-group">
                <label class="form-label">Valor Total (R$)</label>
                <input type="number" step="0.01" min="0" name="valor_total" id="vale-valor" class="form-control" oninput="calcularVale('valor')">
            </div>
        </div>

        <div class="form-group">
            <label class="form-label">Descrição / Observações</label>
            <textarea name="descricao" id="vale-descricao" class="form-control" rows="2"></textarea>
        </div>

      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-novo-vale')">Cancelar</button>
      <button class="btn btn-primary" onclick="document.getElementById('form-vale').requestSubmit()">Salvar Vale</button>
    </div>
  </div>
</div>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="/assets/js/main.js?v=<?= time() ?>"></script>
<script>
const combustiveis = <?= json_encode(array_column($combustiveis, null, 'id')) ?>;
const caixaAbertoId = <?= $caixaAberto ? $caixaAberto['id'] : 'null' ?>;

async function salvarCliente(e) {
  e.preventDefault();
  const data = serializeForm(e.target);
  // NOTE: This requires a backend endpoint, e.g., /administrator/ajax/gerenciar_vales.php
  const resp = await postJSON('/administrator/ajax/gerenciar_vales.php', { acao:'salvar_cliente', ...data });
  if (resp.ok) {
    showToast('Cliente salvo com sucesso!', 'success');
    location.reload();
  } else {
    showToast(resp.msg || 'Erro ao salvar cliente.', 'error');
  }
}

function selecionarCliente(clienteId) {
    const form = document.getElementById('form-vale');
    if (clienteId && clienteId != "0") {
        const option = document.querySelector(`#vale-cliente-id option[value='${clienteId}']`);
        form.querySelector('#vale-nome').value = option.dataset.nome;
        form.querySelector('#vale-empresa').value = option.dataset.empresa;
        form.querySelector('#vale-carro').value = option.dataset.carro;
        form.querySelector('#vale-placa').value = option.dataset.placa;
    } else {
        form.querySelector('#vale-nome').value = '';
        form.querySelector('#vale-empresa').value = '';
        form.querySelector('#vale-carro').value = '';
        form.querySelector('#vale-placa').value = '';
        form.querySelector('#vale-nome').focus();
    }
}

function calcularVale(source) {
    const combustivelId = document.getElementById('vale-combustivel').value;
    const inputQtd = document.getElementById('vale-quantidade');
    const inputVal = document.getElementById('vale-valor');

    if (!combustivelId) {
        if ((source === 'litros' && inputQtd.value) || (source === 'valor' && inputVal.value)) {
            showToast('Selecione um combustível primeiro.', 'warning');
            if (source === 'litros') inputQtd.value = '';
            if (source === 'valor') inputVal.value = '';
        }
        return;
    }

    const preco = parseFloat(combustiveis[combustivelId].preco);

    if (source === 'litros') {
        const qtd = parseFloat(inputQtd.value) || 0;
        inputVal.value = (qtd > 0) ? (qtd * preco).toFixed(2) : '';
    } else if (source === 'valor') {
        const val = parseFloat(inputVal.value) || 0;
        inputQtd.value = (val > 0) ? (val / preco).toFixed(2) : '';
    }
}

async function abrirModalVale(valeId = null) {
    if (!caixaAbertoId) {
        showToast('É necessário ter um caixa aberto para criar ou editar vales.', 'warning');
        return;
    }
    
    const form = document.getElementById('form-vale');
    form.reset();
    document.getElementById('vale-id').value = '';

    if (valeId) {
        const resp = await postJSON('/administrator/ajax/gerenciar_vales.php', { acao: 'obter_vale', id: valeId });
        if (resp.ok && resp.vale) {
            const v = resp.vale;
            document.querySelector('#modal-novo-vale .modal-title').textContent = '✏️ Editar Vale #' + v.id;
            document.getElementById('vale-id').value = v.id;
            document.getElementById('vale-cliente-id').value = v.cliente_id || 0;
            document.getElementById('vale-nome').value = v.nome_cliente;
            document.getElementById('vale-empresa').value = v.empresa;
            document.getElementById('vale-carro').value = v.carro;
            document.getElementById('vale-placa').value = v.placa;
            document.getElementById('vale-km').value = v.km;
            document.getElementById('vale-combustivel').value = v.combustivel_id;
            document.getElementById('vale-quantidade').value = v.quantidade;
            document.getElementById('vale-valor').value = v.valor_total;
            document.getElementById('vale-descricao').value = v.descricao;
        } else {
            showToast(resp.msg || 'Erro ao carregar dados do vale.', 'error');
            return;
        }
    } else {
        document.querySelector('#modal-novo-vale .modal-title').textContent = '🎟️ Novo Vale de Abastecimento';
    }

    openModal('modal-novo-vale');
}

async function salvarVale(e) {
    e.preventDefault();
    const data = serializeForm(e.target);
    
    if (!caixaAbertoId) {
        showToast('Caixa fechado. Não é possível salvar o vale.', 'error');
        return;
    }

    const resp = await postJSON('/administrator/ajax/gerenciar_vales.php', { 
        acao: data.id ? 'editar_vale' : 'criar_vale',
        caixa_id: caixaAbertoId,
        ...data 
    });

    if (resp.ok) {
        showToast('Vale salvo com sucesso!', 'success');
        location.reload();
    } else {
        showToast(resp.msg || 'Erro ao salvar o vale.', 'error');
    }
}

async function revogarVale(valeId) {
    confirmDelete('Deseja realmente revogar este vale? Esta ação não pode ser desfeita.', async () => {
        const resp = await postJSON('/administrator/ajax/gerenciar_vales.php', { acao: 'revogar_vale', id: valeId });
        if (resp.ok) {
            showToast('Vale revogado.', 'success');
            location.reload();
        } else {
            showToast(resp.msg || 'Erro ao revogar o vale.', 'error');
        }
    });
}

function imprimirVale(valeId) {
    window.open(`/administrator/comprovante_vale.php?id=${valeId}`, '_blank');
}

</script>
</body>
</html>