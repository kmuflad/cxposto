<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('admin');

$db = getDB();
$total_produtos = $db->query("SELECT COUNT(*) FROM produtos")->fetchColumn();

$page_id = 'produtos';
$page_title = 'Produtos — Convênio Posto';
$topbar_custom_actions = '<button class="btn btn-primary btn-sm" onclick="openModal(\'modal-novo\')">+ Novo Produto</button>';
include __DIR__ . '/../includes/navbar_admin.php'; 
?>

    <div class="page-body">
      <!-- Filtro rápido -->
      <div class="card fade-in" style="margin-bottom:1rem;padding:1rem;">
        <input type="text" id="filtro" class="form-control" placeholder="🔍 Filtrar por nome ou código de barras..."
               oninput="filtrarTabela(this.value)">
      </div>

      <div class="card fade-in">
        <div class="card-header">
          <span class="card-title">📦 Produtos Cadastrados</span>
          <span class="badge badge-info"><?= $total_produtos ?> produtos (listando últimos 100)</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>Nome</th><th>Código de Barras</th><th>Valor</th><th>Estoque</th><th>Status</th><th>Ações</th></tr>
            </thead>
            <tbody id="tbody-produtos">
            </tbody>
          </table>
        </div>
        <div id="empty-state-produtos" class="empty-state" style="display:none;"><span class="empty-icon">📦</span><p>Nenhum produto encontrado.</p></div>
      </div>
    </div>
  </div>
</div>

<!-- MODAL NOVO -->
<div class="modal-overlay" id="modal-novo">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">➕ Novo Produto</span>
      <button class="modal-close" onclick="closeModal('modal-novo')">×</button>
    </div>
    <div class="modal-body">
      <form id="form-novo" onsubmit="salvarNovo(event)">
        <div class="form-group">
          <label class="form-label">Nome do Produto</label>
          <input name="nome" class="form-control" placeholder="Ex: Água Mineral 500ml" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Código de Barras</label>
            <div style="display:flex;gap:.4rem;">
              <input name="codigo_barras" id="novo-cod" class="form-control" placeholder="Ex: 7891000315507">
              <button type="button" class="btn btn-ghost btn-sm" style="flex-shrink:0;"
                      onclick="generateRandomBarcode('novo-cod')" title="Gerar Aleatório">🎲</button>
              <button type="button" class="btn btn-ghost btn-sm" style="flex-shrink:0;"
                      onclick="openBarcodeCamera(c => document.getElementById('novo-cod').value = c)"
                      title="Câmera">📷</button>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Valor (R$)</label>
            <input name="valor" type="number" step="0.01" min="0" class="form-control" placeholder="0,00" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Estoque Inicial</label>
          <input name="estoque" type="number" min="0" class="form-control" placeholder="0" value="0" required>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-novo')">Cancelar</button>
      <button class="btn btn-primary" onclick="document.getElementById('form-novo').requestSubmit()">Salvar</button>
    </div>
  </div>
</div>

<!-- MODAL EDITAR -->
<div class="modal-overlay" id="modal-editar">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title">✏️ Editar Produto</span>
      <button class="modal-close" onclick="closeModal('modal-editar')">×</button>
    </div>
    <div class="modal-body">
      <form id="form-editar" onsubmit="salvarEditar(event)">
        <input type="hidden" id="edit-id" name="id">
        <div class="form-group">
          <label class="form-label">Nome do Produto</label>
          <input id="edit-nome" name="nome" class="form-control" required>
        </div>
        <div class="form-row">
          <div class="form-group">
            <label class="form-label">Código de Barras</label>
            <div style="display:flex;gap:.4rem;">
              <input id="edit-cod" name="codigo_barras" class="form-control">
              <button type="button" class="btn btn-ghost btn-sm" style="flex-shrink:0;"
                      onclick="generateRandomBarcode('edit-cod')" title="Gerar Aleatório">🎲</button>
              <button type="button" class="btn btn-ghost btn-sm" style="flex-shrink:0;"
                      onclick="openBarcodeCamera(c => document.getElementById('edit-cod').value = c)"
                      title="Câmera">📷</button>
            </div>
          </div>
          <div class="form-group">
            <label class="form-label">Valor (R$)</label>
            <input id="edit-valor" name="valor" type="number" step="0.01" min="0" class="form-control" required>
          </div>
        </div>
        <div class="form-group">
          <label class="form-label">Estoque</label>
          <input id="edit-estoque" name="estoque" type="number" min="0" class="form-control" required>
        </div>
      </form>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-editar')">Cancelar</button>
      <button class="btn btn-primary" onclick="document.getElementById('form-editar').requestSubmit()">Salvar</button>
    </div>
  </div>
</div>

<!-- MODAL CÂMERA -->
<div class="modal-overlay" id="modal-camera">
  <div class="modal" style="max-width:480px;">
    <div class="modal-header">
      <span class="modal-title">📷 Leitor de Código de Barras</span>
      <button class="modal-close" onclick="closeBarcodeCamera()">×</button>
    </div>
    <div class="modal-body" style="padding:1rem;">
      <div style="position:relative;background:#000;border-radius:10px;overflow:hidden;aspect-ratio:4/3;">
        <video id="barcode-video" playsinline muted style="width:100%;height:100%;object-fit:cover;display:block;"></video>
        <div style="position:absolute;left:10%;right:10%;top:50%;height:2px;background:rgba(251,146,60,.7);box-shadow:0 0 8px var(--accent);animation:scanLine 2s linear infinite;"></div>
      </div>
      <p id="barcode-status" style="text-align:center;margin-top:.75rem;font-size:.85rem;color:#93c5fd;">Iniciando câmera...</p>
      <div style="margin-top:1rem;">
        <label class="form-label">Ou digite manualmente:</label>
        <div style="display:flex;gap:.5rem;">
          <input type="text" id="manual-code" class="form-control" placeholder="Ex: 7891000315507"
                 onkeydown="if(event.key==='Enter') manualBarcode()">
          <button class="btn btn-primary" onclick="manualBarcode()">OK</button>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
@keyframes scanLine { 0%{top:20%} 50%{top:80%} 100%{top:20%} }
</style>

<script src="/assets/js/main.js?v=<?= time() ?>"></script>
<script src="/assets/js/barcode.js?v=<?= time() ?>"></script>
<script>
let _barcodeCallback = null;

function generateRandomBarcode(id) {
  const el = document.getElementById(id);
  if (!el) return;
  let code = '';
  for (let i = 0; i < 13; i++) {
    code += Math.floor(Math.random() * 10);
  }
  el.value = code;
}

function abrirEditar(p) {
  document.getElementById('edit-id').value      = p.id;
  document.getElementById('edit-nome').value    = p.nome;
  document.getElementById('edit-cod').value     = p.codigo_barras || '';
  document.getElementById('edit-valor').value   = p.valor;
  document.getElementById('edit-estoque').value = p.estoque;
  openModal('modal-editar');
}

async function salvarNovo(e) {
  e.preventDefault();
  const data = serializeForm(e.target);
  const resp = await postJSON('/administrator/ajax/salvar_produto.php', { acao:'criar', ...data });
  if (resp.ok) { 
    showToast('Produto cadastrado!', 'success'); 
    closeModal('modal-novo'); 
    carregarProdutos(document.getElementById('filtro').value); 
    e.target.reset();
  }
  else showToast(resp.msg || 'Erro ao cadastrar.', 'error');
}

async function salvarEditar(e) {
  e.preventDefault();
  const data = serializeForm(e.target);
  const resp = await postJSON('/administrator/ajax/salvar_produto.php', { acao:'editar', ...data });
  if (resp.ok) { 
    showToast('Produto atualizado!', 'success'); 
    closeModal('modal-editar'); 
    carregarProdutos(document.getElementById('filtro').value); 
  }
  else showToast(resp.msg || 'Erro ao atualizar.', 'error');
}

async function excluirProduto(id) {
  confirmDelete('Excluir este produto permanentemente?', async () => {
    const resp = await postJSON('/administrator/ajax/excluir_produto.php', { id });
    if (resp.ok) { document.getElementById('row-p'+id)?.remove(); showToast('Produto excluído.', 'success'); }
    else showToast(resp.msg, 'error');
  });
}

let debounceTimer;
function filtrarTabela(q) {
  const query = q.toLowerCase().trim();
  const rows = document.querySelectorAll('#tbody-produtos tr');
  let encontrou = false;

  // Filtro local instantâneo (melhor UX)
  rows.forEach(row => {
    const texto = row.innerText.toLowerCase();
    if (texto.includes(query)) {
      row.style.display = '';
      encontrou = true;
    } else {
      row.style.display = 'none';
    }
  });

  const emptyState = document.getElementById('empty-state-produtos');
  if (emptyState) emptyState.style.display = encontrou ? 'none' : 'flex';

  // Sincroniza com o servidor para garantir dados novos (opcional, com debounce)
  clearTimeout(debounceTimer);
  debounceTimer = setTimeout(() => {
    carregarProdutos(q);
  }, 500);
}

async function carregarProdutos(q = '') {
  try {
    const res = await fetch('/administrator/ajax/listar_produtos.php?q=' + encodeURIComponent(q));
    const produtos = await res.json();
    const tbody = document.getElementById('tbody-produtos');
    const emptyState = document.getElementById('empty-state-produtos');
    
    if (produtos.length === 0) {
      tbody.innerHTML = '';
      emptyState.style.display = 'flex';
      return;
    }
    emptyState.style.display = 'none';
    
    let html = '';
    produtos.forEach(p => {
      const pJson = JSON.stringify(p).replace(/"/g, '&quot;');
      const valor = parseFloat(p.valor).toLocaleString('pt-BR', {minimumFractionDigits: 2, maximumFractionDigits: 2});
      const estoqueClass = p.estoque > 5 ? 'text-success' : (p.estoque > 0 ? 'text-accent' : 'text-danger');
      const badge = p.ativo == 1 ? '<span class="badge badge-success">Ativo</span>' : '<span class="badge badge-danger">Inativo</span>';
      const codBar = p.codigo_barras ? `<code style="background:var(--bg-input);padding:.2rem .5rem;border-radius:4px;">${p.codigo_barras}</code>` : `<span class="text-muted text-sm">—</span>`;
      
      html += `
      <tr id="row-p${p.id}">
        <td><strong>${p.nome}</strong></td>
        <td>${codBar}</td>
        <td class="text-accent fw-bold">R$ ${valor}</td>
        <td><span class="${estoqueClass} fw-bold">${p.estoque}</span></td>
        <td>${badge}</td>
        <td>
          <div style="display:flex;gap:.4rem;">
            <button class="btn btn-ghost btn-sm" onclick="abrirEditar(${pJson})">✏️</button>
            <button class="btn btn-danger btn-sm" onclick="excluirProduto(${p.id})">🗑️</button>
          </div>
        </td>
      </tr>`;
    });
    tbody.innerHTML = html;
  } catch (e) {
    console.error(e);
  }
}

document.addEventListener('DOMContentLoaded', () => carregarProdutos());

function manualBarcode() {
  const code = document.getElementById('manual-code').value.trim();
  if (!code) return;
  closeBarcodeCamera();
  if (window._barcodeCallback) { window._barcodeCallback(code); window._barcodeCallback = null; }
}
// Override para múltiplos campos
const _origOpen = window.openBarcodeCamera;
window.openBarcodeCamera = function(cb) {
  window._barcodeCallback = cb;
  _origOpen(cb);
};
</script>
</body>
</html>
