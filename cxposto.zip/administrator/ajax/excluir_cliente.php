<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$id    = (int)($input['id'] ?? 0);
$db    = getDB();

if (!$id) { echo json_encode(['ok'=>false,'msg'=>'ID inválido.']); exit; }

try {
    // Verifica de forma robusta se o operador tem qualquer histórico de transações
    $colunaOperador2Existe = $db->query("SHOW COLUMNS FROM `caixas` LIKE 'operador2_id'")->fetch();
    
    $params = [];
    $sql_parts = [];

    $sql_parts[] = "EXISTS(SELECT 1 FROM vendas WHERE operador_id = ?)";
    $params[] = $id;

    if ($colunaOperador2Existe) {
        $sql_parts[] = "EXISTS(SELECT 1 FROM caixas WHERE operador_id = ? OR operador2_id = ?)";
        $params[] = $id;
        $params[] = $id;
    } else {
        $sql_parts[] = "EXISTS(SELECT 1 FROM caixas WHERE operador_id = ?)";
        $params[] = $id;
    }

    $sql_parts[] = "EXISTS(SELECT 1 FROM vales WHERE operador_id = ?)";
    $params[] = $id;

    $sql = "SELECT " . implode(" OR ", $sql_parts) . " AS has_refs";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $has_refs = $stmt->fetchColumn();

    if ($has_refs) {
        // Apenas desativa
        $db->prepare("UPDATE usuarios SET ativo=0 WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true, 'msg'=>'Operador desativado pois possui histórico de transações.']);
    } else {
        // Se não houver histórico, pode excluir com segurança
        $db->prepare("DELETE FROM usuarios WHERE id=? AND tipo='operador'")->execute([$id]);
        echo json_encode(['ok'=>true]);
    }
} catch (PDOException $e) {
    echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);
}
