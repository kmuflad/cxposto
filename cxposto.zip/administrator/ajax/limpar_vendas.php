<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok'=>false, 'msg'=>'Método inválido.']);
    exit;
}

try {
    $db = getDB();
    
    // Desativa a checagem de chave estrangeira temporariamente para permitir o TRUNCATE
    $db->exec("SET FOREIGN_KEY_CHECKS = 0");
    
    // Zera todas as tabelas transacionais
    $db->exec("TRUNCATE TABLE itens_venda");
    $db->exec("TRUNCATE TABLE vendas");
    $db->exec("TRUNCATE TABLE lancamentos_avulsos");
    $db->exec("TRUNCATE TABLE caixa_combustiveis");
    $db->exec("TRUNCATE TABLE caixas");
    
    // Reativa a checagem
    $db->exec("SET FOREIGN_KEY_CHECKS = 1");
    
    echo json_encode(['ok'=>true]);
} catch (PDOException $e) {
    // Em caso de erro, tenta garantir que as chaves sejam religadas
    try { $db->exec("SET FOREIGN_KEY_CHECKS = 1"); } catch(Exception $ex) {}
    echo json_encode(['ok'=>false, 'msg'=>'Erro ao limpar: ' . $e->getMessage()]);
}
