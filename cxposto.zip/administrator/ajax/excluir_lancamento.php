<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');

header('Content-Type: application/json');
$db = getDB();

try {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    $id = (int)($data['id'] ?? 0);

    if (!$id) {
        throw new Exception('ID inválido.');
    }

    $db->prepare("DELETE FROM lancamentos_avulsos WHERE id = ?")->execute([$id]);

    echo json_encode(['ok' => true]);

} catch (Exception $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}
