<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check(); // Permite admin e operador, com verificação interna

header('Content-Type: application/json');
$input = json_decode(file_get_contents('php://input'), true);
$acao = $input['acao'] ?? '';
$db = getDB();
$response = ['ok' => false, 'msg' => 'Ação inválida.'];

try {
    switch ($acao) {
        case 'salvar_cliente':
            if ($_SESSION['tipo'] !== 'admin') {
                $response['msg'] = 'Acesso negado.';
                break;
            }
            $id = (int)($input['id'] ?? 0);
            $nome = trim($input['nome'] ?? '');
            $empresa = ($input['empresa'] ?? null) ? trim($input['empresa']) : null;
            $carro = ($input['carro'] ?? null) ? trim($input['carro']) : null;
            $placa = ($input['placa'] ?? null) ? trim($input['placa']) : null;

            if (empty($nome)) {
                $response['msg'] = 'O nome do cliente é obrigatório.';
                break;
            }

            if ($id > 0) { // Update
                $stmt = $db->prepare("UPDATE clientes_abastecimento SET nome=?, empresa=?, carro=?, placa=? WHERE id=?");
                $stmt->execute([$nome, $empresa, $carro, $placa, $id]);
            } else { // Insert
                $stmt = $db->prepare("INSERT INTO clientes_abastecimento (nome, empresa, carro, placa) VALUES (?, ?, ?, ?)");
                $stmt->execute([$nome, $empresa, $carro, $placa]);
            }
            $response = ['ok' => true];
            break;

        case 'toggle_cliente':
            if ($_SESSION['tipo'] !== 'admin') {
                $response['msg'] = 'Acesso negado.';
                break;
            }
            $id = (int)($input['id'] ?? 0);
            $ativo = (int)($input['ativo'] ?? 0);
            if (!$id) {
                $response['msg'] = 'ID do cliente não informado.';
                break;
            }
            $stmt = $db->prepare("UPDATE clientes_abastecimento SET ativo = ? WHERE id = ?");
            $stmt->execute([$ativo, $id]);
            $response = ['ok' => true];
            break;

        case 'obter_vale':
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                $response['msg'] = 'ID do vale não informado.';
                break;
            }
            $stmt = $db->prepare("SELECT * FROM vales WHERE id = ?");
            $stmt->execute([$id]);
            $vale = $stmt->fetch();
            if ($vale) {
                $response = ['ok' => true, 'vale' => $vale];
            } else {
                $response['msg'] = 'Vale não encontrado.';
            }
            break;

        case 'criar_vale':
        case 'editar_vale':
            if ($acao === 'editar_vale' && $_SESSION['tipo'] !== 'admin') {
                $response['msg'] = 'Acesso negado para editar vales.';
                break;
            }

            $id = (int)($input['id'] ?? 0);
            $caixa_id = (int)($input['caixa_id'] ?? 0);
            $combustivel_id = (int)($input['combustivel_id'] ?? 0);
            $quantidade = (float)($input['quantidade'] ?? 0);
            $valor_total = (float)($input['valor_total'] ?? 0);
            $nome_cliente = trim($input['nome_cliente'] ?? '');

            if ($id === 0 && !$caixa_id) {
                $response['msg'] = 'Não há um caixa aberto para criar um novo vale.';
                break;
            }
            if (!$combustivel_id || !$nome_cliente || ($quantidade <= 0 && $valor_total <= 0)) {
                $response['msg'] = 'Dados incompletos para gerar o vale (Combustível, Cliente, Valor/Litros).';
                break;
            }

            $stmt = $db->prepare("SELECT nome, preco FROM combustiveis WHERE id = ?");
            $stmt->execute([$combustivel_id]);
            $combustivel = $stmt->fetch();
            if (!$combustivel) {
                $response['msg'] = 'Combustível inválido.';
                break;
            }

            $params = [
                'cliente_id' => ($input['cliente_id'] ?? 0) ?: null,
                'nome_cliente' => $nome_cliente,
                'empresa' => ($input['empresa'] ?? '') ?: null,
                'carro' => ($input['carro'] ?? '') ?: null,
                'placa' => ($input['placa'] ?? '') ?: null,
                'km' => ($input['km'] ?? null) ?: null,
                'combustivel_id' => $combustivel_id,
                'nome_combustivel' => $combustivel['nome'],
                'preco_combustivel' => $combustivel['preco'],
                'tipo_quantidade' => $input['tipo_quantidade'] ?? 'litros',
                'quantidade' => $quantidade,
                'valor_total' => $valor_total,
                'descricao' => ($input['descricao'] ?? '') ?: null,
            ];

            if ($id > 0) {
                $params['id'] = $id;
                $sql = "UPDATE vales SET cliente_id=:cliente_id, nome_cliente=:nome_cliente, empresa=:empresa, carro=:carro, placa=:placa, km=:km, combustivel_id=:combustivel_id, nome_combustivel=:nome_combustivel, preco_combustivel=:preco_combustivel, tipo_quantidade=:tipo_quantidade, quantidade=:quantidade, valor_total=:valor_total, descricao=:descricao WHERE id=:id AND status='ativo'";
                $stmt = $db->prepare($sql);
                $stmt->execute($params);
                $response = ['ok' => true];
            } else {
                $params['caixa_id'] = $caixa_id;
                $params['operador_id'] = $_SESSION['usuario_id'];
                $sql = "INSERT INTO vales (caixa_id, operador_id, cliente_id, nome_cliente, empresa, carro, placa, km, combustivel_id, nome_combustivel, preco_combustivel, tipo_quantidade, quantidade, valor_total, descricao) VALUES (:caixa_id, :operador_id, :cliente_id, :nome_cliente, :empresa, :carro, :placa, :km, :combustivel_id, :nome_combustivel, :preco_combustivel, :tipo_quantidade, :quantidade, :valor_total, :descricao)";
                $stmt = $db->prepare($sql);
                $stmt->execute($params);
                $valeId = $db->lastInsertId();
                $response = ['ok' => true, 'vale_id' => $valeId];

                // Enviar notificação para o Telegram
                require_once __DIR__ . '/../../config/telegram_helper.php';
                $configPath = __DIR__ . '/../../config/settings.json';
                $config = file_exists($configPath) ? json_decode(file_get_contents($configPath), true) : [];
                
                $topicId = $config['telegram_topic_vales'] ?? null;
                $botToken = $config['telegram_bot_token'] ?? null;
                $chatId = $config['telegram_chat_id'] ?? null;

                if ($topicId && $botToken && $chatId) {
                    $operadorNome = $_SESSION['usuario_nome'];
                    $message = "<b>🎟️ Novo Vale de Convênio</b>\n\n";
                    $message .= "<b>Valor: R$ " . number_format($params['valor_total'], 2, ',', '.') . "</b>\n";
                    $message .= "<b>Litros:</b> " . number_format($params['quantidade'], 2, ',', '.') . " L\n";
                    $message .= "<b>Combustível:</b> " . htmlspecialchars($params['nome_combustivel']) . "\n";
                    $message .= "<pre>------------------------------</pre>\n";
                    $message .= "<b>Cliente:</b> " . htmlspecialchars($params['nome_cliente']) . "\n";
                    if (!empty($params['empresa'])) {
                        $message .= "<b>Empresa:</b> " . htmlspecialchars($params['empresa']) . "\n";
                    }
                    if (!empty($params['placa'])) {
                        $message .= "<b>Placa:</b> " . htmlspecialchars($params['placa']) . "\n";
                    }
                    if (!empty($params['carro'])) {
                        $message .= "<b>Carro:</b> " . htmlspecialchars($params['carro']) . "\n";
                    }
                    if (!empty($params['km'])) {
                        $message .= "<b>KM:</b> " . htmlspecialchars($params['km']) . "\n";
                    }
                    $message .= "<b>Operador:</b> " . htmlspecialchars($operadorNome) . "\n";
                    $message .= "<b>Data:</b> " . date('d/m/Y H:i:s') . "\n";
                    $message .= "<b>ID do Vale:</b> <code>#" . $valeId . "</code>";
                    sendTelegramMessage($message, $topicId, $botToken, $chatId);
                }
            }
            break;

        case 'revogar_vale':
            if ($_SESSION['tipo'] !== 'admin') {
                $response['msg'] = 'Acesso negado.';
                break;
            }
            $id = (int)($input['id'] ?? 0);
            if (!$id) {
                $response['msg'] = 'ID do vale não informado.';
                break;
            }
            $stmt = $db->prepare("UPDATE vales SET status='revogado', revogado_em=NOW(), revogado_por=? WHERE id=? AND status='ativo'");
            $stmt->execute([$_SESSION['usuario_id'], $id]);
            $response = ['ok' => true];
            break;
    }
} catch (PDOException $e) {
    $response['msg'] = 'Erro de banco de dados: ' . $e->getMessage();
}

echo json_encode($response);