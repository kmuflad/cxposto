<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$acao  = $input['acao'] ?? '';
$db    = getDB();

try {
    if ($acao === 'criar') {
        $nome   = trim($input['nome'] ?? '');
        $login  = trim($input['login'] ?? '');
        $senha  = trim($input['senha'] ?? '');
        $tipo   = $input['tipo'] ?? 'operador';
        $escala = trim($input['data_base_escala'] ?? '');

        if (!$nome || !$login || !$senha) { echo json_encode(['ok'=>false,'msg'=>'Preencha todos os campos.']); exit; }
        if (strlen($senha) < 6)           { echo json_encode(['ok'=>false,'msg'=>'Senha mínima de 6 caracteres.']); exit; }

        $hash = password_hash($senha, PASSWORD_BCRYPT);
        $db->prepare("INSERT INTO usuarios (nome, login, senha, tipo, data_base_escala) VALUES (?,?,?,?,?)")
           ->execute([$nome, $login, $hash, $tipo, $escala]);
        echo json_encode(['ok'=>true]);

    } elseif ($acao === 'editar') {
        $id     = (int)($input['id'] ?? 0);
        $nome   = trim($input['nome'] ?? '');
        $login  = trim($input['login'] ?? '');
        $senha  = trim($input['senha'] ?? '');
        $tipo   = $input['tipo'] ?? 'operador';
        $escala = trim($input['data_base_escala'] ?? '');

        if (!$id || !$nome || !$login) { echo json_encode(['ok'=>false,'msg'=>'Dados inválidos.']); exit; }

        if ($senha) {
            if (strlen($senha) < 6) { echo json_encode(['ok'=>false,'msg'=>'Senha mínima de 6 caracteres.']); exit; }
            $hash = password_hash($senha, PASSWORD_BCRYPT);
            $db->prepare("UPDATE usuarios SET nome=?, login=?, senha=?, tipo=?, data_base_escala=? WHERE id=?")->execute([$nome, $login, $hash, $tipo, $escala, $id]);
        } else {
            $db->prepare("UPDATE usuarios SET nome=?, login=?, tipo=?, data_base_escala=? WHERE id=?")->execute([$nome, $login, $tipo, $escala, $id]);
        }
        echo json_encode(['ok'=>true]);

    } elseif ($acao === 'toggle') {
        $id    = (int)($input['id'] ?? 0);
        $ativo = (int)($input['ativo'] ?? 0);
        $db->prepare("UPDATE usuarios SET ativo=? WHERE id=?")->execute([$ativo, $id]);
        echo json_encode(['ok'=>true]);

    } else {
        echo json_encode(['ok'=>false,'msg'=>'Ação inválida.']);
    }
} catch (PDOException $e) {
    $msg = str_contains($e->getMessage(), 'Duplicate') ? 'Login já existe. Escolha outro.' : $e->getMessage();
    echo json_encode(['ok'=>false,'msg'=>$msg]);
}
