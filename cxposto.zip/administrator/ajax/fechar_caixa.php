<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check(); // Permite admin e operador
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$acao  = $input['acao'] ?? '';
$db    = getDB();

try {
    if ($acao === 'abrir') {
        // Admin define quem será o operador do dia
        $operadorId    = (int)($input['operador_id'] ?? 0);
        $operador2Id   = ($input['operador2_id'] ?? 0) ?: null;
        $valorAbertura = (float)($input['valor_abertura'] ?? 0);

        if (!$operadorId) { echo json_encode(['ok'=>false,'msg'=>'Selecione um operador para este turno.']); exit; }

        if ($operadorId && $operador2Id && $operadorId === $operador2Id) {
            echo json_encode(['ok'=>false,'msg'=>'Os operadores devem ser diferentes.']); exit;
        }

        // Garantia: Fecha qualquer outro caixa que possa ter ficado aberto por erro
        $db->exec("UPDATE caixas SET status='fechado', fechamento=NOW() WHERE status='aberto'");

        $db->beginTransaction();

        $colunaOperador2Existe = $db->query("SHOW COLUMNS FROM `caixas` LIKE 'operador2_id'")->fetch();

        if ($colunaOperador2Existe && $operador2Id) {
            $stmt = $db->prepare("INSERT INTO caixas (operador_id, operador2_id, valor_abertura, status) VALUES (?, ?, ?, 'aberto')");
            $stmt->execute([$operadorId, $operador2Id, $valorAbertura]);
        } else {
            $stmt = $db->prepare("INSERT INTO caixas (operador_id, valor_abertura, status) VALUES (?, ?, 'aberto')");
            $stmt->execute([$operadorId, $valorAbertura]);
        }

        $caixaId = $db->lastInsertId();

        // Salvar litragens e alturas iniciais de combustíveis
        foreach ($input as $key => $val) {
            if (strpos($key, 'litragem_') === 0) {
                $cbId = (int)str_replace('litragem_', '', $key);
                $litragem = (float)$val;
                $altura = (float)($input['altura_' . $cbId] ?? 0);
                
                // Busca nome e preço atual do combustível para congelar no caixa
                $cb = $db->prepare("SELECT nome, preco FROM combustiveis WHERE id=?");
                $cb->execute([$cbId]);
                $cb = $cb->fetch();

                if ($cb) {
                    $db->prepare("INSERT IGNORE INTO caixa_combustiveis (caixa_id, combustivel_id, nome, preco, litragem_inicial, altura_inicial) VALUES (?,?,?,?,?,?)")
                       ->execute([$caixaId, $cbId, $cb['nome'], $cb['preco'], $litragem, $altura]);
                }
            }
        }
        $db->commit();
        echo json_encode(['ok'=>true, 'id'=>$caixaId]);

    } elseif ($acao === 'fechar') {
        $id = (int)($input['id'] ?? 0);
        $dinheiroFinal = (float)($input['dinheiro_final'] ?? 0);
        if (!$id) { echo json_encode(['ok'=>false,'msg'=>'ID inválido.']); exit; }

        $db->beginTransaction();
        $db->prepare("UPDATE caixas SET status='fechado', fechamento=NOW(), valor_dinheiro_final=? WHERE id=? AND status='aberto'")
           ->execute([$dinheiroFinal, $id]);

        // Salvar litragens vendidas
        $litragens = $input['litragem'] ?? [];
        foreach ($litragens as $key => $val) {
            if (strpos($key, 'litros_vendidos_') === 0) {
                $rowId = (int)str_replace('litros_vendidos_', '', $key);
                $litrosVendidos = (float)$val;
                
                // Buscar litragem inicial para subtrair e registrar
                $stmt = $db->prepare("SELECT litragem_inicial FROM caixa_combustiveis WHERE id=? AND caixa_id=?");
                $stmt->execute([$rowId, $id]);
                $cb = $stmt->fetch();
                if ($cb) {
                    $litragemFinal = $cb['litragem_inicial'] - $litrosVendidos;
                    $db->prepare("UPDATE caixa_combustiveis SET litragem_final=? WHERE id=? AND caixa_id=?")
                       ->execute([$litragemFinal, $rowId, $id]);
                }
            }
        }
        $db->commit();
        echo json_encode(['ok'=>true]);

    } elseif ($acao === 'editar_estoque') {
        $idRegistro = (int)($input['id_registro'] ?? 0);
        $litragem = (float)($input['litragem_inicial'] ?? 0);
        $altura = (float)($input['altura_inicial'] ?? 0);

        if (!$idRegistro) { echo json_encode(['ok'=>false,'msg'=>'ID do registro inválido.']); exit; }

        $db->prepare("UPDATE caixa_combustiveis SET litragem_inicial=?, altura_inicial=? WHERE id=?")
           ->execute([$litragem, $altura, $idRegistro]);
        
        echo json_encode(['ok'=>true]);

    } else {
        echo json_encode(['ok'=>false,'msg'=>'Ação inválida.']);
    }
} catch (PDOException $e) {
    echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);
}
