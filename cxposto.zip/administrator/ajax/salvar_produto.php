<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$acao  = $input['acao'] ?? '';
$db    = getDB();

try {
    if ($acao === 'criar') {
        $nome    = trim($input['nome'] ?? '');
        $codBar  = trim($input['codigo_barras'] ?? '') ?: null;
        $valor   = (float)($input['valor'] ?? 0);
        $estoque = (int)($input['estoque'] ?? 0);

        if (!$nome || $valor <= 0) { echo json_encode(['ok'=>false,'msg'=>'Nome e valor são obrigatórios.']); exit; }

        $db->prepare("INSERT INTO produtos (nome, codigo_barras, valor, estoque) VALUES (?,?,?,?)")
           ->execute([$nome, $codBar, $valor, $estoque]);
        echo json_encode(['ok'=>true]);

    } elseif ($acao === 'editar') {
        $id      = (int)($input['id'] ?? 0);
        $nome    = trim($input['nome'] ?? '');
        $codBar  = trim($input['codigo_barras'] ?? '') ?: null;
        $valor   = (float)($input['valor'] ?? 0);
        $estoque = (int)($input['estoque'] ?? 0);

        if (!$id || !$nome || $valor <= 0) { echo json_encode(['ok'=>false,'msg'=>'Dados inválidos.']); exit; }

        $db->prepare("UPDATE produtos SET nome=?, codigo_barras=?, valor=?, estoque=? WHERE id=?")
           ->execute([$nome, $codBar, $valor, $estoque, $id]);
        echo json_encode(['ok'=>true]);

    } else {
        echo json_encode(['ok'=>false,'msg'=>'Ação inválida.']);
    }
} catch (PDOException $e) {
    $msg = str_contains($e->getMessage(), 'Duplicate') ? 'Código de barras já cadastrado.' : $e->getMessage();
    echo json_encode(['ok'=>false,'msg'=>$msg]);
}
