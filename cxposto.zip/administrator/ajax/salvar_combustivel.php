<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$acao  = $input['acao'] ?? '';
$db    = getDB();

try {
    if ($acao === 'criar') {
        $nome  = trim($input['nome'] ?? '');
        $preco = (float)($input['preco'] ?? 0);
        if (!$nome) { echo json_encode(['ok'=>false,'msg'=>'Nome obrigatório.']); exit; }
        $db->prepare("INSERT INTO combustiveis (nome, preco) VALUES (?,?)")->execute([$nome, $preco]);
        echo json_encode(['ok'=>true]);

    } elseif ($acao === 'editar') {
        $id    = (int)($input['id'] ?? 0);
        $nome  = trim($input['nome'] ?? '');
        $preco = (float)($input['preco'] ?? 0);
        if (!$id || !$nome) { echo json_encode(['ok'=>false,'msg'=>'Dados inválidos.']); exit; }
        $db->prepare("UPDATE combustiveis SET nome=?, preco=? WHERE id=?")->execute([$nome, $preco, $id]);
        echo json_encode(['ok'=>true]);

    } elseif ($acao === 'excluir') {
        $id = (int)($input['id'] ?? 0);
        $db->prepare("DELETE FROM combustiveis WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true]);

    } else {
        echo json_encode(['ok'=>false,'msg'=>'Ação inválida.']);
    }
} catch (PDOException $e) {
    echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);
}
