<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');

header('Content-Type: application/json');

try {
    $db = getDB();
    
    // Stats do dashboard
    $totalVendas = $db->query("SELECT COUNT(*) FROM vendas WHERE status='finalizada' AND DATE(criado_em)=CURDATE()")->fetchColumn();
    $totalHoje   = $db->query("SELECT COALESCE(SUM(valor_total),0) FROM vendas WHERE status='finalizada' AND DATE(criado_em)=CURDATE()")->fetchColumn();
    $totalProd   = $db->query("SELECT COUNT(*) FROM produtos WHERE ativo=1")->fetchColumn();
    $totalOper   = $db->query("SELECT COUNT(*) FROM usuarios WHERE tipo='operador' AND ativo=1")->fetchColumn();
    $caixa       = $db->query("SELECT * FROM caixas WHERE status='aberto' LIMIT 1")->fetch();

    echo json_encode([
        'ok' => true,
        'totalVendas' => (int)$totalVendas,
        'totalHoje' => (float)$totalHoje,
        'totalProd' => (int)$totalProd,
        'totalOper' => (int)$totalOper,
        'caixaAberto' => !!$caixa,
        'caixaNome' => $caixa ? '🟢 Caixa Aberto' : '🔴 Caixa Fechado'
    ]);
} catch (Exception $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}
