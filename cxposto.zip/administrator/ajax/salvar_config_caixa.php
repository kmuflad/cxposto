<?php
require_once __DIR__ . '/../../config/auth_check.php';
auth_check('admin');
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok'=>false, 'msg'=>'Método inválido.']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$fechamento = $input['fechamento'] ?? '';

$configPath = __DIR__ . '/../../config/settings.json';
$config = [];
if (file_exists($configPath)) {
    $config = json_decode(file_get_contents($configPath), true) ?: [];
}

$config['caixa_auto_fechamento'] = $fechamento;
$config['vendas_pagamento_detalhado'] = (bool)($input['vendas_pagamento_detalhado'] ?? false);

if (file_put_contents($configPath, json_encode($config, JSON_PRETTY_PRINT))) {
    echo json_encode(['ok'=>true]);
} else {
    echo json_encode(['ok'=>false, 'msg'=>'Erro ao salvar arquivo de configurações. Verifique permissões.']);
}
