<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');
header('Content-Type: application/json');

$id = (int)($_GET['id'] ?? 0);
if (!$id) { echo json_encode(['itens'=>[]]); exit; }

$db = getDB();

$venda = $db->prepare("
    SELECT 
        (SELECT COALESCE(SUM(iv.valor_total), v.valor_total) FROM itens_venda iv WHERE iv.venda_id = v.id) as valor_total, 
        v.criado_em, 
        u.nome as operador 
    FROM vendas v 
    JOIN usuarios u ON u.id=v.operador_id 
    WHERE v.id=?
");
$venda->execute([$id]);
$venda = $venda->fetch();

$itens = $db->prepare("SELECT nome_produto, quantidade, valor_unitario, valor_total FROM itens_venda WHERE venda_id=?");
$itens->execute([$id]);
$itens = $itens->fetchAll();

echo json_encode([
    'itens'    => $itens,
    'total'    => $venda['valor_total'] ?? 0,
    'operador' => $venda['operador'] ?? '',
    'data'     => $venda ? date('d/m/Y H:i:s', strtotime($venda['criado_em'])) : '',
]);
