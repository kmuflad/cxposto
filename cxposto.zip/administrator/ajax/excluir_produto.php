<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$id    = (int)($input['id'] ?? 0);
$db    = getDB();

if (!$id) { echo json_encode(['ok'=>false,'msg'=>'ID inválido.']); exit; }

try {
    // Verifica se produto foi vendido
    $vendido = $db->prepare("SELECT COUNT(*) FROM itens_venda WHERE produto_id=?");
    $vendido->execute([$id]);
    if ($vendido->fetchColumn() > 0) {
        $db->prepare("UPDATE produtos SET ativo=0 WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true, 'msg'=>'Produto desativado (possui histórico de vendas).']);
    } else {
        $db->prepare("DELETE FROM produtos WHERE id=?")->execute([$id]);
        echo json_encode(['ok'=>true]);
    }
} catch (PDOException $e) {
    echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);
}
