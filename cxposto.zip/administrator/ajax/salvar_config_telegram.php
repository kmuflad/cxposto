<?php
require_once __DIR__ . '/../../config/auth_check.php';
auth_check('admin');
header('Content-Type: application/json');

$input = json_decode(file_get_contents('php://input'), true);
$configPath = __DIR__ . '/../../config/settings.json';

try {
    // Carrega configurações existentes
    $config = file_exists($configPath) ? json_decode(file_get_contents($configPath), true) : [];

    // Atualiza com os novos dados do Telegram
    $config['telegram_bot_token'] = trim($input['telegram_bot_token'] ?? '');
    $config['telegram_chat_id'] = trim($input['telegram_chat_id'] ?? '');
    $config['telegram_topic_vendas'] = ($input['telegram_topic_vendas'] ?? '') ?: null;
    $config['telegram_topic_vales'] = ($input['telegram_topic_vales'] ?? '') ?: null;

    // Salva o arquivo de configuração
    if (file_put_contents($configPath, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES))) {
        echo json_encode(['ok' => true]);
    } else {
        echo json_encode(['ok' => false, 'msg' => 'Não foi possível salvar o arquivo de configurações. Verifique as permissões.']);
    }
} catch (Exception $e) {
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}