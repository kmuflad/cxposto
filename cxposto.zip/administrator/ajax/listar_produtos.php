<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');

$db = getDB();
$q = isset($_GET['q']) ? trim($_GET['q']) : '';

if ($q !== '') {
    $stmt = $db->prepare("SELECT * FROM produtos WHERE nome LIKE :q OR codigo_barras LIKE :q ORDER BY nome ASC LIMIT 100");
    $stmt->bindValue(':q', "%$q%", PDO::PARAM_STR);
    $stmt->execute();
} else {
    $stmt = $db->query("SELECT * FROM produtos ORDER BY nome ASC LIMIT 100");
}

$produtos = $stmt->fetchAll();

header('Content-Type: application/json');
echo json_encode($produtos);
