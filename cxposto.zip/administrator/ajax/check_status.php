<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
header('Content-Type: application/json');

$db = getDB();
$caixa = $db->query("SELECT id, status FROM caixas WHERE status='aberto' ORDER BY id DESC LIMIT 1")->fetch();

// Carrega configurações de horário
$configPath = __DIR__ . '/../../config/settings.json';
$config = file_exists($configPath) ? json_decode(file_get_contents($configPath), true) : [];

$deveFechar = false;
if ($caixa && isset($config['caixa_auto_fechamento'])) {
    $agora = date('H:i');
    $horaFechamento = $config['caixa_auto_fechamento'];
    
    // Se passou do horário de fechamento e ainda está aberto
    if ($agora >= $horaFechamento) {
        $deveFechar = true;
    }
}

echo json_encode([
    'caixa_id' => $caixa['id'] ?? null,
    'status' => $caixa['status'] ?? 'fechado',
    'deve_fechar' => $deveFechar
]);
