<?php
require_once __DIR__ . '/../../config/auth_check.php';
require_once __DIR__ . '/../../config/db.php';
auth_check('admin');

header('Content-Type: application/json');
$db = getDB();

try {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    $vendaId = (int)($data['id'] ?? 0);

    if (!$vendaId) {
        throw new Exception('ID da venda inválido.');
    }

    $db->beginTransaction();

    // 1. Pegar dados da venda
    $venda = $db->prepare("SELECT * FROM vendas WHERE id = ?");
    $venda->execute([$vendaId]);
    $venda = $venda->fetch();

    if (!$venda) {
        throw new Exception('Venda não encontrada.');
    }

    $caixaId = $venda['caixa_id'];
    $valorTotal = $venda['valor_total'];

    // 2. Devolver estoque dos produtos
    $itens = $db->prepare("SELECT * FROM itens_venda WHERE venda_id = ?");
    $itens->execute([$vendaId]);
    $itensVenda = $itens->fetchAll();

    foreach ($itensVenda as $item) {
        $db->prepare("UPDATE produtos SET estoque = estoque + ? WHERE nome = ?")
           ->execute([$item['quantidade'], $item['nome_produto']]);
    }

    // 3. Subtrair valor do caixa
    $db->prepare("UPDATE caixas SET valor_total = valor_total - ? WHERE id = ?")
       ->execute([$valorTotal, $caixaId]);

    // 4. Deletar itens e venda
    $db->prepare("DELETE FROM itens_venda WHERE venda_id = ?")->execute([$vendaId]);
    $db->prepare("DELETE FROM vendas WHERE id = ?")->execute([$vendaId]);

    $db->commit();
    echo json_encode(['ok' => true]);

} catch (Exception $e) {
    if ($db->inTransaction()) $db->rollBack();
    echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
}
