<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('admin');

$db = getDB();

// Fetch all active vouchers with a company name
$vales = $db->query("
    SELECT * 
    FROM vales 
    WHERE empresa IS NOT NULL AND empresa != '' AND status = 'ativo'
    ORDER BY empresa, criado_em ASC
")->fetchAll();

// Group by company
$valesPorEmpresa = [];
$totalGeral = 0;
foreach ($vales as $vale) {
    $empresa = strtoupper(trim($vale['empresa']));
    if (!isset($valesPorEmpresa[$empresa])) {
        $valesPorEmpresa[$empresa] = [];
    }
    $valesPorEmpresa[$empresa][] = $vale;
    $totalGeral += (float)$vale['valor_total'];
}
ksort($valesPorEmpresa); // Sort companies alphabetically
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Relatório de Vales por Empresa</title>
    <link rel="stylesheet" href="/assets/css/style.css?v=<?= time() ?>">
    <style>
        body { background: var(--bg-deep); font-family: 'Inter', sans-serif; }
        .container { max-width: 800px; margin: 2rem auto; padding: 2rem; background: var(--bg-card); border-radius: 12px; }
        h1 { text-align: center; color: var(--accent); border-bottom: 1px solid var(--border); padding-bottom: 1rem; margin-bottom: 2rem; }
        .empresa-bloco { margin-bottom: 2.5rem; }
        .empresa-titulo { font-size: 1.5rem; font-weight: 700; color: var(--text-primary); border-left: 4px solid var(--accent); padding-left: 1rem; margin-bottom: 1rem; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: .75rem; text-align: left; border-bottom: 1px solid var(--border); }
        th { font-size: .8rem; color: var(--text-muted); text-transform: uppercase; }
        .total-geral { margin-top: 2rem; padding-top: 1.5rem; border-top: 2px solid var(--accent); text-align: right; }
        .total-geral span { font-size: 1.8rem; font-weight: 800; color: var(--accent); }
        .no-print { text-align: center; margin-bottom: 2rem; }
        @media print {
            body { background: #fff; color: #000; }
            .container { box-shadow: none; margin: 0; max-width: 100%; padding: 0; border-radius: 0; }
            .no-print { display: none; }
            th, td { border-color: #ccc; }
            h1, .empresa-titulo, .total-geral span { color: #000 !important; }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="no-print">
            <button class="btn btn-primary" onclick="window.print()">🖨️ Imprimir Relatório</button>
        </div>
        <h1>Relatório de Vales por Empresa</h1>

        <?php if (empty($valesPorEmpresa)): ?>
            <div class="empty-state"><p>Nenhum vale ativo encontrado para empresas.</p></div>
        <?php else: ?>
            <?php foreach ($valesPorEmpresa as $empresa => $vales): ?>
                <div class="empresa-bloco">
                    <h2 class="empresa-titulo"><?= htmlspecialchars($empresa) ?></h2>
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th><th>Cliente</th><th>Data</th><th>Combustível</th><th>Litros</th><th>Valor</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $totalEmpresa = 0; ?>
                            <?php foreach ($vales as $v): ?>
                                <tr>
                                    <td>#<?= $v['id'] ?></td>
                                    <td>
                                        <?= htmlspecialchars($v['nome_cliente']) ?>
                                        <?php if($v['placa']): ?><div class="text-xs text-muted"><?= htmlspecialchars($v['placa']) ?></div><?php endif; ?>
                                    </td>
                                    <td class="text-sm"><?= date('d/m/Y H:i', strtotime($v['criado_em'])) ?></td>
                                    <td><?= htmlspecialchars($v['nome_combustivel']) ?></td>
                                    <td><?= number_format($v['quantidade'], 2, ',', '.') ?> L</td>
                                    <td class="fw-bold">R$ <?= number_format($v['valor_total'], 2, ',', '.') ?></td>
                                </tr>
                                <?php $totalEmpresa += (float)$v['valor_total']; ?>
                            <?php endforeach; ?>
                            <tr style="background: var(--bg-input);"><td colspan="5" style="text-align:right; font-weight: bold;">Total <?= htmlspecialchars($empresa) ?>:</td><td class="fw-bold">R$ <?= number_format($totalEmpresa, 2, ',', '.') ?></td></tr>
                        </tbody>
                    </table>
                </div>
            <?php endforeach; ?>
            <div class="total-geral"><span>Total Geral: R$ <?= number_format($totalGeral, 2, ',', '.') ?></span></div>
        <?php endif; ?>
    </div>
</body>
</html>