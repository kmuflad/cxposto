<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('admin');

// Carrega configurações existentes
$configPath = __DIR__ . '/../config/settings.json';
$config = file_exists($configPath) ? json_decode(file_get_contents($configPath), true) : [];

$page_id = 'telegram';
$page_title = 'Configurações do Telegram — Convênio Posto';
include __DIR__ . '/../includes/navbar_admin.php';
?>

<div class="page-body">
    <div class="card fade-in" style="max-width: 700px; margin: 0 auto;">
        <div class="card-header">
            <span class="card-title">✈️ Configurações de Notificação do Telegram</span>
        </div>
        <form id="form-telegram" onsubmit="salvarConfigTelegram(event)">
            <p style="font-size:.85rem;color:var(--text-muted);margin-bottom:1.5rem;line-height:1.4;">
                Configure o bot do Telegram para receber notificações em tempo real sobre as operações do sistema. Você precisará de um Token de Bot, o ID do seu chat (grupo) e os IDs dos tópicos (se o grupo usar tópicos).
            </p>

            <div class="form-group">
                <label class="form-label">Token do Bot</label>
                <input type="text" name="telegram_bot_token" class="form-control" placeholder="Ex: 123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11" value="<?= htmlspecialchars($config['telegram_bot_token'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label class="form-label">Chat ID</label>
                <input type="text" name="telegram_chat_id" class="form-control" placeholder="Ex: -1001234567890 (ID do grupo/canal)" value="<?= htmlspecialchars($config['telegram_chat_id'] ?? '') ?>">
            </div>

            <hr style="border-color: var(--border); margin: 1.5rem 0;">
            <div class="form-label" style="margin-bottom:1rem; color:var(--accent);">IDs dos Tópicos (Opcional)</div>

            <div class="form-row">
                <div class="form-group">
                    <label class="form-label">Tópico de Vendas</label>
                    <input type="number" name="telegram_topic_vendas" class="form-control" placeholder="ID numérico do tópico" value="<?= htmlspecialchars($config['telegram_topic_vendas'] ?? '') ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Tópico de Vales</label>
                    <input type="number" name="telegram_topic_vales" class="form-control" placeholder="ID numérico do tópico" value="<?= htmlspecialchars($config['telegram_topic_vales'] ?? '') ?>">
                </div>
            </div>

            <div class="modal-footer" style="padding: 1.5rem 0 0;">
                <button type="submit" class="btn btn-primary" id="btnSalvarTelegram">💾 Salvar Configurações</button>
            </div>
        </form>
    </div>
</div>
</div>
</div>

<script src="/assets/js/main.js?v=<?= time() ?>"></script>
<script>
async function salvarConfigTelegram(e) {
    e.preventDefault();
    const btn = document.getElementById('btnSalvarTelegram');
    btn.disabled = true;
    btn.textContent = 'Salvando...';
    try {
        const data = serializeForm(e.target);
        const resp = await postJSON('/administrator/ajax/salvar_config_telegram.php', data);
        if (resp.ok) {
            showToast('Configurações do Telegram salvas!', 'success');
        } else {
            showToast(resp.msg || 'Erro ao salvar.', 'error');
        }
    } catch (err) {
        showToast('Erro de comunicação.', 'error');
    }
    btn.disabled = false;
    btn.textContent = '💾 Salvar Configurações';
}
</script>
</body>
</html>