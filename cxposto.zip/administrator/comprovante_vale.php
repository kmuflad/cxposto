<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check(); // Permite admin e operador

$valeId = (int) ($_GET['id'] ?? 0);
if (!$valeId) {
  echo "ID do vale não informado.";
  exit;
}

$db = getDB();
$vale = $db->prepare("SELECT v.*, u.nome as operador_nome FROM vales v JOIN usuarios u ON u.id = v.operador_id WHERE v.id = ?");
$vale->execute([$valeId]);
$vale = $vale->fetch();

if (!$vale) {
  echo "Vale não encontrado.";
  exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Comprovante de Vale #<?= $valeId ?></title>
    <link rel="stylesheet" href="/assets/css/style.css?v=<?= time() ?>">
    <style>
        body { background: var(--bg-deep); margin: 0; padding: 0; -webkit-print-color-adjust: exact; }
        .comp-wrapper { min-height: 100vh; display: flex; flex-direction: column; align-items: center; padding: 2rem 1rem; }
        .no-print { display: flex; gap: .75rem; margin-bottom: 2rem; }
        .recibo { background: #fff; color: #000 !important; max-width: 320px; width: 100%; box-sizing: border-box; padding: 20px; font-family: 'Courier New', Courier, monospace; font-size: 13px; font-weight: 700 !important; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4); }
        .recibo-center { text-align: center; text-transform: uppercase; }
        .recibo h2 { font-size: 18px; margin: 0 0 5px; font-weight: 900 !important; }
        .recibo p { margin: 2px 0; font-size: 11px; }
        .divisor { border-top: 1px dashed #000; margin: 10px 0; }
        .secao-titulo { font-weight: 900 !important; text-transform: uppercase; margin-bottom: 8px; font-size: 14px; border-bottom: 1px solid #000; display: inline-block; }
        .item-row { display: flex; justify-content: space-between; margin-bottom: 4px; line-height: 1.2; }
        .item-nome { flex: 1; padding-right: 10px; }
        .item-valor { text-align: right; white-space: nowrap; }
        .total-destaque { font-size: 16px; font-weight: 900 !important; margin-top: 10px; display: flex; justify-content: space-between; }
        .btn { padding: 10px 20px; border-radius: 8px; font-weight: bold; text-decoration: none; cursor: pointer; border: none; font-family: 'Inter', sans-serif; }
        .btn-primary { background: var(--accent); color: white; }
        .btn-ghost { background: rgba(255, 255, 255, 0.1); color: white; }
        @page { margin: 0; size: 80mm auto; }
        @media print {
            body { background: #fff !important; }
            .comp-wrapper { padding: 0; }
            .recibo { box-shadow: none; max-width: none; width: 100%; padding: 5mm; }
            .no-print { display: none !important; }
        }
    </style>
</head>
<body>
    <div class="comp-wrapper">
        <div class="no-print">
            <button onclick="window.print()" class="btn btn-primary">🖨️ Imprimir</button>
            <button onclick="window.close()" class="btn btn-ghost">✕ Fechar</button>
        </div>
        <div class="recibo">
            <div class="recibo-center">
                <h2>CONVÊNIO POSTO</h2>
                <p>COMPROVANTE DE VALE</p>
                <p><?= date('d/m/Y - H:i', strtotime($vale['criado_em'])) ?></p>
            </div>
            <div class="divisor"></div>
            <div class="item-row">
                <span>VALE ID:</span>
                <span>#<?= $vale['id'] ?></span>
            </div>
            <div class="item-row">
                <span>OPERADOR:</span>
                <span><?= htmlspecialchars($vale['operador_nome']) ?></span>
            </div>
            <div class="divisor"></div>
            <div class="secao-titulo">Dados do Cliente</div>
            <div class="item-row"><span class="item-nome">NOME:</span><span class="item-valor"><?= htmlspecialchars($vale['nome_cliente']) ?></span></div>
            <?php if ($vale['empresa']): ?><div class="item-row"><span class="item-nome">EMPRESA:</span><span class="item-valor"><?= htmlspecialchars($vale['empresa']) ?></span></div><?php endif; ?>
            <?php if ($vale['carro']): ?><div class="item-row"><span class="item-nome">CARRO:</span><span class="item-valor"><?= htmlspecialchars($vale['carro']) ?></span></div><?php endif; ?>
            <?php if ($vale['placa']): ?><div class="item-row"><span class="item-nome">PLACA:</span><span class="item-valor"><?= htmlspecialchars($vale['placa']) ?></span></div><?php endif; ?>
            <?php if ($vale['km']): ?><div class="item-row"><span class="item-nome">KM:</span><span class="item-valor"><?= htmlspecialchars($vale['km']) ?></span></div><?php endif; ?>
            <div class="divisor"></div>
            <div class="secao-titulo">Abastecimento</div>
            <div class="item-row"><span class="item-nome">COMBUSTÍVEL:</span><span class="item-valor"><?= htmlspecialchars($vale['nome_combustivel']) ?></span></div>
            <div class="item-row"><span class="item-nome">PREÇO/L:</span><span class="item-valor">R$ <?= number_format($vale['preco_combustivel'], 3, ',', '.') ?></span></div>
            <div class="item-row"><span class="item-nome">LITROS:</span><span class="item-valor"><?= number_format($vale['quantidade'], 2, ',', '.') ?> L</span></div>
            <div class="total-destaque">
                <span>TOTAL:</span>
                <span>R$ <?= number_format($vale['valor_total'], 2, ',', '.') ?></span>
            </div>
            <?php if ($vale['descricao']): ?>
            <div class="divisor"></div>
            <p style="font-size:11px;"><strong>OBS:</strong> <?= htmlspecialchars($vale['descricao']) ?></p>
            <?php endif; ?>
            <div class="divisor"></div>
            <div style="margin-top: 20px; text-align: center;">
                <p>___________________________________</p>
                <p style="font-size:10px;">ASSINATURA DO CLIENTE</p>
            </div>
            <div class="recibo-center" style="margin-top: 20px; font-size: 10px;">
                <p>Sistema Convênio Posto</p>
            </div>
        </div>
    </div>
</body>
</html>