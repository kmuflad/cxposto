<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('admin');

// Stats do dashboard
$db = getDB();
$totalVendas = $db->query("SELECT COUNT(*) FROM vendas WHERE status='finalizada' AND DATE(criado_em)=CURDATE()")->fetchColumn();
$totalHoje   = $db->query("SELECT COALESCE(SUM(valor_total),0) FROM vendas WHERE status='finalizada' AND DATE(criado_em)=CURDATE()")->fetchColumn();
$totalProd   = $db->query("SELECT COUNT(*) FROM produtos WHERE ativo=1")->fetchColumn();
$totalOper   = $db->query("SELECT COUNT(*) FROM usuarios WHERE tipo='operador' AND ativo=1")->fetchColumn();
$caixa       = $db->query("SELECT * FROM caixas WHERE status='aberto' LIMIT 1")->fetch();

$page_id = 'dashboard';
$page_title = 'Dashboard Admin — Convênio Posto';
include __DIR__ . '/../includes/navbar_admin.php'; 
?>

    <div class="page-body">
      <div class="stat-grid fade-in">
        <div class="stat-card accent">
          <span class="stat-icon">💰</span>
          <div class="stat-value" id="stat-total-hoje">R$ <?= number_format($totalHoje, 2, ',', '.') ?></div>
          <div class="stat-label">Vendas Hoje</div>
        </div>
        <div class="stat-card success">
          <span class="stat-icon">🧾</span>
          <div class="stat-value" id="stat-transacoes-hoje"><?= $totalVendas ?></div>
          <div class="stat-label">Transações Hoje</div>
        </div>
        <div class="stat-card info">
          <span class="stat-icon">📦</span>
          <div class="stat-value" id="stat-produtos-ativos"><?= $totalProd ?></div>
          <div class="stat-label">Produtos Ativos</div>
        </div>
        <div class="stat-card">
          <span class="stat-icon">👥</span>
          <div class="stat-value" id="stat-operadores-ativos"><?= $totalOper ?></div>
          <div class="stat-label">Operadores Ativos</div>
        </div>
      </div>

      <!-- Últimas vendas -->
      <?php
      $ultimas = $db->query("
          SELECT v.id, v.valor_total, v.status, v.criado_em, u.nome as operador
          FROM vendas v
          JOIN usuarios u ON u.id = v.operador_id
          ORDER BY v.criado_em DESC
          LIMIT 10
      ")->fetchAll();
      ?>
      <div class="card fade-in">
        <div class="card-header">
          <span class="card-title">🧾 Últimas Vendas</span>
          <a href="/administrator/vendas.php" class="btn btn-ghost btn-sm">Ver Tudo →</a>
        </div>
        <?php if ($ultimas): ?>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>#</th>
                <th>Operador</th>
                <th>Valor</th>
                <th>Status</th>
                <th>Data/Hora</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($ultimas as $v): ?>
              <tr>
                <td><strong>#<?= $v['id'] ?></strong></td>
                <td><?= htmlspecialchars($v['operador']) ?></td>
                <td class="text-accent fw-bold">R$ <?= number_format($v['valor_total'],2,',','.') ?></td>
                <td>
                  <?php if ($v['status']==='finalizada'): ?>
                    <span class="badge badge-success">Finalizada</span>
                  <?php else: ?>
                    <span class="badge badge-danger">Cancelada</span>
                  <?php endif; ?>
                </td>
                <td class="text-muted text-sm"><?= date('d/m/Y H:i', strtotime($v['criado_em'])) ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
          <div class="empty-state"><span class="empty-icon">🧾</span><p>Nenhuma venda registrada ainda.</p></div>
        <?php endif; ?>
      </div>

    </div>
  </div>
</div>
<script src="/assets/js/main.js?v=<?= time() ?>"></script>
</body>
</html>
