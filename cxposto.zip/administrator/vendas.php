<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check('admin');

$db = getDB();

// Filtros
$operadorId = (int)($_GET['operador'] ?? 0);
$dataFiltro = $_GET['data'] ?? '';
$status     = $_GET['status'] ?? '';

$params = [];
$where  = ['1=1'];
if ($operadorId) { $where[] = 'v.operador_id = ?'; $params[] = $operadorId; }
if ($dataFiltro) { $where[] = 'DATE(v.criado_em) = ?'; $params[] = $dataFiltro; }
if ($status)     { $where[] = 'v.status = ?'; $params[] = $status; }

$whereSql = implode(' AND ', $where);
$stmt = $db->prepare("
    SELECT v.id, 
           (SELECT COALESCE(SUM(iv.valor_total), v.valor_total) FROM itens_venda iv WHERE iv.venda_id = v.id) as valor_total, 
           v.status, v.criado_em, u.nome as operador
    FROM vendas v
    JOIN usuarios u ON u.id = v.operador_id
    WHERE $whereSql
    ORDER BY v.criado_em DESC
    LIMIT 200
");
$stmt->execute($params);
$vendas = $stmt->fetchAll();

$operadores = $db->query("SELECT id, nome FROM usuarios WHERE tipo='operador' ORDER BY nome")->fetchAll();


$page_id = 'vendas';
$page_title = 'Histórico de Vendas — Convênio Posto';
include __DIR__ . '/../includes/navbar_admin.php'; 
?>

    <div class="page-body">
      <!-- Filtros -->
      <div class="card fade-in" style="margin-bottom:1rem;">
        <form method="GET" style="display:flex;gap:.75rem;flex-wrap:wrap;align-items:flex-end;">
          <div class="form-group" style="margin:0;flex:1;min-width:140px;">
            <label class="form-label">Operador</label>
            <select name="operador" class="form-control">
              <option value="">Todos</option>
              <?php foreach ($operadores as $op): ?>
                <option value="<?= $op['id'] ?>" <?= $operadorId == $op['id'] ? 'selected' : '' ?>><?= htmlspecialchars($op['nome']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group" style="margin:0;flex:1;min-width:140px;">
            <label class="form-label">Data</label>
            <input type="date" name="data" class="form-control" value="<?= htmlspecialchars($dataFiltro) ?>">
          </div>
          <div class="form-group" style="margin:0;flex:1;min-width:120px;">
            <label class="form-label">Status</label>
            <select name="status" class="form-control">
              <option value="">Todos</option>
              <option value="finalizada" <?= $status==='finalizada'?'selected':'' ?>>Finalizada</option>
              <option value="cancelada"  <?= $status==='cancelada'?'selected':'' ?>>Cancelada</option>
            </select>
          </div>
          <div style="display:flex;gap:.5rem;padding-bottom:.05rem;">
            <button type="submit" class="btn btn-primary">Filtrar</button>
            <a href="/administrator/vendas.php" class="btn btn-ghost">Limpar</a>
            <button type="button" class="btn btn-danger" style="margin-left:auto;" onclick="openModal('modal-limpar')">🗑️ Resetar Sistema de Vendas</button>
          </div>
        </form>
      </div>

      <!-- Resumo -->
      <?php
      $totalFin = array_sum(array_column(array_filter($vendas, fn($v) => $v['status']==='finalizada'), 'valor_total'));
      ?>
      <div class="stat-grid fade-in" style="margin-bottom:1rem;">
        <div class="stat-card accent">
          <span class="stat-icon">💰</span>
          <div class="stat-value">R$ <?= number_format($totalFin,2,',','.') ?></div>
          <div class="stat-label">Total (Filtro)</div>
        </div>
        <div class="stat-card success">
          <span class="stat-icon">🧾</span>
          <div class="stat-value"><?= count(array_filter($vendas, fn($v) => $v['status']==='finalizada')) ?></div>
          <div class="stat-label">Vendas Finalizadas</div>
        </div>
        <div class="stat-card danger">
          <span class="stat-icon">❌</span>
          <div class="stat-value"><?= count(array_filter($vendas, fn($v) => $v['status']==='cancelada')) ?></div>
          <div class="stat-label">Canceladas</div>
        </div>
      </div>

      <div class="card fade-in">
        <div class="card-header">
          <span class="card-title">🧾 Vendas</span>
          <span class="badge badge-info"><?= count($vendas) ?> registros</span>
        </div>
        <?php if ($vendas): ?>
        <div class="table-wrap">
          <table>
            <thead>
              <tr><th>#</th><th>Operador</th><th>Data/Hora</th><th>Valor</th><th>Status</th><th>Detalhes</th></tr>
            </thead>
            <tbody>
              <?php foreach ($vendas as $v): ?>
              <tr>
                <td><strong>#<?= $v['id'] ?></strong></td>
                <td><?= htmlspecialchars($v['operador']) ?></td>
                <td class="text-muted text-sm"><?= date('d/m/Y H:i:s', strtotime($v['criado_em'])) ?></td>
                <td class="<?= $v['status']==='finalizada' ? 'text-accent' : 'text-muted' ?> fw-bold">
                  R$ <?= number_format($v['valor_total'],2,',','.') ?>
                </td>
                <td>
                  <?php if ($v['status']==='finalizada'): ?>
                    <span class="badge badge-success">Finalizada</span>
                  <?php else: ?>
                    <span class="badge badge-danger">Cancelada</span>
                  <?php endif; ?>
                </td>
                <td>
                  <button class="btn btn-ghost btn-sm" onclick="verDetalhes(<?= $v['id'] ?>)">🔍 Ver</button>
                </td>
              </tr>
              <!-- Linha de detalhes (expandível) -->
              <tr id="det-<?= $v['id'] ?>" style="display:none;">
                <td colspan="6" style="padding:0;">
                  <div id="det-content-<?= $v['id'] ?>" style="padding:1rem 1.5rem;background:var(--bg-input);border-bottom:1px solid var(--border);">
                    <span class="text-muted">Carregando...</span>
                  </div>
                </td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php else: ?>
          <div class="empty-state"><span class="empty-icon">🧾</span><p>Nenhuma venda encontrada com os filtros selecionados.</p></div>
        <?php endif; ?>
      </div>
    </div>
  </div>
</div>

<!-- MODAL DETALHE -->
<div class="modal-overlay" id="modal-detalhe">
  <div class="modal" style="max-width:560px;">
    <div class="modal-header">
      <span class="modal-title" id="modal-det-title">Detalhes da Venda</span>
      <button class="modal-close" onclick="closeModal('modal-detalhe')">×</button>
    </div>
    <div class="modal-body" id="modal-det-body">Carregando...</div>
  </div>
</div>

<!-- MODAL LIMPAR VENDAS -->
<div class="modal-overlay" id="modal-limpar">
  <div class="modal" style="max-width:460px;">
    <div class="modal-header">
      <span class="modal-title" style="color:var(--danger);">⚠️ Zona de Perigo</span>
      <button class="modal-close" onclick="closeModal('modal-limpar')">×</button>
    </div>
    <div class="modal-body" style="text-align:center;">
      <span style="font-size:3.5rem;display:block;margin-bottom:1rem;">🧨</span>
      <p style="color:var(--text-secondary);margin-bottom:.75rem;font-size:1.1rem;font-weight:700;">Você está prestes a apagar todas as vendas.</p>
      <p style="font-size:.9rem;color:var(--text-muted);margin-bottom:1rem;line-height:1.5;">
        Isso irá <strong>deletar permanentemente</strong> todo o histórico de vendas, fechamento de caixas e comprovantes do sistema.<br><br>
        <span style="color:var(--success);">Operadores e Produtos serão mantidos.</span>
      </p>
    </div>
    <div class="modal-footer">
      <button class="btn btn-ghost" onclick="closeModal('modal-limpar')">Cancelar</button>
      <button class="btn btn-danger" id="btnConfirmarLimpeza" onclick="confirmarLimpeza()">🧨 Sim, Apagar Tudo</button>
    </div>
  </div>
</div>

<script src="/assets/js/main.js?v=<?= time() ?>"></script>
<script>
async function verDetalhes(id) {
  document.getElementById('modal-det-title').textContent = `Venda #${id} — Detalhes`;
  document.getElementById('modal-det-body').innerHTML = '<div class="empty-state"><span class="empty-icon">⏳</span><p>Carregando...</p></div>';
  openModal('modal-detalhe');

  try {
    const resp = await fetch(`/administrator/ajax/detalhe_venda.php?id=${id}`);
    const data = await resp.json();

    if (!data.itens || !data.itens.length) {
      document.getElementById('modal-det-body').innerHTML = '<p class="text-muted">Sem itens registrados.</p>';
      return;
    }

    let html = `
      <div style="margin-bottom:.75rem;display:flex;gap:1rem;flex-wrap:wrap;">
        <span class="badge badge-neutral">🕐 ${data.data}</span>
        <span class="badge badge-neutral">👤 ${data.operador}</span>
      </div>
      <table style="width:100%">
        <thead>
          <tr>
            <th style="text-align:left;font-size:.72rem;color:var(--text-muted);padding:.5rem 0;text-transform:uppercase;">Produto</th>
            <th style="text-align:center;font-size:.72rem;color:var(--text-muted);padding:.5rem 0;text-transform:uppercase;">Qtd</th>
            <th style="text-align:right;font-size:.72rem;color:var(--text-muted);padding:.5rem 0;text-transform:uppercase;">Unitário</th>
            <th style="text-align:right;font-size:.72rem;color:var(--text-muted);padding:.5rem 0;text-transform:uppercase;">Subtotal</th>
          </tr>
        </thead>
        <tbody>
    `;
    data.itens.forEach(i => {
      html += `<tr>
        <td style="padding:.5rem 0;font-weight:600;">${i.nome_produto}</td>
        <td style="text-align:center;color:var(--text-muted);">x${i.quantidade}</td>
        <td style="text-align:right;color:var(--text-muted);">R$ ${parseFloat(i.valor_unitario).toFixed(2).replace('.',',')}</td>
        <td style="text-align:right;color:var(--accent);font-weight:700;">R$ ${parseFloat(i.valor_total).toFixed(2).replace('.',',')}</td>
      </tr>`;
    });
    html += `</tbody></table>
      <div style="border-top:1px solid var(--border);margin-top:.75rem;padding-top:.75rem;display:flex;justify-content:space-between;align-items:center;">
        <span style="font-weight:700;font-size:1rem;">TOTAL</span>
        <span style="font-size:1.5rem;font-weight:800;color:var(--accent);">R$ ${parseFloat(data.total).toFixed(2).replace('.',',')}</span>
      </div>
    `;
    document.getElementById('modal-det-body').innerHTML = html;
  } catch(e) {
    document.getElementById('modal-det-body').innerHTML = '<p class="text-danger">Erro ao carregar detalhes.</p>';
  }
}
// ── LIMPEZA DE VENDAS ────────────────────────────
async function confirmarLimpeza() {
  const btn = document.getElementById('btnConfirmarLimpeza');
  btn.disabled = true; btn.textContent = 'Apagando...';
  
  try {
    const resp = await postJSON('/administrator/ajax/limpar_vendas.php', {});
    if (resp.ok) {
      showToast('Sistema resetado com sucesso!', 'success');
      setTimeout(() => location.href = '/administrator/vendas.php', 1000);
    } else {
      showToast(resp.msg || 'Erro ao limpar.', 'error');
      btn.disabled = false; btn.textContent = '🧨 Sim, Apagar Tudo';
    }
  } catch(e) {
    showToast('Erro de comunicação.', 'error');
    btn.disabled = false; btn.textContent = '🧨 Sim, Apagar Tudo';
  }
}
</script>
</body>
</html>
