<?php
require_once __DIR__ . '/../config/auth_check.php';
require_once __DIR__ . '/../config/db.php';
auth_check();

$caixaId = (int) ($_GET['id'] ?? 0);
if (!$caixaId) {
  echo "ID do caixa não informado.";
  exit;
}

$db = getDB();

// DADOS DO CAIXA
$caixa = $db->prepare("SELECT c.*, u.nome as operador FROM caixas c JOIN usuarios u ON u.id=c.operador_id WHERE c.id=?");
$caixa->execute([$caixaId]);
$caixa = $caixa->fetch();
$mode = $_GET['mode'] ?? 'completo'; // 'completo' ou 'resumido'
if (!$caixa) {
  echo "Caixa não encontrado.";
  exit;
}

// VENDAS (Produtos)
$stmtVendas = $db->prepare("SELECT * FROM vendas WHERE caixa_id = ? AND status='finalizada' ORDER BY criado_em DESC");
$stmtVendas->execute([$caixaId]);
$vendas = $stmtVendas->fetchAll();
$totalVendas = count($vendas);
$totalValor = $db->query("
    SELECT COALESCE(SUM(iv.valor_total), 0) 
    FROM itens_venda iv 
    JOIN vendas v ON v.id = iv.venda_id 
    WHERE v.caixa_id = $caixaId AND v.status='finalizada'
")->fetchColumn();

// ITENS VENDIDOS (Agrupados)
$itens = $db->prepare("
    SELECT iv.nome_produto, SUM(iv.quantidade) as total_qtd, SUM(iv.valor_total) as total_valor
    FROM itens_venda iv
    JOIN vendas v ON v.id = iv.venda_id
    WHERE v.caixa_id = ? AND v.status='finalizada'
    GROUP BY iv.nome_produto
    ORDER BY total_valor DESC
");
$itens->execute([$caixaId]);
$itens = $itens->fetchAll();

// PIX, CIELO e VALE (Consolidado de Conveniência: Vendas + Avulsos legítimos, excluindo combustível extra)
$pixTotal = $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$caixaId AND tipo='pix' AND COALESCE(descricao, '') != 'Venda de Combustível') + (SELECT COALESCE(SUM(valor_pix),0) FROM vendas WHERE caixa_id=$caixaId AND status='finalizada')")->fetchColumn();
$cieloTotal = $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$caixaId AND tipo='cielo' AND COALESCE(descricao, '') != 'Venda de Combustível') + (SELECT COALESCE(SUM(valor_cielo),0) FROM vendas WHERE caixa_id=$caixaId AND status='finalizada')")->fetchColumn();
$valeTotal = $db->query("SELECT (SELECT COALESCE(SUM(valor),0) FROM lancamentos_avulsos WHERE caixa_id=$caixaId AND tipo='vale' AND COALESCE(descricao, '') != 'Venda de Combustível') + (SELECT COALESCE(SUM(valor_vale),0) FROM vendas WHERE caixa_id=$caixaId AND status='finalizada')")->fetchColumn();

// COMBUSTÍVEIS (Litragem - Lógica de Estoque: Inicial - Final)
$stmtComb = $db->prepare("SELECT *, (litragem_inicial - COALESCE(litragem_final, litragem_inicial)) as vendidos FROM caixa_combustiveis WHERE caixa_id = ?");
$stmtComb->execute([$caixaId]);
$combustiveis = $stmtComb->fetchAll();

$totalCombustivel = 0;
foreach ($combustiveis as $cb) {
  $totalCombustivel += (float) $cb['vendidos'] * (float) $cb['preco'];
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Comprovante Caixa #<?= $caixaId ?> — Convênio Posto</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/style.css">
  <style>
    body {
      background: var(--bg-deep);
      margin: 0;
      padding: 0;
      -webkit-print-color-adjust: exact;
    }

    .comp-wrapper {
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      align-items: center;
      padding: 2rem 1rem;
    }

    .no-print {
      display: flex;
      gap: .75rem;
      margin-bottom: 2rem;
    }

    /* RECIBO ESTILO TÉRMICO PREMIUM */
    .recibo {
      background: #fff;
      color: #000 !important;
      max-width: 320px; width: 100%; box-sizing: border-box;
      padding: 20px;
      font-family: 'Courier New', Courier, monospace;
      font-size: 13px;
      font-weight: 700 !important;
      box-shadow: 0 10px 40px rgba(0, 0, 0, 0.4);
      position: relative;
    }

    .recibo-center {
      text-align: center;
      text-transform: uppercase;
    }

    .recibo h2 {
      font-size: 18px;
      margin: 0 0 5px;
      font-weight: 900 !important;
    }

    .recibo p {
      margin: 2px 0;
      font-size: 11px;
    }

    .divisor {
      border-top: 1px dashed #000;
      margin: 10px 0;
    }

    .secao-titulo {
      font-weight: 900 !important;
      text-transform: uppercase;
      margin-bottom: 8px;
      font-size: 14px;
      border-bottom: 1px solid #000;
      display: inline-block;
    }

    .item-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 4px;
      line-height: 1.2;
    }

    .item-nome {
      flex: 1;
      padding-right: 10px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }

    .item-valor {
      text-align: right;
      white-space: nowrap;
    }

    .total-destaque {
      font-size: 16px;
      font-weight: 900 !important;
      margin-top: 10px;
      display: flex;
      justify-content: space-between;
    }

    .conferencia-box {
      margin-top: 15px;
      padding: 10px;
      border: 1px solid #000;
    }

    .status-caixa {
      text-align: center;
      margin-top: 10px;
      font-size: 11px;
      text-transform: uppercase;
    }

    .btn {
      padding: 10px 20px;
      border-radius: 8px;
      font-weight: bold;
      text-decoration: none;
      cursor: pointer;
      border: none;
      font-family: 'Inter', sans-serif;
    }

    .btn-primary {
      background: var(--accent);
      color: white;
    }

    .btn-warning {
      background: #f59e0b;
      color: white;
    }

    .btn-success {
      background: #10b981;
      color: white;
    }

    .btn-ghost {
      background: rgba(255, 255, 255, 0.1);
      color: white;
    }

    @page {
      margin: 0;
      size: 80mm auto;
    }

    @media print {
      body {
        background: #fff !important;
      }

      .comp-wrapper {
        padding: 0;
      }

      .recibo {
        box-shadow: none;
        max-width: none; width: 100%;
        padding: 5mm;
        position: static;
      }

      .no-print {
        display: none !important;
      }
    }
  </style>
</head>

<body>
  <div class="comp-wrapper">
    <div class="no-print" style="flex-wrap:wrap; justify-content:center; gap: .5rem;">
      <button onclick="window.print()" class="btn btn-primary">🖨️ Imprimir</button>
      <?php if ($mode === 'completo'): ?>
        <a href="?id=<?= $caixaId ?>&mode=resumido" class="btn btn-warning">📄 Ver Resumido</a>
      <?php else: ?>
        <a href="?id=<?= $caixaId ?>&mode=completo" class="btn btn-success">📄 Ver Completo</a>
      <?php endif; ?>
      <button onclick="window.close()" class="btn btn-ghost">✕ Fechar Janela</button>
    </div>

    <div class="recibo">
      <div class="recibo-center">
        <h2>CONVÊNIO POSTO</h2>
        <p>CONFERÊNCIA DE TURNO</p>
        <p><?= date('d/m/Y - H:i', strtotime($caixa['abertura'])) ?></p>
      </div>

      <div class="divisor"></div>

      <div class="item-row">
        <span>OPERADOR:</span>
        <span><?= htmlspecialchars($caixa['operador']) ?></span>
      </div>
      <div class="item-row">
        <span>TURNO ID:</span>
        <span>#<?= $caixaId ?></span>
      </div>
      <div class="item-row">
        <span>ABERTURA:</span>
        <span>R$ <?= number_format($caixa['valor_abertura'], 2, ',', '.') ?></span>
      </div>

      <div class="divisor"></div>

      <?php if ($mode === 'completo'): ?>
        <div class="secao-titulo">Produtos Vendidos</div>
        <?php foreach ($itens as $it): ?>
          <div class="item-row">
            <span class="item-nome"><?= htmlspecialchars($it['nome_produto']) ?> (<?= $it['total_qtd'] ?>x)</span>
            <span class="item-valor">R$ <?= number_format($it['total_valor'], 2, ',', '.') ?></span>
          </div>
        <?php endforeach; ?>
      <?php else: ?>
        <div class="secao-titulo">Resumo Conveniência</div>
        <div class="item-row">
          <span>Vendas de Balcão (<?= $totalVendas ?>):</span>
          <span>R$ <?= number_format($totalValor, 2, ',', '.') ?></span>
        </div>
      <?php endif; ?>

      <div class="divisor"></div>

      <?php if ($combustiveis): ?>
        <div class="secao-titulo">Vendas de Combustível</div>
        <?php foreach ($combustiveis as $cb): ?>
          <div style="margin-bottom: 8px;">
            <div style="font-weight: 900;"><?= htmlspecialchars($cb['nome']) ?></div>
            <div class="item-row">
              <span>E. INICIAL:</span>
              <span><?= number_format($cb['litragem_inicial'], 1, ',', '.') ?></span>
            </div>
            <div class="item-row">
              <span>E. FINAL:</span>
              <span><?= number_format($cb['litragem_final'], 1, ',', '.') ?></span>
            </div>
            <div class="item-row">
              <span>LITROS VENDIDOS:</span>
              <span><?= number_format($cb['vendidos'], 2, ',', '.') ?> L</span>
            </div>
            <div class="item-row">
              <span>PREÇO UNIT.:</span>
              <span>R$ <?= number_format($cb['preco'], 2, ',', '.') ?></span>
            </div>
            <div class="item-row" style="font-weight: 900;">
              <span>SUBTOTAL:</span>
              <span>R$ <?= number_format($cb['vendidos'] * $cb['preco'], 2, ',', '.') ?></span>
            </div>
          </div>
        <?php endforeach; ?>
        <div class="total-destaque" style="border-top: 1px solid #000; padding-top: 5px;">
          <span>TOTAL COMBUSTÍVEL:</span>
          <span>R$ <?= number_format($totalCombustivel, 2, ',', '.') ?></span>
        </div>
        <div class="divisor"></div>
      <?php endif; ?>

      <div class="secao-titulo">Resumo Financeiro</div>
      <div class="item-row">
        <span>PIX:</span>
        <span>R$ <?= number_format($pixTotal, 2, ',', '.') ?></span>
      </div>
      <div class="item-row">
        <span>CIELO:</span>
        <span>R$ <?= number_format($cieloTotal, 2, ',', '.') ?></span>
      </div>
      <div class="item-row">
        <span>VALES:</span>
        <span>R$ <?= number_format($valeTotal, 2, ',', '.') ?></span>
      </div>
      <div class="item-row">
        <span>DINHEIRO:</span>
        <span>R$ <?= number_format((float) $caixa['valor_dinheiro_final'], 2, ',', '.') ?></span>
      </div>


      <div class="total-destaque" style="border-top: 1px solid #000; padding-top: 5px; margin-top: 5px;">
        <span>TOTAL CAIXA:</span>
        <span>R$
          <?= number_format((float) ($pixTotal + $cieloTotal + $valeTotal + $caixa['valor_dinheiro_final']), 2, ',', '.') ?></span>
      </div>

      <div class="total-destaque" style="border-top: 1px solid #000; padding-top: 5px; margin-top: 5px;"></div>

      <div class="item-row" style="font-size: 11px; color: #333;">
        <span>CONVENIÊNCIA:</span>
        <span>R$ <?= number_format((float) $totalValor, 2, ',', '.') ?></span>
      </div>

      <div class="conferencia-box">
        <div class="recibo-center" style="font-size: 11px; margin-bottom: 8px;">CONFERÊNCIA DE CAIXA</div>

        <?php
        $valorX = (float) $totalCombustivel;
        $valorY = (float) $pixTotal + (float) $cieloTotal + (float) $valeTotal + (float) $caixa['valor_dinheiro_final'];
        $valorZ = $valorY - $valorX;
        $valorFinal = $valorZ - (float) $totalValor;
        ?>

        <div class="item-row">
          <span>COMBUSTÍVEL R$:</span>
          <span>R$ <?= number_format($valorX, 2, ',', '.') ?></span>
        </div>
        <div class="item-row">
          <span>PISTA R$:</span>
          <span>R$ <?= number_format($valorY, 2, ',', '.') ?></span>
        </div>
        <div class="divisor" style="margin: 5px 0;"></div>
        <div class="item-row" style="font-weight: 900;">
          <span>DIFERENÇA:</span>
          <span>R$ <?= number_format($valorZ, 2, ',', '.') ?></span>
        </div>
        <div class="item-row">
          <span>CONVENIÊNCIA:</span>
          <span>-R$ <?= number_format($totalValor, 2, ',', '.') ?></span>
        </div>
        <div class="divisor" style="margin: 5px 0;"></div>
        <div class="item-row" style="font-size: 16px; font-weight: 900;">
          <?php if (abs($valorFinal) < 0.01): ?>
            <span>SALDO FINAL:</span>
            <span>R$ 0,00</span>
          <?php elseif ($valorFinal > 0): ?>
            <span>PASSANDO:</span>
            <span>R$ <?= number_format($valorFinal, 2, ',', '.') ?></span>
          <?php else: ?>
            <span>FALTANDO:</span>
            <span>R$ <?= number_format(abs($valorFinal), 2, ',', '.') ?></span>
          <?php endif; ?>
        </div>
      </div>

      <div class="status-caixa">
        <?php if (abs($valorFinal) < 0.01): ?>
          *** FECHAMENTO ZERADO (100%) ***
        <?php elseif ($valorFinal > 0): ?>
          *** PASSANDO R$ <?= number_format(abs($valorFinal), 2, ',', '.') ?> ***
        <?php else: ?>
          *** FALTANDO R$ <?= number_format(abs($valorFinal), 2, ',', '.') ?> ***
        <?php endif; ?>
      </div>

      <div class="recibo-center" style="margin-top: 20px; font-size: 10px;">
        <p>Impresso em <?= date('d/m/Y H:i') ?></p>
        <p>Sistema Convênio Posto</p>
      </div>
    </div>
  </div>
</body>

</html>