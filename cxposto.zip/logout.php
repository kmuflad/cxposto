<?php
session_set_cookie_params(['lifetime'=>86400,'path'=>'/','httponly'=>true,'samesite'=>'Lax']);
session_start();
session_destroy();
header('Location: /login.php');
exit;
