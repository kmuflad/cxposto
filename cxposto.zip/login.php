<?php
// Sessão persistente 24h
session_set_cookie_params([
  'lifetime' => 86400,
  'path' => '/',
  'secure' => false,
  'httponly' => true,
  'samesite' => 'Lax',
]);
session_start();

// Se já logado, redireciona
if (!empty($_SESSION['usuario_id'])) {
  header('Location: ' . ($_SESSION['tipo'] === 'admin' ? '/administrator/' : '/usuario/'));
  exit;
}

require_once __DIR__ . '/config/db.php';

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $login = trim($_POST['login'] ?? '');
  $senha = trim($_POST['senha'] ?? '');

  if ($login && $senha) {
    try {
      $stmt = getDB()->prepare("SELECT * FROM usuarios WHERE login = ? AND ativo = 1 LIMIT 1");
      $stmt->execute([$login]);
      $user = $stmt->fetch();

      if ($user && password_verify($senha, $user['senha'])) {
        // Verificar escala se for operador
        if ($user['tipo'] === 'operador' && $user['data_base_escala']) {
          $hoje = new DateTime(date('Y-m-d'));
          $base = new DateTime($user['data_base_escala']);
          $diff = $hoje->diff($base)->days;
          if ($diff % 2 != 0) {
            $erro = 'Hoje é seu dia de folga. Acesso bloqueado.';
          }
        }

        if (!$erro) {
          $_SESSION['usuario_id'] = $user['id'];
          $_SESSION['usuario_nome'] = $user['nome'];
          $_SESSION['tipo'] = $user['tipo'];
          $_SESSION['login_time'] = time();

          header('Location: ' . ($user['tipo'] === 'admin' ? '/administrator/' : '/usuario/'));
          exit;
        }
      } else {
        $erro = 'Login ou senha incorretos.';
      }
    } catch (PDOException $e) {
      $erro = 'Erro de conexão com o banco de dados.';
    }
  } else {
    $erro = 'Preencha todos os campos.';
  }
}

$exp = $_GET['exp'] ?? '';
$acesso = $_GET['acesso'] ?? '';
$erroGet = $_GET['erro'] ?? '';
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="/assets/css/style.css">
  <style>
    html,
    body {
      height: 100%;
      overflow: hidden;
    }

    .login-wrapper {
      min-height: 100vh;
      min-height: 100dvh;
      display: flex;
      align-items: center;
      justify-content: center;
      background: #0f0f14;
      position: relative;
      overflow: hidden;
    }

    .login-wrapper .bg-map {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      border: 0;
      pointer-events: auto;
      /* Destravado para o dedo */
      z-index: 0;
    }

    .login-wrapper .bg-overlay {
      position: absolute;
      inset: 0;
      background: rgba(15, 15, 20, 0.65);
      z-index: 1;
      pointer-events: none;
    }

    .login-wrapper::before {
      content: '';
      position: absolute;
      width: 600px;
      height: 600px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(251, 146, 60, .15) 0%, transparent 70%);
      top: -200px;
      right: -200px;
      pointer-events: none;
      z-index: 2;
    }

    .login-wrapper::after {
      content: '';
      position: absolute;
      width: 400px;
      height: 400px;
      border-radius: 50%;
      background: radial-gradient(circle, rgba(251, 146, 60, .08) 0%, transparent 70%);
      bottom: -100px;
      left: -100px;
      pointer-events: none;
      z-index: 2;
    }

    .login-card {
      padding: 2.5rem;
      width: 100%;
      max-width: 420px;
      position: relative;
      z-index: 3;
      animation: fadeSlideUp .5s ease;
    }

    .login-logo {
      text-align: center;
      margin-bottom: 2rem;
    }

    .login-logo .icon {
      font-size: 3rem;
      display: block;
      margin-bottom: .5rem;
    }

    .login-logo h1 {
      font-size: 1.5rem;
      font-weight: 800;
      color: var(--text-primary);
      margin: 0;
    }

    .login-logo span {
      font-size: .85rem;
      color: var(--text-muted);
    }

    .form-group {
      margin-bottom: 1.25rem;
    }

    .form-group label {
      display: block;
      font-size: .8rem;
      font-weight: 600;
      color: var(--text-muted);
      text-transform: uppercase;
      letter-spacing: .05em;
      margin-bottom: .4rem;
    }

    .form-group input {
      width: 100%;
      background: var(--bg-input);
      border: 1.5px solid var(--border);
      border-radius: 10px;
      padding: .8rem 1rem;
      color: var(--text-primary);
      font-size: 1rem;
      font-family: 'Inter', sans-serif;
      transition: border-color .2s, box-shadow .2s;
      box-sizing: border-box;
    }

    .form-group input:focus {
      outline: none;
      border-color: var(--accent);
      box-shadow: 0 0 0 3px rgba(251, 146, 60, .2);
    }

    .btn-login {
      width: 100%;
      padding: .9rem;
      background: linear-gradient(135deg, var(--accent), #ea580c);
      color: #fff;
      border: none;
      border-radius: 10px;
      font-size: 1rem;
      font-weight: 700;
      font-family: 'Inter', sans-serif;
      cursor: pointer;
      transition: opacity .2s, transform .15s;
      margin-top: .5rem;
    }

    .btn-login:hover {
      opacity: .9;
      transform: translateY(-1px);
    }

    .btn-login:active {
      transform: translateY(0);
    }

    .alert-error {
      background: rgba(239, 68, 68, .15);
      border: 1px solid rgba(239, 68, 68, .3);
      color: #fca5a5;
      border-radius: 10px;
      padding: .75rem 1rem;
      font-size: .88rem;
      margin-bottom: 1.25rem;
      text-align: center;
    }

    .alert-warn {
      background: rgba(234, 179, 8, .12);
      border: 1px solid rgba(234, 179, 8, .3);
      color: #fde047;
      border-radius: 10px;
      padding: .75rem 1rem;
      font-size: .88rem;
      margin-bottom: 1.25rem;
      text-align: center;
    }

    @keyframes fadeSlideUp {
      from {
        opacity: 0;
        transform: translateY(24px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  </style>
</head>

<body>
  <div class="login-wrapper">
    <iframe class="bg-map"
      src="https://www.google.com/maps/embed?pb=!4v1778808828608!6m8!1m7!1s0B7NBN4qv0gXT6-t9Wcd5g!2m2!1d-7.090032814210348!2d-40.02383408456404!3f287.8481949751192!4f-1.340376078654458!5f2.0949737198906946"
      allowfullscreen loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    <div class="bg-overlay"></div>

    <div class="login-card">
      <div class="login-logo">
        <img src="/assets/images/logo.png" alt="Logo" style="width:42px; height:48px; object-fit:contain;">
        <h1>Operador</h1>
        <span style="color: white;">Sistema de Gestão</span>
      </div>

      <?php if ($exp): ?>
        <div class="alert-warn">⏰ Sua sessão expirou. Faça login novamente.</div>
      <?php elseif ($acesso): ?>
        <div class="alert-error">🔒 Acesso negado para esta área.</div>
      <?php elseif ($erroGet === 'desativado'): ?>
        <div class="alert-error">⛔ Sua conta foi desativada ou excluída.</div>
      <?php elseif ($erroGet === 'folga'): ?>
        <div class="alert-warn">🏖️ Hoje é seu dia de folga. Aproveite o descanso!</div>
      <?php endif; ?>

      <?php if ($erro): ?>
        <div class="alert-error">⚠️ <?= htmlspecialchars($erro) ?></div>
      <?php endif; ?>

      <form method="POST" id="loginForm" autocomplete="off">
        <div class="form-group">
          <label for="login" style="color: white;">Usuário</label>
          <input type="text" id="login" name="login" placeholder="Digite seu usuário" autofocus
            value="<?= htmlspecialchars($_POST['login'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label for="senha" style="color: white;">Senha</label>
          <input type="password" id="senha" name="senha" placeholder="••••••••">
        </div>
        <button type="submit" class="btn-login" id="btnLogin">Entrar</button>
      </form>
    </div>
  </div>
  <script>
    const form = document.getElementById('loginForm');
    const btn = document.getElementById('btnLogin');
    form.addEventListener('submit', () => {
      btn.textContent = 'Autenticando...';
      btn.style.opacity = '0.8';
      btn.style.pointerEvents = 'none';
    });
  </script>
</body>

</html>