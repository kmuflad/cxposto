/* ================================================
   main.js — Utilitários globais Convênio Posto
   ================================================ */

// ── SPINNER (Loading Overlay) ──────────────────
function showSpinner(msg = 'Processando...') {
  if (document.getElementById('global-spinner')) return;
  const overlay = document.createElement('div');
  overlay.id = 'global-spinner';
  overlay.innerHTML = `
    <div style="display:flex;flex-direction:column;align-items:center;gap:1.25rem;">
      <div class="spinner-ring"></div>
      <span style="font-size:1rem;font-weight:600;color:#fff;">${msg}</span>
    </div>`;
  Object.assign(overlay.style, {
    position:'fixed', inset:'0', zIndex:'99999',
    background:'rgba(0,0,0,0.7)', backdropFilter:'blur(4px)',
    display:'flex', alignItems:'center', justifyContent:'center',
    animation:'fadeIn .2s ease'
  });
  // Inject spinner CSS if not present
  if (!document.getElementById('spinner-style')) {
    const style = document.createElement('style');
    style.id = 'spinner-style';
    style.textContent = `
      @keyframes spinRing { to { transform: rotate(360deg); } }
      .spinner-ring {
        width:48px; height:48px; border:4px solid rgba(255,255,255,0.15);
        border-top-color: #fb923c; border-radius:50%;
        animation: spinRing .8s linear infinite;
      }`;
    document.head.appendChild(style);
  }
  document.body.appendChild(overlay);
}
function hideSpinner() {
  const el = document.getElementById('global-spinner');
  if (el) el.remove();
}

// ── TOAST ──────────────────────────────────────
function showToast(msg, type = 'info', duration = 3500) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }
  const icons = { success: '✅', error: '❌', info: 'ℹ️', warning: '⚠️' };
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.innerHTML = `<span>${icons[type] || 'ℹ️'}</span><span>${msg}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.animation = 'toastOut .3s ease forwards';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// ── MODAL ──────────────────────────────────────
function openModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.add('open');
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (el) el.classList.remove('open');
}
// Fecha modal ao clicar fora
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});
// Fecha com ESC
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
  }
});

// ── SIDEBAR MOBILE ─────────────────────────────
const hamburger    = document.querySelector('.hamburger');
const sidebar      = document.querySelector('.sidebar');
const overlayMob   = document.querySelector('.overlay-mob');

if (hamburger) {
  hamburger.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    overlayMob.classList.toggle('show');
  });
}
if (overlayMob) {
  overlayMob.addEventListener('click', () => {
    sidebar.classList.remove('open');
    overlayMob.classList.remove('show');
  });
}

// ── CLOCK ──────────────────────────────────────
function updateClock() {
  const el = document.getElementById('live-clock');
  if (!el) return;
  const now = new Date();
  el.textContent = now.toLocaleTimeString('pt-BR');
}
updateClock();
setInterval(updateClock, 1000);

// ── CURRENCY FORMAT ────────────────────────────
function formatBRL(value) {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value);
}

// ── MONEY MASK ─────────────────────────────────
function maskMoney(input) {
  if (!input) return;
  input.addEventListener('input', e => {
    let v = e.target.value.replace(/\D/g, '');
    v = (v / 100).toFixed(2) + '';
    v = v.replace(".", ",");
    v = v.replace(/(\d)(\d{3})(\d{3}),/g, "$1.$2.$3,");
    v = v.replace(/(\d)(\d{3}),/g, "$1.$2,");
    e.target.value = v;
  });
}

function parseBRL(value) {
  if (!value) return 0;
  if (typeof value === 'number') return value;
  return parseFloat(value.replace(/\./g, '').replace(',', '.'));
}

// ── CONFIRM DELETE ─────────────────────────────
function confirmDelete(msg, callback) {
  let overlay = document.getElementById('global-confirm');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'global-confirm';
    overlay.className = 'modal-overlay';
    overlay.innerHTML = `
      <div class="modal" style="max-width: 400px; text-align: center;">
        <div class="modal-body" style="padding: 2rem 1rem;">
          <div style="font-size: 3rem; margin-bottom: 1rem;">⚠️</div>
          <h3 style="margin-bottom: 1rem;">Confirmação</h3>
          <p id="global-confirm-msg" style="margin-bottom: 2rem; color: #9ca3af;"></p>
          <div style="display: flex; gap: 1rem; justify-content: center;">
            <button class="btn btn-ghost" id="global-confirm-cancel">Cancelar</button>
            <button class="btn btn-danger" id="global-confirm-ok">Confirmar</button>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);
  }

  document.getElementById('global-confirm-msg').textContent = msg;
  overlay.classList.add('open');

  const btnCancel = document.getElementById('global-confirm-cancel');
  const btnOk = document.getElementById('global-confirm-ok');

  const newCancel = btnCancel.cloneNode(true);
  const newOk = btnOk.cloneNode(true);
  btnCancel.replaceWith(newCancel);
  btnOk.replaceWith(newOk);

  newCancel.addEventListener('click', () => {
    overlay.classList.remove('open');
  });

  newOk.addEventListener('click', () => {
    overlay.classList.remove('open');
    if (typeof callback === 'function') callback();
  });
}
// ── AJAX POST helper ───────────────────────────
async function postJSON(url, data) {
  const resp = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  return resp.json();
}

// ── ATUALIZAÇÃO PARCIAL (SPA-LIKE) ───────────
async function refreshContent(selectors = []) {
  try {
    const resp = await fetch(window.location.href);
    const html = await resp.text();
    const parser = new DOMParser();
    const doc = parser.parseFromString(html, 'text/html');

    selectors.forEach(selector => {
      const newEl = doc.querySelector(selector);
      const oldEl = document.querySelector(selector);
      if (newEl && oldEl) {
        oldEl.innerHTML = newEl.innerHTML;
      }
    });
    return true;
  } catch (e) {
    console.error("Erro ao atualizar conteúdo:", e);
    return false;
  }
}

// ── FORM SERIALIZE ─────────────────────────────
function serializeForm(form) {
  const data = {};
  new FormData(form).forEach((v, k) => { data[k] = v; });
  return data;
}
// ── REALTIME POLLING ───────────────────────────
const POLLING_INTERVAL = 120000; // 2 minutos

async function pollAdminStats() {
    const totalHojeEl = document.getElementById('stat-total-hoje');
    const statusCaixaEl = document.getElementById('nav-caixa-status');
    if (!totalHojeEl && !statusCaixaEl) return;

    try {
        const resp = await fetch('/administrator/ajax/get_stats.php');
        const data = await resp.json();
        if (data.ok) {
            if (totalHojeEl) totalHojeEl.textContent = formatBRL(data.totalHoje);
            if (document.getElementById('stat-transacoes-hoje')) document.getElementById('stat-transacoes-hoje').textContent = data.totalVendas;
            if (document.getElementById('stat-produtos-ativos')) document.getElementById('stat-produtos-ativos').textContent = data.totalProd;
            if (document.getElementById('stat-operadores-ativos')) document.getElementById('stat-operadores-ativos').textContent = data.totalOper;
            
            if (statusCaixaEl) {
                statusCaixaEl.textContent = data.caixaNome;
                statusCaixaEl.className = 'caixa-status ' + (data.caixaAberto ? 'caixa-aberto' : 'caixa-fechado');
            }
        }
    } catch (e) { console.error('Poll Admin Error:', e); }
}

async function pollOperatorResumo() {
    const pixEl = document.getElementById('nav-resumo-pix');
    if (!pixEl) return;

    try {
        const resp = await fetch('/usuario/ajax/get_venda_resumo.php');
        const data = await resp.json();
        if (data.ok) {
            if (document.getElementById('nav-resumo-dinheiro')) document.getElementById('nav-resumo-dinheiro').textContent = formatBRL(data.dinheiro);
            if (document.getElementById('nav-resumo-pix')) document.getElementById('nav-resumo-pix').textContent = formatBRL(data.pix);
            if (document.getElementById('nav-resumo-cielo')) document.getElementById('nav-resumo-cielo').textContent = formatBRL(data.cielo);
            if (document.getElementById('nav-resumo-vale')) document.getElementById('nav-resumo-vale').textContent = formatBRL(data.vale);
        }
    } catch (e) { console.error('Poll Operator Error:', e); }
}

// Inicia polling apenas para o perfil correto
if (document.querySelector('.layout')) {
    const role = document.querySelector('.logo-sub')?.textContent.trim();
    if (role === 'Administrador') {
        setInterval(pollAdminStats, POLLING_INTERVAL);
        pollAdminStats(); // Roda uma vez de imediato
    } else if (role === 'Operador') {
        setInterval(pollOperatorResumo, POLLING_INTERVAL);
        pollOperatorResumo(); // Roda uma vez de imediato
    }
}

// ── THEME TOGGLE ───────────────────────────────
function initTheme() {
  const saved = localStorage.getItem('theme') || 'dark';
  document.documentElement.setAttribute('data-theme', saved);
  updateThemeIcon(saved);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'dark';
  const next = current === 'light' ? 'dark' : 'light';
  document.documentElement.setAttribute('data-theme', next);
  localStorage.setItem('theme', next);
  updateThemeIcon(next);
}

function updateThemeIcon(theme) {
  const icons = document.querySelectorAll('.theme-toggle-icon');
  icons.forEach(i => {
    i.textContent = theme === 'light' ? '🌙' : '☀️';
  });
}

initTheme();
document.addEventListener('DOMContentLoaded', initTheme);
