/* ================================================
   barcode.js — Leitor de código de barras via câmera
   Usa BarcodeDetector (Chrome/Edge) nativo.
   Verifica permissão antes de abrir câmera.
   ================================================ */

(function () {
  'use strict';

  let stream           = null;
  let scanning         = false;
  let onDetectCallback = null;

  const videoEl  = () => document.getElementById('barcode-video');
  const statusEl = () => document.getElementById('barcode-status');

  // ── VERIFICAR CONTEXTO E SUPORTE ─────────────
  function diagnosticarCamera() {
    // Contexto inseguro: HTTP em IP de rede (não é localhost)
    const isLocalhost = ['localhost', '127.0.0.1', '::1'].includes(location.hostname);
    const isHttps     = location.protocol === 'https:';
    if (!isLocalhost && !isHttps) return 'insecure_context';

    // Navegador sem suporte a getUserMedia
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) return 'no_support';

    return 'ok';
  }

  // ── VERIFICAR PERMISSÃO ──────────────────────
  async function checarPermissao() {
    if (navigator.permissions) {
      try {
        const result = await navigator.permissions.query({ name: 'camera' });
        return result.state; // 'granted' | 'prompt' | 'denied'
      } catch (_) { /* Firefox não suporta query de câmera */ }
    }
    return 'prompt';
  }

  // ── ABRIR CÂMERA (com verificação) ────────────
  window.openBarcodeCamera = async function (callback) {
    onDetectCallback = callback;

    // 1. Diagnóstico do ambiente
    const diag = diagnosticarCamera();

    if (diag === 'insecure_context') {
      mostrarErroBloqueio(
        '🔒 Câmera indisponível via <strong>HTTP em rede local</strong>.<br><br>' +
        'O navegador só permite câmera em contextos seguros.<br><br>' +
        '<strong>Soluções:</strong><br>' +
        '① Acesse pelo próprio computador usando<br>' +
        '&nbsp;&nbsp;&nbsp;<code style="background:rgba(255,255,255,.1);padding:.1rem .4rem;border-radius:4px;">http://localhost/</code><br>' +
        '② Ou configure HTTPS no XAMPP<br>' +
        '③ Ou use a digitação manual do código abaixo ↓'
      );
      return;
    }

    if (diag === 'no_support') {
      mostrarErroBloqueio(
        '❌ Navegador não suporta câmera.<br>Use <strong>Chrome</strong> ou <strong>Edge</strong> atualizados.'
      );
      return;
    }

    // 2. Verifica permissão atual antes de abrir o modal
    const estado = await checarPermissao();

    if (estado === 'denied') {
      mostrarErroBloqueio(
        '🚫 Acesso à câmera <strong>bloqueado</strong>.<br><br>' +
        'Para liberar:<br>' +
        '① Clique no ícone 🔒 ou 📷 na barra de endereços<br>' +
        '② Mude a câmera para <strong style="color:#86efac">Permitir</strong><br>' +
        '③ Recarregue a página e tente novamente'
      );
      return;
    }

    // 3. Permissão OK ou "prompt" — abre o modal e solicita acesso
    openModal('modal-camera');
    setStatus('⏳ Solicitando acesso à câmera...', 'info');

    try {
      stream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: { ideal: 'environment' },
          width:  { ideal: 1280 },
          height: { ideal: 720 },
        }
      });

      const video = videoEl();
      if (!video) return;
      video.srcObject = stream;
      await video.play();
      scanning = true;
      setStatus('📷 Aponte o código de barras para a câmera...', 'info');
      startDetection();

    } catch (err) {
      console.error('Camera error:', err);

      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setStatus(
          '🚫 Permissão negada.<br>' +
          'Clique no ícone 🔒 na barra de endereços, permita a câmera e recarregue a página.',
          'error'
        );
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setStatus('❌ Nenhuma câmera encontrada neste dispositivo.', 'error');
      } else if (err.name === 'NotReadableError') {
        setStatus('❌ A câmera está sendo usada por outro aplicativo.', 'error');
      } else {
        setStatus('❌ Erro: ' + err.message, 'error');
      }
    }
  };

  // ── FECHAR CÂMERA ────────────────────────────────
  window.closeBarcodeCamera = function () {
    scanning = false;
    if (stream) {
      stream.getTracks().forEach(t => t.stop());
      stream = null;
    }
    closeModal('modal-camera');
    _resetModalCamera();
  };

  // ── DETECÇÃO ─────────────────────────────────────
  async function startDetection() {
    if ('BarcodeDetector' in window) {
      const detector = new BarcodeDetector({
        formats: ['ean_13', 'ean_8', 'code_128', 'code_39', 'qr_code', 'upc_a', 'upc_e']
      });
      detectLoop(detector);
    } else {
      setStatus(
        '⚠️ Detecção automática não suportada neste navegador.<br>Digite o código manualmente abaixo.',
        'warning'
      );
    }
  }

  async function detectLoop(detector) {
    const video = videoEl();
    if (!video || !scanning) return;

    if (video.readyState === video.HAVE_ENOUGH_DATA) {
      try {
        const barcodes = await detector.detect(video);
        if (barcodes.length > 0) {
          const code = barcodes[0].rawValue;
          setStatus(`✅ Código detectado: ${code}`, 'success');
          scanning = false;
          await new Promise(r => setTimeout(r, 500));
          closeBarcodeCamera();
          if (onDetectCallback) onDetectCallback(code);
          return;
        }
      } catch (_) { /* continua tentando */ }
    }
    if (scanning) requestAnimationFrame(() => detectLoop(detector));
  }

  // ── HELPERS ──────────────────────────────────────
  function setStatus(msg, type) {
    const el = statusEl();
    if (!el) return;
    const colors = { info: '#93c5fd', success: '#86efac', error: '#fca5a5', warning: '#fde68a' };
    el.innerHTML   = msg;
    el.style.color = colors[type] || '#fff';
  }

  function _resetModalCamera() {
    const video = videoEl();
    if (video) video.style.display = '';
    const el = statusEl();
    if (el) {
      el.innerHTML       = 'Iniciando câmera...';
      el.removeAttribute('style');
      el.style.color     = '#93c5fd';
      el.style.textAlign = 'center';
    }
  }

  // Exibe erro sem mostrar o vídeo — apenas mensagem de bloqueio
  function mostrarErroBloqueio(htmlMsg) {
    if (typeof showToast === 'function') {
      showToast('Câmera bloqueada — veja as instruções.', 'error', 5000);
    }

    openModal('modal-camera');

    const video = videoEl();
    if (video) video.style.display = 'none';

    const el = statusEl();
    if (el) {
      el.innerHTML          = htmlMsg;
      el.style.color        = '#fca5a5';
      el.style.lineHeight   = '1.9';
      el.style.textAlign    = 'left';
      el.style.background   = 'rgba(239,68,68,.08)';
      el.style.border       = '1px solid rgba(239,68,68,.2)';
      el.style.borderRadius = '8px';
      el.style.padding      = '.85rem 1rem';
      el.style.marginTop    = '.5rem';
      el.style.fontSize     = '.85rem';
    }
  }

})();
